package com.infinityclock.app.widget.config

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.updateAll
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.clock.presets.buildPresetCatalog
import com.infinityclock.app.common.ClockRef
import com.infinityclock.app.common.ClockRefKind
import com.infinityclock.app.data.ClockRepository
import com.infinityclock.app.data.StudioRepository
import com.infinityclock.app.data.WidgetConfigRepository
import com.infinityclock.app.studio.model.StudioClockConfig
import com.infinityclock.app.studio.render.StudioClockPreview
import com.infinityclock.app.theme.InfinityClockTheme
import com.infinityclock.app.widget.AnalogClockWidgetLarge
import com.infinityclock.app.widget.DigitalClockWidgetMedium
import com.infinityclock.app.widget.DigitalClockWidgetSmall
import com.infinityclock.app.widget.HybridClockWidgetExtraLarge
import com.infinityclock.app.widget.model.WidgetInstanceConfig
import com.infinityclock.app.clock.engine.ClockEngine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * The real AppWidget configuration Activity (android.appwidget.action.
 * APPWIDGET_CONFIGURE). Every field the Part 2 brief lists — clock,
 * 12/24, seconds, date, day, background/transparency — is wired to an
 * actual WidgetInstanceConfig saved per appWidgetId, and Save pushes an
 * immediate refresh of that one widget instance before returning RESULT_OK.
 */
class WidgetConfigurationActivity : ComponentActivity() {

    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setResult(Activity.RESULT_CANCELED)

        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        // If the app's "Use as Widget" flow requested a specific clock be
        // pre-selected right after pinning, it's passed here (direct-launch
        // case) or via the in-memory handoff (system auto-launch case).
        val preselected = ClockRef.deserialize(intent?.getStringExtra(EXTRA_PRESELECTED_CLOCK_REF))
            ?: com.infinityclock.app.widget.PendingWidgetSelection.consume()

        setContent {
            InfinityClockTheme {
                Surface {
                    WidgetConfigScreen(
                        appWidgetId = appWidgetId,
                        preselected = preselected,
                        onSave = { config -> finishWithSave(config) }
                    )
                }
            }
        }
    }

    private fun finishWithSave(config: WidgetInstanceConfig) {
        androidx.lifecycle.lifecycleScope.launch {
            WidgetConfigRepository(this@WidgetConfigurationActivity).save(config)
            refreshThisWidget()
            val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            setResult(Activity.RESULT_OK, resultValue)
            finish()
        }
    }

    private suspend fun refreshThisWidget() {
        val provider = AppWidgetManager.getInstance(this).getAppWidgetInfo(appWidgetId)?.provider
        when (widgetClassFor(provider)) {
            DigitalClockWidgetSmall::class.java -> DigitalClockWidgetSmall().updateAll(this)
            DigitalClockWidgetMedium::class.java -> DigitalClockWidgetMedium().updateAll(this)
            AnalogClockWidgetLarge::class.java -> AnalogClockWidgetLarge().updateAll(this)
            else -> HybridClockWidgetExtraLarge().updateAll(this)
        }
    }

    private fun widgetClassFor(provider: ComponentName?): Class<*> = when (provider?.className) {
        DigitalClockWidgetSmallReceiverName -> DigitalClockWidgetSmall::class.java
        DigitalClockWidgetMediumReceiverName -> DigitalClockWidgetMedium::class.java
        AnalogClockWidgetLargeReceiverName -> AnalogClockWidgetLarge::class.java
        else -> HybridClockWidgetExtraLarge::class.java
    }

    companion object {
        const val EXTRA_PRESELECTED_CLOCK_REF = "com.infinityclock.app.EXTRA_PRESELECTED_CLOCK_REF"
        private const val DigitalClockWidgetSmallReceiverName = "com.infinityclock.app.widget.DigitalClockWidgetSmallReceiver"
        private const val DigitalClockWidgetMediumReceiverName = "com.infinityclock.app.widget.DigitalClockWidgetMediumReceiver"
        private const val AnalogClockWidgetLargeReceiverName = "com.infinityclock.app.widget.AnalogClockWidgetLargeReceiver"
    }
}

@Composable
private fun WidgetConfigScreen(
    appWidgetId: Int,
    preselected: ClockRef?,
    onSave: (WidgetInstanceConfig) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var standardClocks by remember { mutableStateOf<List<ClockConfig>>(emptyList()) }
    var studioClocks by remember { mutableStateOf<List<StudioClockConfig>>(emptyList()) }
    var selectedRef by remember { mutableStateOf(preselected) }
    var is24Hour by remember { mutableStateOf(true) }
    var showSeconds by remember { mutableStateOf(false) }
    var showDate by remember { mutableStateOf(true) }
    var showDay by remember { mutableStateOf(true) }
    var transparentBackground by remember { mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        val presets = buildPresetCatalog()
        val custom = ClockRepository(context).customClocksFlow.first()
        standardClocks = presets + custom
        studioClocks = StudioRepository(context).clocksFlow.first()

        val existing = WidgetConfigRepository(context).get(appWidgetId)
        if (existing != null) {
            selectedRef = existing.clockRef
            is24Hour = existing.is24Hour
            showSeconds = existing.showSeconds
            showDate = existing.showDate
            showDay = existing.showDay
            transparentBackground = existing.transparentBackground
        } else if (selectedRef == null && standardClocks.isNotEmpty()) {
            selectedRef = ClockRef(ClockRefKind.STANDARD, standardClocks.first().id)
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Configure Widget") }) }) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                val previewStandard = standardClocks.firstOrNull { ClockRef(ClockRefKind.STANDARD, it.id) == selectedRef }
                val previewStudio = studioClocks.firstOrNull { ClockRef(ClockRefKind.STUDIO, it.id) == selectedRef }
                Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    androidx.compose.foundation.layout.Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1.6f)
                    ) {
                        when {
                            previewStandard != null -> ClockEngine(previewStandard, AnimationQuality.BALANCED, live = true)
                            previewStudio != null -> StudioClockPreview(previewStudio, AnimationQuality.BALANCED, is24Hour = is24Hour)
                            else -> Text("Pick a clock below", modifier = Modifier.padding(16.dp))
                        }
                    }
                }
                Text(
                    "Widget preview — actual appearance may vary slightly by launcher.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item { Text("Choose a clock", style = MaterialTheme.typography.titleMedium) }
            items(standardClocks) { clock ->
                val ref = ClockRef(ClockRefKind.STANDARD, clock.id)
                SelectableRow(clock.name + if (clock.isCustom) " (Custom)" else "", ref == selectedRef) { selectedRef = ref }
            }
            items(studioClocks) { clock ->
                val ref = ClockRef(ClockRefKind.STUDIO, clock.id)
                SelectableRow(clock.name + " (Studio)", ref == selectedRef) { selectedRef = ref }
            }
            if (studioClocks.isNotEmpty()) {
                item {
                    Text(
                        "Studio clocks currently appear in widgets as a styled digital readout using their colors — full custom layouts inside widgets aren't supported by Android's widget framework yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item { Text("Options", style = MaterialTheme.typography.titleMedium) }
            item { ToggleRow("24-hour format", is24Hour) { is24Hour = it } }
            item { ToggleRow("Show seconds", showSeconds) { showSeconds = it } }
            item { ToggleRow("Show date", showDate) { showDate = it } }
            item { ToggleRow("Show day", showDay) { showDay = it } }
            item { ToggleRow("Transparent background", transparentBackground) { transparentBackground = it } }

            item {
                Button(
                    onClick = {
                        val ref = selectedRef ?: return@Button
                        onSave(
                            WidgetInstanceConfig(
                                appWidgetId = appWidgetId,
                                clockRef = ref,
                                is24Hour = is24Hour,
                                showSeconds = showSeconds,
                                showDate = showDate,
                                showDay = showDay,
                                transparentBackground = transparentBackground
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = selectedRef != null
                ) { Text("Add Widget") }
            }
        }
    }
}

@Composable
private fun SelectableRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .then(Modifier),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = if (selected) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge)
        androidx.compose.material3.RadioButton(selected = selected, onClick = onClick)
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
