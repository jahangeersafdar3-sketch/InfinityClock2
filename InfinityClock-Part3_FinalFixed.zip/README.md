# Infinity Clock — Part 1

A premium clock customization studio built with Kotlin + Jetpack Compose +
Material 3. This is **Part 1**: the foundation architecture, the shared
clock rendering engine, 102 built-in presets, full customization/save/load,
and settings — all working end to end, offline, with no cloud dependency.

## How the build works

This repo intentionally does **not** ship a `gradlew` binary wrapper jar.
CI (`.github/workflows/build.yml`) installs Gradle 8.7 directly via
`gradle/actions/setup-gradle` and runs `gradle assembleDebug`, which is a
fully supported, reproducible way to build in GitHub Actions without
committing a binary jar to the repo. Every push/PR to `main` produces a
downloadable debug APK as a workflow artifact named
`infinity-clock-debug-apk`.

To build locally, install Gradle 8.7+ and Android SDK 34, then run:

```
gradle assembleDebug
```

If you'd rather use the standard wrapper locally, run `gradle wrapper
--gradle-version 8.7` once inside the project to generate `gradlew` /
`gradlew.bat` / `gradle/wrapper/gradle-wrapper.jar` — CI does not need this,
it's only for local convenience.

## Architecture

```
app/src/main/java/com/infinityclock/app/
  MainActivity.kt        - app entry point, theme + nav host
  navigation/             - Screen routes, bottom nav, NavHost wiring
  clock/
    model/                - ClockConfig + every enum (the single source of
                            truth for how any clock looks/behaves)
    engine/                - ClockEngine (dispatcher), Digital/Analog/Hybrid
                            face renderers, animated backgrounds
    presets/               - curated color palettes + the 102-preset catalog
                            generator (built from category "blueprints", not
                            102 duplicated screens)
    util/                  - real system-clock ticker, formatting, battery
  data/                   - DataStore-backed SettingsRepository and
                            ClockRepository (custom clocks, favorites, recents)
  viewmodel/              - AppViewModel: single shared state holder
  ui/
    home/, gallery/, create/, widgets/, settings/, components/
  theme/                  - Material 3 color scheme (Light/Dark/AMOLED)
```

## What's real vs. what's explicitly scoped out

- The clock is computed from `Calendar.getInstance()` every tick (see
  `clock/util/TimeTicker.kt`) — never a naive incrementing counter — and the
  ticker re-syncs to the real second boundary every loop, so it cannot drift.
- The analog second hand's sweep animation is derived from the actual
  millisecond-within-second value, not a separate animation clock.
- Battery percentage on the "Digital + Battery" hybrid clock reads the real
  `BatteryManager` broadcast.
- Every switch/slider/chip in Settings and the Create/Customize screen is
  bound to real state (DataStore-persisted for Settings; the in-memory
  `ClockConfig` under edit for Create) — none are decorative.
- Custom clocks, favorites, and recently-used are persisted locally via
  Jetpack DataStore (JSON via `org.json`, which ships with Android — no
  extra serialization plugin, no network, no Firebase).
- Animation quality (`BATTERY_SAVER` / `BALANCED` / `SMOOTH` / `MAXIMUM`)
  actually gates whether infinite-repeat animations run; `BATTERY_SAVER`
  always renders a static frame. `ClockEngine` also pauses its ticker
  entirely when the hosting lifecycle isn't `STARTED`.
- The **Widgets** tab and its navigation route exist now, as required, but
  Part 1 does not claim to ship real home-screen widgets (that needs an
  `AppWidgetProvider`, which is Part 2/3 scope per the brief) — the screen
  says this plainly instead of showing a fake control.
- Release signing config is deliberately left unattached in
  `app/build.gradle.kts` (with a comment marking where Part 2/3 wires it in)
  since no signing key exists yet; the debug build is fully functional.

## Preset catalog

34 categories (16 digital / 13 analog / 5 hybrid) x 3 curated-palette
variants each = **102 presets**, all rendered by the one shared
`ClockEngine` — see `clock/presets/ClockPresets.kt`.

## Part 2 — Clock Studio, Layers/Undo-Redo, and Real Home-Screen Widgets

Part 2 adds two large, independent subsystems on top of Part 1 without
touching any existing preset, customization, settings, or navigation code
(all Part 1 files were extended additively, not rewritten):

### Clock Studio (`studio/`, `ui/studio/`, `viewmodel/StudioViewModel.kt`)

- A free-form canvas editor: `CanvasElement` (hours/minutes/seconds/date/
  day/month/custom text, rectangle/circle/line shapes, background,
  decorative dots, particles, glow orb) with real move/resize/rotate via
  on-canvas drag handles, plus opacity, color, gradient, font, font size,
  stroke, shadow, glow, visibility, and layer order — all genuinely wired,
  not decorative sliders.
- A real layer panel (select / hide-show / duplicate / delete / rename /
  reorder) and a snapshot-based undo/redo stack (`studio/undo/
  UndoRedoStack.kt`) covering every listed operation.
- Per-element animation presets (fade, scale, pulse, glow, rotation, slide,
  light sweep, breathing, gradient flow, particle, number transition) with
  a speed multiplier.
- Studio clocks persist via `StudioRepository` (DataStore + org.json,
  independent of Part 1's `ClockRepository`) and appear in the Gallery
  under a new "Studio" filter, in the Create tab's hub, and are selectable
  for widgets.
- The Create tab is now a hub offering both **Clock Studio** (new) and
  **Quick Customize** (the original Part 1 parametric editor, completely
  unchanged) — nothing from Part 1 was removed.

### Real Home-Screen Widgets (`widget/`)

- Four real `Jetpack Glance` AppWidget providers, registered in the
  manifest and visible in Android's widget picker (Home Screen → Widgets →
  Infinity Clock): Digital Small, Digital Medium, Analog Large, Hybrid
  Extra Large. Each has its own `appwidget-provider` XML with real size
  constraints, `resizeMode`, preview image, and configuration Activity.
- **Per-instance configuration**: `WidgetConfigurationActivity` implements
  the real `ACTION_APPWIDGET_CONFIGURE` contract; each pinned widget stores
  its own `WidgetInstanceConfig` (clock choice, 12/24, seconds, date, day,
  background/transparency) keyed by its Android-assigned `appWidgetId`, so
  multiple widgets never share settings.
- **Responsive layout**: `InfinityWidgetContent` branches on widget size
  category rather than cropping a fixed layout; analog/hybrid faces are
  rendered into a `Bitmap` via `WidgetBitmapRenderer` since RemoteViews/
  Glance cannot host a live Compose `Canvas`.
- **Honest limitation documented, not faked**: Studio (freeform) clocks
  can't yet render their full custom layout inside a widget — Android's
  widget framework doesn't support arbitrary custom drawing there. A Studio
  clock shown in a widget renders as a styled digital readout using that
  design's own colors instead, and the configuration screen says this
  plainly.
- **Correct, battery-respecting update lifecycle** (`WidgetUpdateScheduler`,
  `widget/receivers/`): widgets cannot redraw every second on their own, so
  instead of pretending otherwise, an inexact `AlarmManager` alarm
  (`setAndAllowWhileIdle`, no exact-alarm permission needed) ticks roughly
  once a minute — starting only when the first widget is added
  (`onEnabled`), and stopping the moment the last one is removed
  (`onDeleted`, checked across all four widget types via one shared
  `WidgetConfigRepository`). `WidgetSystemEventReceiver` handles reboot,
  manual time change, timezone change, and locale change.
- **"Use as Widget"** (`UseAsWidgetLauncher`): uses the official
  `AppWidgetManager.requestPinAppWidget` API (Android 8+) to let the user
  pin a widget for a specific clock directly from the Gallery, a Studio
  clock, or the Widgets tab. Where a launcher doesn't support that API, the
  app says so honestly and points to the manual picker instead of
  pretending the pin happened.
- Saving a custom or Studio clock immediately triggers a refresh of any
  matching widgets (`WidgetUpdateScheduler.requestUpdateForClock`) rather
  than waiting for the next minute tick.

### What's out of scope for Part 2 (by design, not oversight)

- Pixel-perfect Studio layouts inside widgets (see above).
- Anything from the Part 3 brief (live wallpaper, alarms, timer, stopwatch,
  world clock) — intentionally deferred to keep this update reviewable and
  correct rather than rushed.

## Part 3 — Live Wallpaper, Alarms, Timer, Stopwatch, World Clock, Control Center

Part 3 adds the remaining "use on phone" surfaces. The old **Widgets** bottom
tab is now **Use on Phone**: a control center whose top card still opens the
exact Part 2 widget setup screen, plus new cards for every feature below.

### Live Wallpaper (`wallpaper/`)

- `InfinityLiveWallpaperService` is a real `WallpaperService`: it draws
  directly onto the wallpaper's `SurfaceHolder` Canvas (Compose cannot run
  here), with a draw-loop interval driven by the selected performance mode
  (`BATTERY_SAVER` = 1/min, `BALANCED` = 1/sec, `SMOOTH` = 5fps, `MAXIMUM` =
  ~30fps) and stopped completely via `onVisibilityChanged`/
  `onSurfaceDestroyed` when not visible.
- `WallpaperConfigActivity` (+ `WallpaperConfigScreen`) lets you pick a
  clock, colors, position/size, and performance mode, and hands off to the
  real system picker via `ACTION_CHANGE_LIVE_WALLPAPER` — this app never
  claims to set the wallpaper itself. It also honestly notes that its own
  preview is approximate, not the real wallpaper render.
- Lock Screen: Android's live wallpaper API applies to the Home Screen; lock
  screen behavior is OS/OEM-dependent and outside any single app's control,
  so this is not claimed as a feature — the Bedside/Full Screen Clock modes
  below are the supported way to get a full clock display, including over
  the lock screen where the OS allows it.

### Burn-in Protection (`burnin/BurnInShifter.kt`)

Shared by the wallpaper and the Bedside/Full Screen Clock: every N minutes
it picks a new small random offset and eases toward it over ~4 seconds
(smoothstep, not linear), so the clock visibly drifts rather than jumping —
exactly what the brief asked for. On/off, interval, and movement range are
all real, working settings.

### Bedside Clock / Full Screen Clock (`fullscreen/FullScreenClockActivity.kt`)

One real Activity, not two separately-built screens pretending to be
different — "Bedside Clock" and "Full Screen Clock" are the same feature
with different starting modes (Normal / Dim / Red Night / AMOLED), which is
the honest description of what's implemented. Keeps the screen on, doesn't
lock orientation, applies burn-in protection, and reveals a tap-to-show
control overlay that auto-hides.

### Alarms (`alarm/`)

- A real Android alarm clock built on `AlarmManager.setAlarmClock()` — the
  API meant specifically for alarm-clock apps: always exact, always exempt
  from Doze, and needs no special exact-alarm permission (unlike
  `setExactAndAllowWhileIdle`).
- `AlarmScheduler.nextTriggerMillis()` computes the next real occurrence
  from `Calendar` (so DST/timezone are handled by the platform automatically),
  supporting one-shot and repeat-by-weekday alarms.
- `AlarmFireReceiver` starts `AlarmRingingActivity` directly — a documented
  exception to Android's background-activity-start restrictions for
  PendingIntents delivered by `AlarmManager` for the app's own alarm — which
  shows over the lock screen, turns the screen on, plays the alert sound on
  the alarm stream, vibrates, and offers real Snooze/Dismiss actions.
- `AlarmBootReceiver` re-registers every enabled alarm after a reboot,
  since `AlarmManager` alarms don't survive one.
- The editor screen uses Material 3's real `TimePicker` plus repeat-day
  chips, label, vibrate/sound toggles.

### Timer (`timer/`)

- Anchored on `SystemClock.elapsedRealtime()` (a real end-timestamp, not a
  decrementing counter), so backgrounding/reopening the app always shows
  the correct remaining time.
- Uses an exact alarm only when the app already has permission
  (`canScheduleExactAlarms()`, API 31+); otherwise it falls back to an
  inexact-but-Doze-aware alarm and shows an honest one-line notice with a
  direct link to grant the permission, rather than silently failing or
  demanding a permission most users won't need.
- Fires a real completion alert (sound + vibration + notification with a
  Stop action) even if the app was backgrounded or closed.

### Stopwatch (`stopwatch/`)

Also anchored on `SystemClock.elapsedRealtime()` for correct elapsed-time
math (per the brief's explicit instruction), with persisted state so it
survives app restart, plus real Start/Pause/Resume/Reset/Lap with lap
history and per-lap split times.

### World Clock (`worldclock/`)

A curated ~65-city catalog with search/add/remove/reorder/favorite, each
city's current time computed from real `java.util.TimeZone` data — daylight
saving is applied automatically by the platform, not hand-rolled.

### Data Safety (Settings → Data Safety)

Export/Import of custom clocks and Studio designs to a user-chosen file via
the Storage Access Framework (`ActivityResultContracts.CreateDocument` /
`OpenDocument`) — no cloud account involved, ever. Imported clocks always
get new IDs so importing can never silently overwrite existing data.

### What's out of scope for Part 3 (by design, not oversight)

- A custom sound picker for alarms/timer (both use the device's default
  alarm/notification sound via `RingtoneManager`) — a full sound-picker UI
  was cut to keep this update reviewable; the architecture (`AlertPlayer`)
  supports adding one later without changes elsewhere.
- Weather integration: intentionally not built at all in this pass, so
  there's no half-finished weather code and no fake weather data anywhere;
  the app has zero network dependency as a result.
- Live lock-screen wallpaper as a guaranteed feature (see above — this is
  an OS/OEM capability question, not something an app can unilaterally add).
