# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep class com.infinityclock.app.clock.model.** { *; }
