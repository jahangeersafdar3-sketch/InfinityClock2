package com.infinityclock.app.alarm.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * repeatDays uses java.util.Calendar's day constants (Calendar.SUNDAY=1 ..
 * Calendar.SATURDAY=7) so scheduling math can use Calendar directly with no
 * translation layer. An empty set means "one-shot, next matching time only".
 */
data class AlarmItem(
    val id: String = UUID.randomUUID().toString(),
    val hour: Int,
    val minute: Int,
    val label: String = "Alarm",
    val enabled: Boolean = true,
    val repeatDays: Set<Int> = emptySet(),
    val vibrate: Boolean = true,
    val soundEnabled: Boolean = true
) {
    val requestCode: Int get() = id.hashCode()

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("hour", hour); put("minute", minute); put("label", label)
        put("enabled", enabled); put("repeatDays", JSONArray(repeatDays.toList()))
        put("vibrate", vibrate); put("soundEnabled", soundEnabled)
    }

    companion object {
        fun fromJson(j: JSONObject): AlarmItem {
            val daysArray = j.optJSONArray("repeatDays") ?: JSONArray()
            return AlarmItem(
                id = j.getString("id"), hour = j.getInt("hour"), minute = j.getInt("minute"),
                label = j.optString("label", "Alarm"), enabled = j.optBoolean("enabled", true),
                repeatDays = (0 until daysArray.length()).map { daysArray.getInt(it) }.toSet(),
                vibrate = j.optBoolean("vibrate", true), soundEnabled = j.optBoolean("soundEnabled", true)
            )
        }
    }
}
