package com.infinityclock.app.clock.util

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.Calendar

data class TickTime(
    val hour24: Int,
    val hour12: Int,
    val minute: Int,
    val second: Int,
    val millisWithinSecond: Int,
    val dayOfWeek: String,
    val dayOfMonth: Int,
    val month: String,
    val year: Int,
    val epochMillis: Long
)

private val dayNames = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
private val monthNames = arrayOf(
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
)

/**
 * Every tick reads the real device clock via Calendar.getInstance() — it
 * never just increments a counter — so the displayed time cannot drift from
 * system time, matches the OS if the user changes it, and self-corrects
 * across app pauses/resumes.
 */
fun currentTickTime(): TickTime {
    val now = Calendar.getInstance()
    val hour24 = now.get(Calendar.HOUR_OF_DAY)
    val hour12raw = now.get(Calendar.HOUR)
    return TickTime(
        hour24 = hour24,
        hour12 = if (hour12raw == 0) 12 else hour12raw,
        minute = now.get(Calendar.MINUTE),
        second = now.get(Calendar.SECOND),
        millisWithinSecond = now.get(Calendar.MILLISECOND),
        dayOfWeek = dayNames[now.get(Calendar.DAY_OF_WEEK) - 1],
        dayOfMonth = now.get(Calendar.DAY_OF_MONTH),
        month = monthNames[now.get(Calendar.MONTH)],
        year = now.get(Calendar.YEAR),
        epochMillis = now.timeInMillis
    )
}

/**
 * Emits a fresh TickTime aligned to real wall-clock second boundaries.
 * Rather than a naive `delay(1000)` loop (which drifts over time because it
 * ignores how long each emission + consumer work took), it computes the
 * exact number of milliseconds remaining until the next system-clock second
 * and sleeps exactly that long, so it stays locked to the true clock.
 */
fun tickerFlow(): Flow<TickTime> = flow {
    while (true) {
        val time = currentTickTime()
        emit(time)
        val msUntilNextSecond = 1000 - time.millisWithinSecond
        delay(msUntilNextSecond.toLong().coerceAtLeast(16L))
    }
}
