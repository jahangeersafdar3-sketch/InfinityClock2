package com.infinityclock.app.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import androidx.glance.appwidget.updateAll
import com.infinityclock.app.data.WidgetConfigRepository
import com.infinityclock.app.widget.receivers.WidgetTickReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Schedules minute-accurate widget refreshes without any continuously
 * running service. This is the officially-supported pattern for Android
 * widgets: RemoteViews/Glance cannot redraw on their own every second, so
 * instead of pretending otherwise, an inexact AlarmManager alarm (battery
 * friendly — `setAndAllowWhileIdle`, not an exact alarm) fires roughly once
 * a minute ONLY while at least one Infinity Clock widget is actually
 * pinned, self-rescheduling from WidgetTickReceiver, and stopping the
 * moment the last widget is removed (see onDisabled in each provider).
 */
object WidgetUpdateScheduler {

    private const val TICK_INTERVAL_MS = 60_000L
    private const val REQUEST_CODE = 4471

    private fun tickPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, WidgetTickReceiver::class.java).apply {
            action = WidgetTickReceiver.ACTION_TICK
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags)
    }

    fun scheduleNextTick(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val triggerAt = SystemClock.elapsedRealtime() + TICK_INTERVAL_MS
        alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, tickPendingIntent(context))
    }

    fun cancelTicking(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        alarmManager.cancel(tickPendingIntent(context))
    }

    /** Called once from onEnabled (first widget added) to start the chain. */
    fun startIfNeeded(context: Context) {
        scheduleNextTick(context)
    }

    /** Refreshes every Infinity Clock widget instance immediately — used after
     * a save in the Clock Studio/quick customizer so edits show up right away
     * instead of waiting for the next minute tick. */
    fun requestUpdateForClock(context: Context, @Suppress("UNUSED_PARAMETER") clockId: String) {
        triggerAllWidgetUpdates(context)
    }

    fun triggerAllWidgetUpdates(context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            DigitalClockWidgetSmall().updateAll(context)
            DigitalClockWidgetMedium().updateAll(context)
            AnalogClockWidgetLarge().updateAll(context)
            HybridClockWidgetExtraLarge().updateAll(context)
        }
    }

    suspend fun hasAnyConfiguredWidget(context: Context): Boolean =
        WidgetConfigRepository(context).hasAnyConfigured()
}
