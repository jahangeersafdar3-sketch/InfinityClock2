package com.infinityclock.app.wallpaper

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.util.currentTickTime
import com.infinityclock.app.clock.util.timeString
import com.infinityclock.app.burnin.BurnInShifter
import com.infinityclock.app.data.WallpaperConfigRepository
import com.infinityclock.app.widget.render.WidgetBitmapRenderer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.min

/**
 * A real Android WallpaperService. RemoteViews/Compose cannot run here —
 * this draws directly onto the wallpaper's SurfaceHolder Canvas, exactly
 * like the platform's own live wallpapers, with a draw-loop interval driven
 * by the selected performance mode and stopped entirely while not visible.
 */
class InfinityLiveWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = InfinityEngine()

    private fun intervalMillisFor(quality: AnimationQuality): Long = when (quality) {
        AnimationQuality.BATTERY_SAVER -> 60_000L
        AnimationQuality.BALANCED -> 1_000L
        AnimationQuality.SMOOTH -> 200L
        AnimationQuality.MAXIMUM -> 33L
    }

    inner class InfinityEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        private val repository = WallpaperConfigRepository(this@InfinityLiveWallpaperService)

        @Volatile private var config = WallpaperConfig()
        @Volatile private var engineVisible = false
        private var burnInShifter: BurnInShifter? = null

        private val drawRunnable = object : Runnable {
            override fun run() {
                drawFrame()
                if (engineVisible) {
                    handler.postDelayed(this, intervalMillisFor(config.performanceMode))
                }
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            scope.launch {
                repository.configFlow.collectLatest { newConfig ->
                    val intervalChanged = newConfig.performanceMode != config.performanceMode
                    config = newConfig
                    rebuildBurnInShifter()
                    if (intervalChanged && engineVisible) {
                        handler.removeCallbacks(drawRunnable)
                        handler.post(drawRunnable)
                    }
                }
            }
        }

        private fun rebuildBurnInShifter() {
            val rangePx = config.burnInMovementRangeDp * resources.displayMetrics.density
            burnInShifter = if (config.burnInProtectionEnabled) {
                BurnInShifter(rangePx, config.burnInShiftIntervalMinutes.coerceAtLeast(1) * 60_000L)
            } else {
                null
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            engineVisible = visible
            if (visible) {
                handler.post(drawRunnable)
            } else {
                handler.removeCallbacks(drawRunnable)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            engineVisible = false
            handler.removeCallbacks(drawRunnable)
            scope.cancel()
        }

        private fun drawFrame() {
            val holder = surfaceHolder ?: return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) render(canvas)
            } catch (e: Exception) {
                // A destroyed/invalid surface can throw here during rapid
                // visibility changes; skip this frame rather than crash.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                        // Surface may already be gone; nothing more to do.
                    }
                }
            }
        }

        private fun render(canvas: Canvas) {
            val w = canvas.width
            val h = canvas.height
            canvas.drawColor(argb(config.backgroundColor))

            var shiftX = 0f
            var shiftY = 0f
            val shifter = burnInShifter
            if (shifter != null) {
                shifter.update(System.currentTimeMillis())
                shiftX = shifter.currentOffsetX
                shiftY = shifter.currentOffsetY
            }

            val centerX = w / 2f + w * config.offsetXFraction + shiftX
            val centerY = h / 2f + h * config.offsetYFraction + shiftY
            val time = currentTickTime()

            if (config.renderAsAnalog) {
                val size = (min(w, h) * 0.55f * config.clockScale).toInt().coerceAtLeast(1)
                val bitmap = WidgetBitmapRenderer.renderAnalogFace(
                    widthPx = size, heightPx = size,
                    primaryColor = config.primaryColor, secondaryColor = config.secondaryColor, accentColor = config.accentColor,
                    hour24 = time.hour24, minute = time.minute, second = time.second
                )
                val paint = Paint().apply { alpha = (config.opacity * 255).toInt() }
                canvas.drawBitmap(bitmap, centerX - size / 2f, centerY - size / 2f, paint)
                if (config.showDate) {
                    drawDateLine(canvas, centerX, centerY + size / 2f + h * 0.05f, w, h, time)
                }
            } else {
                val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = argb(config.primaryColor)
                    alpha = (config.opacity * 255).toInt()
                    textAlign = Paint.Align.CENTER
                    textSize = h * 0.12f * config.clockScale
                    if (config.glow) setShadowLayer(28f, 0f, 0f, argb(config.primaryColor))
                }
                val timeText = time.timeString(config.is24Hour, config.showSeconds)
                canvas.drawText(timeText, centerX, centerY, timePaint)
                if (config.showDate) {
                    drawDateLine(canvas, centerX, centerY + h * 0.09f, w, h, time)
                }
            }
        }

        private fun drawDateLine(canvas: Canvas, x: Float, y: Float, w: Int, h: Int, time: com.infinityclock.app.clock.util.TickTime) {
            val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = argb(config.secondaryColor)
                alpha = (config.opacity * 255).toInt()
                textAlign = Paint.Align.CENTER
                textSize = h * 0.03f
            }
            val text = if (config.showDay) "${time.dayOfWeek}, ${time.month} ${time.dayOfMonth}" else "${time.month} ${time.dayOfMonth}"
            canvas.drawText(text, x, y, datePaint)
        }

        private fun argb(value: Long): Int = value.toInt()
    }
}
