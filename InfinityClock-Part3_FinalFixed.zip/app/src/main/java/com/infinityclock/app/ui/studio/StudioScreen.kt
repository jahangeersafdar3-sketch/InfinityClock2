package com.infinityclock.app.ui.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.infinityclock.app.studio.model.ElementType
import com.infinityclock.app.studio.render.StudioCanvasArea
import com.infinityclock.app.viewmodel.AppViewModel
import com.infinityclock.app.viewmodel.StudioViewModel
import com.infinityclock.app.clock.util.currentTickTime
import com.infinityclock.app.clock.util.tickerFlow
import kotlinx.coroutines.flow.collectLatest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(
    appViewModel: AppViewModel,
    studioId: String,
    onDone: () -> Unit
) {
    val studioViewModel: StudioViewModel = viewModel(key = "studio-$studioId")
    val allStudioClocks by appViewModel.studioClocks.collectAsState()
    val settings by appViewModel.settings.collectAsState()

    studioViewModel.load(studioId, if (studioId == "new") null else allStudioClocks.firstOrNull { it.id == studioId })

    val config by studioViewModel.config.collectAsState()
    val selectedId by studioViewModel.selectedElementId.collectAsState()
    val canUndo by studioViewModel.canUndo.collectAsState()
    val canRedo by studioViewModel.canRedo.collectAsState()

    var time by remember { mutableStateOf(currentTickTime()) }
    androidx.compose.runtime.LaunchedEffect(Unit) { tickerFlow().collectLatest { time = it } }

    var showAddMenu by remember { mutableStateOf(false) }
    var showSaveAsDialog by remember { mutableStateOf(false) }
    var saveAsName by remember { mutableStateOf(config.name + " Copy") }

    val selectedElement = config.elements.firstOrNull { it.id == selectedId }

    if (showSaveAsDialog) {
        AlertDialog(
            onDismissRequest = { showSaveAsDialog = false },
            title = { androidx.compose.material3.Text("Save As") },
            text = {
                OutlinedTextField(value = saveAsName, onValueChange = { saveAsName = it }, singleLine = true)
            },
            confirmButton = {
                Button(onClick = {
                    studioViewModel.saveAs(saveAsName) { onDone() }
                    showSaveAsDialog = false
                }) { Text("Save") }
            },
            dismissButton = { OutlinedButton(onClick = { showSaveAsDialog = false }) { Text("Cancel") } }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    OutlinedTextField(
                        value = config.name,
                        onValueChange = { studioViewModel.rename(it) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onDone) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    IconButton(onClick = { studioViewModel.undo() }, enabled = canUndo) {
                        Icon(Icons.Filled.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = { studioViewModel.redo() }, enabled = canRedo) {
                        Icon(Icons.Filled.Redo, contentDescription = "Redo")
                    }
                    IconButton(onClick = { studioViewModel.save { appViewModel.saveStudioClock(it); onDone() } }) {
                        Icon(Icons.Filled.Save, contentDescription = "Save")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Card(
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.fillMaxWidth().aspectRatio(1f)) {
                    StudioCanvasArea(
                        elements = config.elements,
                        time = time,
                        is24Hour = settings.is24Hour,
                        quality = settings.animationQuality,
                        editable = true,
                        selectedId = selectedId,
                        onSelect = { studioViewModel.select(it) },
                        onBeginGesture = { studioViewModel.beginGesture() },
                        onMove = { id, x, y -> studioViewModel.moveElement(id, x, y) },
                        onResize = { id, w, h -> studioViewModel.resizeElement(id, w, h) },
                        onRotate = { id, r -> studioViewModel.rotateElement(id, r) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = { showAddMenu = !showAddMenu }, modifier = Modifier.weight(1f)) {
                    Text(if (showAddMenu) "Hide Elements" else "Add Element")
                }
                OutlinedButton(
                    onClick = { saveAsName = config.name + " Copy"; showSaveAsDialog = true },
                    modifier = Modifier.weight(1f)
                ) { Text("Save As") }
            }

            if (showAddMenu) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                ) {
                    items(ElementType.values().toList()) { type ->
                        FilterChip(
                            selected = false,
                            onClick = {
                                studioViewModel.addElement(type)
                                showAddMenu = false
                            },
                            label = { Text(type.name.replace('_', ' ')) }
                        )
                    }
                }
            }

            HorizontalDivider()

            Row(modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier.weight(1f).fillMaxSize()) {
                    Text("Layers", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(8.dp))
                    StudioLayerPanel(
                        elements = config.elements,
                        selectedId = selectedId,
                        onSelect = { studioViewModel.select(it) },
                        onToggleVisibility = { studioViewModel.toggleVisibility(it) },
                        onMoveUp = { studioViewModel.moveLayerUp(it) },
                        onMoveDown = { studioViewModel.moveLayerDown(it) },
                        onDuplicate = { studioViewModel.duplicateElement(it) },
                        onDelete = { studioViewModel.deleteElement(it) },
                        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)
                    )
                }
                if (selectedElement != null) {
                    androidx.compose.foundation.layout.Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(1.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant)
                    )
                    androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.weight(1.3f).fillMaxSize()) {
                        item {
                            StudioPropertyPanel(
                                element = selectedElement,
                                onChange = { transform -> studioViewModel.updateSelected { it.transform() } }
                            )
                        }
                    }
                }
            }
        }
    }
}
