package com.infinityclock.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.infinityclock.app.data.WorldClockRepository
import com.infinityclock.app.worldclock.WorldClockEntry
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WorldClockViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = WorldClockRepository(application)

    val entries: StateFlow<List<WorldClockEntry>> = repository.entriesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(entry: WorldClockEntry) = viewModelScope.launch { repository.add(entry, entries.value) }
    fun remove(id: String) = viewModelScope.launch { repository.remove(id, entries.value) }
    fun toggleFavorite(id: String) = viewModelScope.launch { repository.toggleFavorite(id, entries.value) }
    fun moveUp(id: String) = viewModelScope.launch { repository.moveUp(id, entries.value) }
    fun moveDown(id: String) = viewModelScope.launch { repository.moveDown(id, entries.value) }
}
