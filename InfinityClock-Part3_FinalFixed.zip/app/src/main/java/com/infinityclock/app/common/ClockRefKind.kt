package com.infinityclock.app.common

/** Distinguishes which repository a clock id belongs to — a Part 1 parametric
 * ClockConfig (preset or quick-customized) or a Part 2 Clock Studio design. */
enum class ClockRefKind { STANDARD, STUDIO }

data class ClockRef(val kind: ClockRefKind, val id: String) {
    fun serialize(): String = "${kind.name}:$id"
    companion object {
        fun deserialize(value: String?): ClockRef? {
            if (value == null) return null
            val parts = value.split(":", limit = 2)
            if (parts.size != 2) return null
            val kind = runCatching { ClockRefKind.valueOf(parts[0]) }.getOrNull() ?: return null
            return ClockRef(kind, parts[1])
        }
    }
}
