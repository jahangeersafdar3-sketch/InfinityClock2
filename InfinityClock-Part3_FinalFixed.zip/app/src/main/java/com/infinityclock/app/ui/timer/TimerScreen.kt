package com.infinityclock.app.ui.timer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.infinityclock.app.timer.formatCountdown
import com.infinityclock.app.viewmodel.TimerViewModel
import kotlinx.coroutines.delay

private val presetsMinutes = listOf(1, 3, 5, 10, 15, 20, 30, 45, 60)

@Composable
fun TimerScreen(onBack: () -> Unit, viewModel: TimerViewModel = viewModel()) {
    val state by viewModel.state.collectAsState()
    var remaining by remember { mutableLongStateOf(viewModel.remainingMillis()) }
    var customMinutes by remember { mutableStateOf("") }

    LaunchedEffect(state.running, state.targetElapsedRealtime) {
        while (state.running) {
            remaining = viewModel.remainingMillis()
            if (remaining <= 0L) break
            delay(200)
        }
        remaining = viewModel.remainingMillis()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Timer") }) }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = formatCountdown(remaining),
                fontSize = 56.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 24.dp)
            )

            if (!state.running) {
                Text("Presets", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth())
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                ) {
                    items(presetsMinutes) { minutes ->
                        FilterChip(
                            selected = state.totalMillis == minutes * 60_000L,
                            onClick = { viewModel.setDuration(minutes * 60_000L) },
                            label = { Text("${minutes}m") }
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = customMinutes,
                        onValueChange = { customMinutes = it.filter { c -> c.isDigit() } },
                        label = { Text("Custom minutes") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { customMinutes.toLongOrNull()?.let { viewModel.setDuration(it * 60_000L) } },
                        modifier = Modifier.padding(start = 8.dp)
                    ) { Text("Set") }
                }
            }

            TimerExactAlarmNotice(viewModel = viewModel)

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
                if (state.running) {
                    Button(onClick = { viewModel.pause() }, modifier = Modifier.weight(1f)) { Text("Pause") }
                } else {
                    Button(
                        onClick = { viewModel.start() },
                        modifier = Modifier.weight(1f),
                        enabled = state.totalMillis > 0 || state.remainingMillisWhenPaused > 0
                    ) { Text(if (state.remainingMillisWhenPaused in 1 until state.totalMillis) "Resume" else "Start") }
                }
                OutlinedButton(onClick = { viewModel.reset() }, modifier = Modifier.weight(1f)) { Text("Reset") }
            }
        }
    }
}

/** Shows a one-line notice (not a blocking dialog) if precise background
 * firing isn't available, and offers a button to grant it — honest about
 * the platform limitation instead of silently failing. Returns true if it
 * rendered a notice. */
@Composable
private fun TimerExactAlarmNotice(viewModel: TimerViewModel): Boolean {
    val context = androidx.compose.ui.platform.LocalContext.current
    val canExact = viewModel.canScheduleExactAlarm()
    if (canExact) return false
    Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(
            "For a timer that fires reliably even when the app is backgrounded, allow exact alarms for Infinity Clock.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedButton(onClick = {
            val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
            intent.data = android.net.Uri.parse("package:${context.packageName}")
            context.startActivity(intent)
        }) { Text("Open Settings") }
    }
    return true
}
