package com.infinityclock.app.clock.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * The single source of truth for how any clock looks and behaves.
 * Every preset AND every user-created clock is just a ClockConfig instance
 * rendered by the shared ClockEngine — there is no per-design screen.
 */
data class ClockConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: ClockCategory,
    val isCustom: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val modifiedAt: Long = System.currentTimeMillis(),

    val font: ClockFont = ClockFont.SYSTEM,
    val primaryColor: Long,
    val secondaryColor: Long,
    val accentColor: Long,

    val backgroundStyle: BackgroundStyle = BackgroundStyle.SOLID,
    val backgroundColors: List<Long> = listOf(0xFF0B0B14),
    val gradientAngle: Float = 45f,

    val opacity: Float = 1f,
    val glow: Boolean = false,
    val glowColor: Long = primaryColor,
    val glowIntensity: Float = 0.5f,
    val shadow: Boolean = false,
    val border: Boolean = false,
    val borderColor: Long = accentColor,

    val showSeconds: Boolean = true,
    val showDate: Boolean = true,
    val showDay: Boolean = true,
    val is24Hour: Boolean = true,

    val animationStyle: AnimationStyle = AnimationStyle.SMOOTH_SWEEP,
    val animationSpeedMultiplier: Float = 1f,

    val handStyle: HandStyle = HandStyle.CLASSIC,
    val numberStyle: NumberStyle = NumberStyle.STANDARD,
    val markerStyle: MarkerStyle = MarkerStyle.TICKS,

    val isFavorite: Boolean = false
) {
    val type: ClockType get() = category.type

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("category", category.name)
        put("isCustom", isCustom)
        put("createdAt", createdAt)
        put("modifiedAt", modifiedAt)
        put("font", font.name)
        put("primaryColor", primaryColor)
        put("secondaryColor", secondaryColor)
        put("accentColor", accentColor)
        put("backgroundStyle", backgroundStyle.name)
        put("backgroundColors", JSONArray(backgroundColors))
        put("gradientAngle", gradientAngle.toDouble())
        put("opacity", opacity.toDouble())
        put("glow", glow)
        put("glowColor", glowColor)
        put("glowIntensity", glowIntensity.toDouble())
        put("shadow", shadow)
        put("border", border)
        put("borderColor", borderColor)
        put("showSeconds", showSeconds)
        put("showDate", showDate)
        put("showDay", showDay)
        put("is24Hour", is24Hour)
        put("animationStyle", animationStyle.name)
        put("animationSpeedMultiplier", animationSpeedMultiplier.toDouble())
        put("handStyle", handStyle.name)
        put("numberStyle", numberStyle.name)
        put("markerStyle", markerStyle.name)
        put("isFavorite", isFavorite)
    }

    companion object {
        fun fromJson(json: JSONObject): ClockConfig {
            val colorsArray = json.getJSONArray("backgroundColors")
            val colors = (0 until colorsArray.length()).map { colorsArray.getLong(it) }
            return ClockConfig(
                id = json.getString("id"),
                name = json.getString("name"),
                category = ClockCategory.valueOf(json.getString("category")),
                isCustom = json.getBoolean("isCustom"),
                createdAt = json.getLong("createdAt"),
                modifiedAt = json.getLong("modifiedAt"),
                font = ClockFont.valueOf(json.getString("font")),
                primaryColor = json.getLong("primaryColor"),
                secondaryColor = json.getLong("secondaryColor"),
                accentColor = json.getLong("accentColor"),
                backgroundStyle = BackgroundStyle.valueOf(json.getString("backgroundStyle")),
                backgroundColors = colors,
                gradientAngle = json.getDouble("gradientAngle").toFloat(),
                opacity = json.getDouble("opacity").toFloat(),
                glow = json.getBoolean("glow"),
                glowColor = json.getLong("glowColor"),
                glowIntensity = json.getDouble("glowIntensity").toFloat(),
                shadow = json.getBoolean("shadow"),
                border = json.getBoolean("border"),
                borderColor = json.getLong("borderColor"),
                showSeconds = json.getBoolean("showSeconds"),
                showDate = json.getBoolean("showDate"),
                showDay = json.getBoolean("showDay"),
                is24Hour = json.getBoolean("is24Hour"),
                animationStyle = AnimationStyle.valueOf(json.getString("animationStyle")),
                animationSpeedMultiplier = json.getDouble("animationSpeedMultiplier").toFloat(),
                handStyle = HandStyle.valueOf(json.getString("handStyle")),
                numberStyle = NumberStyle.valueOf(json.getString("numberStyle")),
                markerStyle = MarkerStyle.valueOf(json.getString("markerStyle")),
                isFavorite = json.getBoolean("isFavorite")
            )
        }
    }
}
