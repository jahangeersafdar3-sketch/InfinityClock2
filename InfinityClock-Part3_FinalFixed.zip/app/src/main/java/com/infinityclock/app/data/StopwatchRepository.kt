package com.infinityclock.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclock.app.stopwatch.StopwatchState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.stopwatchDataStore by preferencesDataStore(name = "infinity_clock_stopwatch")

/** Persists stopwatch state so it survives process death/app restart (Part 3, "use elapsed time correctly"). */
class StopwatchRepository(private val context: Context) {
    private val key = stringPreferencesKey("stopwatch_state_json")

    val stateFlow: Flow<StopwatchState> = context.stopwatchDataStore.data.map { prefs ->
        prefs[key]?.let { StopwatchState.fromJson(JSONObject(it)) } ?: StopwatchState()
    }

    suspend fun save(state: StopwatchState) {
        context.stopwatchDataStore.edit { it[key] = state.toJson().toString() }
    }

    suspend fun current(): StopwatchState = stateFlow.first()
}
