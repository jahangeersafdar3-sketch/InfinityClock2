package com.infinityclock.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.infinityclock.app.MainActivity
import com.infinityclock.app.alarm.model.AlarmItem
import com.infinityclock.app.alarm.receivers.AlarmFireReceiver
import java.util.Calendar

/**
 * Computes the next real trigger time for an alarm (honoring repeat days,
 * or the next occurrence of that time-of-day for a one-shot alarm) using
 * Calendar, which applies the device's current timezone/DST rules
 * automatically, and schedules it with AlarmManager.setAlarmClock() — the
 * one AlarmManager API specifically meant for real alarm-clock apps: it's
 * always exact and always exempt from Doze/battery restrictions, with no
 * extra permission needed, unlike setExact/setExactAndAllowWhileIdle.
 */
object AlarmScheduler {

    fun nextTriggerMillis(alarm: AlarmItem, fromMillis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = fromMillis
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (alarm.repeatDays.isEmpty()) {
            if (cal.timeInMillis <= fromMillis) cal.add(Calendar.DAY_OF_YEAR, 1)
            return cal.timeInMillis
        }

        // Repeating: find the next day-of-week (today included, if the time hasn't passed yet) in repeatDays.
        for (offset in 0..7) {
            val candidate = cal.clone() as Calendar
            candidate.add(Calendar.DAY_OF_YEAR, offset)
            val dow = candidate.get(Calendar.DAY_OF_WEEK)
            if (dow in alarm.repeatDays && candidate.timeInMillis > fromMillis) {
                return candidate.timeInMillis
            }
        }
        // Fallback (shouldn't happen given the 0..7 sweep above).
        cal.add(Calendar.DAY_OF_YEAR, 7)
        return cal.timeInMillis
    }

    private fun firePendingIntent(context: Context, alarm: AlarmItem): PendingIntent {
        val intent = Intent(context, AlarmFireReceiver::class.java).apply {
            action = AlarmFireReceiver.ACTION_ALARM_FIRE
            putExtra(AlarmFireReceiver.EXTRA_ALARM_ID, alarm.id)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(context, alarm.requestCode, intent, flags)
    }

    private fun showPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getActivity(context, 0, intent, flags)
    }

    fun schedule(context: Context, alarm: AlarmItem) {
        if (!alarm.enabled) {
            cancel(context, alarm)
            return
        }
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val triggerAt = nextTriggerMillis(alarm)
        alarmManager.setAlarmClock(
            AlarmManager.AlarmClockInfo(triggerAt, showPendingIntent(context)),
            firePendingIntent(context, alarm)
        )
    }

    fun cancel(context: Context, alarm: AlarmItem) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        alarmManager.cancel(firePendingIntent(context, alarm))
    }

    fun scheduleSnooze(context: Context, alarm: AlarmItem, minutesFromNow: Int = 5) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val triggerAt = System.currentTimeMillis() + minutesFromNow * 60_000L
        alarmManager.setAlarmClock(
            AlarmManager.AlarmClockInfo(triggerAt, showPendingIntent(context)),
            firePendingIntent(context, alarm)
        )
    }
}
