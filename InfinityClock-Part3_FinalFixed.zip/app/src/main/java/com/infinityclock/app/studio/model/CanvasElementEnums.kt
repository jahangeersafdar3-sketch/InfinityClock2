package com.infinityclock.app.studio.model

enum class ElementType {
    HOURS, MINUTES, SECONDS, DATE, DAY, MONTH, CUSTOM_TEXT,
    SHAPE_RECT, SHAPE_CIRCLE, SHAPE_LINE,
    BACKGROUND, DECORATIVE, PARTICLES, GLOW_ORB
}

/** True for elements whose displayed text comes from the live clock, not user input. */
fun ElementType.isTimeBound(): Boolean = this in setOf(
    ElementType.HOURS, ElementType.MINUTES, ElementType.SECONDS,
    ElementType.DATE, ElementType.DAY, ElementType.MONTH
)

fun ElementType.isText(): Boolean = isTimeBound() || this == ElementType.CUSTOM_TEXT
fun ElementType.isShape(): Boolean = this in setOf(ElementType.SHAPE_RECT, ElementType.SHAPE_CIRCLE, ElementType.SHAPE_LINE)

enum class ElementFont { SYSTEM, MONO, SERIF, CONDENSED, ROUNDED }

enum class ElementAnimationPreset {
    NONE, FADE, SCALE, PULSE, GLOW, ROTATION, SLIDE,
    LIGHT_SWEEP, BREATHING, GRADIENT_FLOW, PARTICLE, NUMBER_TRANSITION
}
