package com.infinityclock.app.ui.create

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FileCopy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.infinityclock.app.studio.render.StudioClockPreview
import com.infinityclock.app.viewmodel.AppViewModel

/**
 * The Part 2 "Create" tab landing screen: a real Clock Studio entry point
 * plus the original Part 1 quick-parameter customizer, so nothing from
 * Part 1 is removed — it's simply one of two ways to build a clock now.
 */
@Composable
fun CreateHubScreen(
    viewModel: AppViewModel,
    onQuickCustomize: () -> Unit,
    onOpenStudio: (String) -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val studioClocks by viewModel.studioClocks.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("Create") }) }) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                EntryCard(
                    title = "Clock Studio",
                    subtitle = "Design a clock from scratch — add hands, text, shapes, and effects, then move, resize and rotate them freely.",
                    icon = Icons.Filled.AutoAwesome,
                    onClick = { onOpenStudio("new") }
                )
            }
            item {
                EntryCard(
                    title = "Quick Customize",
                    subtitle = "Start from any preset's colors, background and animation — the fast way to make a custom clock.",
                    icon = Icons.Filled.Tune,
                    onClick = onQuickCustomize
                )
            }

            item {
                Spacer(Modifier.height(4.dp))
                Text("Your Studio Clocks", style = MaterialTheme.typography.titleMedium)
            }

            if (studioClocks.isEmpty()) {
                item {
                    Text(
                        "None yet — tap Clock Studio above to design your first one.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(studioClocks, key = { it.id }) { studio ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenStudio(studio.id) },
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.foundation.layout.Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .height(64.dp)
                            ) {
                                StudioClockPreview(config = studio, quality = settings.animationQuality)
                            }
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 12.dp)
                            ) {
                                Text(studio.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                Text(
                                    "${studio.elements.size} elements",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { viewModel.toggleStudioFavorite(studio.id) }) {
                                Icon(
                                    imageVector = if (studio.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (studio.isFavorite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { viewModel.duplicateStudioClock(studio) {} }) {
                                Icon(Icons.Filled.FileCopy, contentDescription = "Duplicate")
                            }
                            IconButton(onClick = { viewModel.deleteStudioClock(studio.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }
    }
}

// (uses androidx.compose.foundation.lazy.items for the studioClocks list above)

@Composable
private fun EntryCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
