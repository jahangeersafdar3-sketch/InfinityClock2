package com.infinityclock.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.infinityclock.app.ui.alarm.AlarmsScreen
import com.infinityclock.app.ui.create.CreateHubScreen
import com.infinityclock.app.ui.create.CreateScreen
import com.infinityclock.app.ui.gallery.GalleryScreen
import com.infinityclock.app.ui.home.HomeScreen
import com.infinityclock.app.ui.phone.ControlCenterScreen
import com.infinityclock.app.ui.settings.SettingsScreen
import com.infinityclock.app.ui.stopwatch.StopwatchScreen
import com.infinityclock.app.ui.studio.StudioScreen
import com.infinityclock.app.ui.timer.TimerScreen
import com.infinityclock.app.ui.widgets.WidgetsScreen
import com.infinityclock.app.ui.worldclock.WorldClockScreen
import com.infinityclock.app.viewmodel.AppViewModel

private fun iconFor(screen: Screen) = when (screen) {
    Screen.Home -> Icons.Filled.Home
    Screen.Gallery -> Icons.Outlined.GridView
    Screen.Create -> Icons.Filled.AddCircle
    Screen.UseOnPhone -> Icons.Filled.Widgets
    Screen.Settings -> Icons.Filled.Settings
}

@Composable
fun InfinityClockApp(viewModel: AppViewModel = viewModel()) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = { InfinityBottomBar(navController) }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = viewModel,
                    onOpenGallery = { navController.navigate(Screen.Gallery.route) },
                    onOpenCreate = { navController.navigate(editClockRoute("new")) },
                    onOpenSettings = { navController.navigate(Screen.Settings.route) }
                )
            }
            composable(Screen.Gallery.route) {
                GalleryScreen(
                    viewModel = viewModel,
                    onEditClock = { id -> navController.navigate(editClockRoute(id)) },
                    onEditStudioClock = { id -> navController.navigate(studioRoute(id)) }
                )
            }
            composable(Screen.Create.route) {
                CreateHubScreen(
                    viewModel = viewModel,
                    onQuickCustomize = { navController.navigate(editClockRoute("new")) },
                    onOpenStudio = { id -> navController.navigate(studioRoute(id)) }
                )
            }
            composable(EDIT_CLOCK_ROUTE) { backStackEntry ->
                val clockId = backStackEntry.arguments?.getString("clockId") ?: "new"
                CreateScreen(viewModel = viewModel, clockId = clockId, onDone = { navController.popBackStack() })
            }
            composable(STUDIO_ROUTE) { backStackEntry ->
                val studioId = backStackEntry.arguments?.getString("studioId") ?: "new"
                StudioScreen(appViewModel = viewModel, studioId = studioId, onDone = { navController.popBackStack() })
            }

            // Part 3 "Use on Phone" control center + its feature screens.
            composable(Screen.UseOnPhone.route) {
                ControlCenterScreen(
                    onOpenWidgets = { navController.navigate(WIDGETS_DETAIL_ROUTE) },
                    onOpenAlarms = { navController.navigate(ALARMS_ROUTE) },
                    onOpenTimer = { navController.navigate(TIMER_ROUTE) },
                    onOpenStopwatch = { navController.navigate(STOPWATCH_ROUTE) },
                    onOpenWorldClock = { navController.navigate(WORLD_CLOCK_ROUTE) }
                )
            }
            composable(WIDGETS_DETAIL_ROUTE) { WidgetsScreen(viewModel = viewModel) }
            composable(ALARMS_ROUTE) { AlarmsScreen(onBack = { navController.popBackStack() }) }
            composable(TIMER_ROUTE) { TimerScreen(onBack = { navController.popBackStack() }) }
            composable(STOPWATCH_ROUTE) { StopwatchScreen(onBack = { navController.popBackStack() }) }
            composable(WORLD_CLOCK_ROUTE) { WorldClockScreen(onBack = { navController.popBackStack() }) }

            composable(Screen.Settings.route) { SettingsScreen(viewModel = viewModel) }
        }
    }
}

@Composable
private fun InfinityBottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination

    NavigationBar {
        Screen.bottomBarScreens.forEach { screen ->
            val selected = currentRoute?.hierarchy?.any { it.route == screen.route } == true
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(iconFor(screen), contentDescription = screen.label) },
                label = { Text(screen.label) }
            )
        }
    }
}
