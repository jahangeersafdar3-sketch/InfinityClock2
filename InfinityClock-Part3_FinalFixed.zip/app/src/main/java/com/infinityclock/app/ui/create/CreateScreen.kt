package com.infinityclock.app.ui.create

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.infinityclock.app.clock.engine.ClockEngine
import com.infinityclock.app.clock.model.*
import com.infinityclock.app.clock.presets.CuratedPalettes
import com.infinityclock.app.clock.presets.Palette
import com.infinityclock.app.viewmodel.AppViewModel

private fun defaultNewConfig(): ClockConfig = ClockConfig(
    name = "My Clock",
    category = ClockCategory.DIGITAL_MINIMAL,
    isCustom = true,
    primaryColor = CuratedPalettes[0].primary,
    secondaryColor = CuratedPalettes[0].secondary,
    accentColor = CuratedPalettes[0].accent
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateScreen(
    viewModel: AppViewModel,
    clockId: String,
    onDone: () -> Unit
) {
    val allClocks by viewModel.allClocks.collectAsState()
    val settings by viewModel.settings.collectAsState()

    val original = remember(clockId, allClocks) {
        if (clockId == "new") defaultNewConfig() else allClocks.firstOrNull { it.id == clockId } ?: defaultNewConfig()
    }

    var config by remember(clockId) { mutableStateOf(original) }
    var fullscreenPreview by remember { mutableStateOf(false) }
    var showSaveAsDialog by remember { mutableStateOf(false) }
    var saveAsName by remember { mutableStateOf("${original.name} Copy") }

    if (fullscreenPreview) {
        Box(modifier = Modifier.fillMaxSize()) {
            ClockEngine(config = config, quality = settings.animationQuality, modifier = Modifier.fillMaxSize())
            OutlinedButton(
                onClick = { fullscreenPreview = false },
                modifier = Modifier.padding(24.dp)
            ) { Text("Exit Preview") }
        }
        return
    }

    if (showSaveAsDialog) {
        AlertDialog(
            onDismissRequest = { showSaveAsDialog = false },
            title = { Text("Save As New Clock") },
            text = {
                OutlinedTextField(
                    value = saveAsName,
                    onValueChange = { saveAsName = it },
                    label = { Text("Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    val copy = config.copy(
                        id = java.util.UUID.randomUUID().toString(),
                        name = saveAsName.ifBlank { "My Clock" },
                        isCustom = true,
                        createdAt = System.currentTimeMillis(),
                        modifiedAt = System.currentTimeMillis()
                    )
                    viewModel.saveCustomClock(copy, applyImmediately = true)
                    showSaveAsDialog = false
                    onDone()
                }) { Text("Save") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showSaveAsDialog = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text(if (clockId == "new") "Create Clock" else "Customize Clock") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(24.dp))
                    ) {
                        ClockEngine(config = config, quality = settings.animationQuality, modifier = Modifier.fillMaxWidth())
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = config.name,
                    onValueChange = { config = config.copy(name = it, modifiedAt = System.currentTimeMillis()) },
                    label = { Text("Clock Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item { SectionLabel("Clock Type") }
            item {
                ChipRow(ClockType.values().toList(), { it == config.type }, { it.name }) { type ->
                    val newCategory = when (type) {
                        ClockType.DIGITAL -> ClockCategory.DIGITAL_MINIMAL
                        ClockType.ANALOG -> ClockCategory.ANALOG_CLASSIC
                        ClockType.HYBRID -> ClockCategory.HYBRID_ANALOG_DIGITAL
                    }
                    config = config.copy(category = newCategory, modifiedAt = System.currentTimeMillis())
                }
            }

            item { SectionLabel("Color Palette") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(CuratedPalettes) { pal: Palette ->
                        PaletteSwatch(
                            palette = pal,
                            selected = config.primaryColor == pal.primary,
                            onClick = {
                                config = config.copy(
                                    primaryColor = pal.primary,
                                    secondaryColor = pal.secondary,
                                    accentColor = pal.accent,
                                    glowColor = pal.glow,
                                    modifiedAt = System.currentTimeMillis()
                                )
                            }
                        )
                    }
                }
            }

            item { SectionLabel("Background") }
            item {
                ChipRow(BackgroundStyle.values().toList(), { it == config.backgroundStyle }, { it.name.replace('_', ' ') }) {
                    config = config.copy(backgroundStyle = it, modifiedAt = System.currentTimeMillis())
                }
            }

            item { SectionLabel("Animation") }
            item {
                ChipRow(AnimationStyle.values().toList(), { it == config.animationStyle }, { it.name.replace('_', ' ') }) {
                    config = config.copy(animationStyle = it, modifiedAt = System.currentTimeMillis())
                }
            }
            item {
                LabeledSlider(
                    label = "Animation speed (${String.format("%.1fx", config.animationSpeedMultiplier)})",
                    value = config.animationSpeedMultiplier,
                    range = 0.25f..2.5f
                ) { config = config.copy(animationSpeedMultiplier = it, modifiedAt = System.currentTimeMillis()) }
            }

            if (config.type != ClockType.DIGITAL) {
                item { SectionLabel("Hand Style") }
                item {
                    ChipRow(HandStyle.values().toList(), { it == config.handStyle }, { it.name }) {
                        config = config.copy(handStyle = it, modifiedAt = System.currentTimeMillis())
                    }
                }
                item { SectionLabel("Number Style") }
                item {
                    ChipRow(NumberStyle.values().toList(), { it == config.numberStyle }, { it.name.replace('_', ' ') }) {
                        config = config.copy(numberStyle = it, modifiedAt = System.currentTimeMillis())
                    }
                }
                item { SectionLabel("Marker Style") }
                item {
                    ChipRow(MarkerStyle.values().toList(), { it == config.markerStyle }, { it.name }) {
                        config = config.copy(markerStyle = it, modifiedAt = System.currentTimeMillis())
                    }
                }
            }

            item { SectionLabel("Effects & Layout") }
            item {
                Column {
                    ToggleRow("Glow", config.glow) { config = config.copy(glow = it, modifiedAt = System.currentTimeMillis()) }
                    ToggleRow("Shadow", config.shadow) { config = config.copy(shadow = it, modifiedAt = System.currentTimeMillis()) }
                    ToggleRow("Border", config.border) { config = config.copy(border = it, modifiedAt = System.currentTimeMillis()) }
                    ToggleRow("Show Seconds", config.showSeconds) { config = config.copy(showSeconds = it, modifiedAt = System.currentTimeMillis()) }
                    ToggleRow("Show Date", config.showDate) { config = config.copy(showDate = it, modifiedAt = System.currentTimeMillis()) }
                    ToggleRow("Show Day", config.showDay) { config = config.copy(showDay = it, modifiedAt = System.currentTimeMillis()) }
                    ToggleRow("24-Hour Format", config.is24Hour) { config = config.copy(is24Hour = it, modifiedAt = System.currentTimeMillis()) }
                }
            }

            item {
                LabeledSlider(
                    label = "Opacity (${(config.opacity * 100).toInt()}%)",
                    value = config.opacity,
                    range = 0.4f..1f
                ) { config = config.copy(opacity = it, modifiedAt = System.currentTimeMillis()) }
            }

            if (config.glow) {
                item {
                    LabeledSlider(
                        label = "Glow intensity (${(config.glowIntensity * 100).toInt()}%)",
                        value = config.glowIntensity,
                        range = 0.1f..1f
                    ) { config = config.copy(glowIntensity = it, modifiedAt = System.currentTimeMillis()) }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { config = original }, modifier = Modifier.weight(1f)) { Text("Reset") }
                    OutlinedButton(onClick = { fullscreenPreview = true }, modifier = Modifier.weight(1f)) { Text("Preview") }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDone, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    OutlinedButton(
                        onClick = { saveAsName = "${config.name} Copy"; showSaveAsDialog = true },
                        modifier = Modifier.weight(1f)
                    ) { Text("Save As") }
                    Button(
                        onClick = {
                            val toSave = config.copy(isCustom = true, modifiedAt = System.currentTimeMillis())
                            viewModel.saveCustomClock(toSave, applyImmediately = true)
                            onDone()
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Save") }
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium)
}

@Composable
private fun <T> ChipRow(
    values: List<T>,
    isSelected: (T) -> Boolean,
    label: (T) -> String,
    onSelect: (T) -> Unit
) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(values) { value ->
            FilterChip(
                selected = isSelected(value),
                onClick = { onSelect(value) },
                label = { Text(label(value)) }
            )
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun PaletteSwatch(palette: Palette, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
        ) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        listOf(Color(palette.primary), Color(palette.secondary))
                    )
                )
                if (selected) {
                    drawCircle(
                        color = Color.White,
                        radius = size.minDimension / 2f,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                    )
                }
            }
        }
        Text(palette.name, style = MaterialTheme.typography.labelSmall)
    }
}
