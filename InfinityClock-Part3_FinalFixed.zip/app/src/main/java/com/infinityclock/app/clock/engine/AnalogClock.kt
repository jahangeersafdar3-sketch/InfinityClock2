package com.infinityclock.app.clock.engine

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.model.AnimationStyle
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.clock.model.HandStyle
import com.infinityclock.app.clock.model.MarkerStyle
import com.infinityclock.app.clock.model.NumberStyle
import com.infinityclock.app.clock.util.TickTime
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val romanNumerals = arrayOf("XII", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI")

/**
 * All three hands are computed directly from the real TickTime every
 * recomposition (including sub-second fraction for a genuinely smooth sweep
 * second hand) — there is no separately-driven animation clock that could
 * drift from the actual time.
 */
@Composable
fun AnalogClockFace(
    config: ClockConfig,
    time: TickTime,
    quality: AnimationQuality,
    modifier: Modifier = Modifier
) {
    val primary = Color(config.primaryColor)
    val secondary = Color(config.secondaryColor)
    val accent = Color(config.accentColor)
    val smoothSweep = config.animationStyle == AnimationStyle.SMOOTH_SWEEP &&
        quality != AnimationQuality.BATTERY_SAVER

    val secondsFraction = if (smoothSweep) {
        time.second + time.millisWithinSecond / 1000f
    } else {
        time.second.toFloat()
    }
    val minuteFraction = time.minute + secondsFraction / 60f
    val hourFraction = (time.hour24 % 12) + minuteFraction / 60f

    val secondAngle = secondsFraction / 60f * 360f
    val minuteAngle = minuteFraction / 60f * 360f
    val hourAngle = hourFraction / 12f * 360f

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .padding(24.dp)
    ) {
        val radius = min(size.width, size.height) / 2f
        val center = Offset(size.width / 2f, size.height / 2f)

        drawDial(config, radius, center, primary, secondary)
        drawMarkers(config.markerStyle, radius, center, secondary)
        if (config.numberStyle != NumberStyle.TICKS_ONLY) {
            drawNumbers(config.numberStyle, radius, center, secondary)
        }

        drawHand(center, hourAngle, radius * 0.5f, 7f, primary, config.handStyle)
        drawHand(center, minuteAngle, radius * 0.72f, 5f, primary, config.handStyle)
        drawHand(center, secondAngle, radius * 0.85f, 2.5f, accent, HandStyle.NEEDLE)

        drawCircle(color = accent, radius = 7f, center = center)
        drawCircle(color = primary, radius = 3f, center = center)
    }
}

private fun DrawScope.drawDial(
    config: ClockConfig,
    radius: Float,
    center: Offset,
    primary: Color,
    secondary: Color
) {
    drawCircle(color = secondary.copy(alpha = 0.08f), radius = radius, center = center)
    drawCircle(
        color = primary.copy(alpha = if (config.border) 0.9f else 0.35f),
        radius = radius,
        center = center,
        style = Stroke(width = if (config.border) 5f else 2.5f)
    )
}

private fun DrawScope.drawMarkers(style: MarkerStyle, radius: Float, center: Offset, color: Color) {
    if (style == MarkerStyle.NONE) return
    for (i in 0 until 60) {
        val isMajor = i % 5 == 0
        val angle = (i / 60f) * 2 * PI.toFloat() - PI.toFloat() / 2f
        val outer = radius * 0.94f
        val inner = radius * if (isMajor) 0.82f else 0.90f
        val from = Offset(center.x + cos(angle) * inner, center.y + sin(angle) * inner)
        val to = Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer)
        if (!isMajor && style != MarkerStyle.TICKS && style != MarkerStyle.LINES) continue

        when (style) {
            MarkerStyle.DOTS -> if (isMajor) drawCircle(color, radius = 4f, center = to)
            MarkerStyle.DIAMONDS -> if (isMajor) drawCircle(color, radius = 5f, center = to)
            else -> drawLine(color, from, to, strokeWidth = if (isMajor) 4f else 1.5f, cap = StrokeCap.Round)
        }
    }
}

private fun DrawScope.drawNumbers(style: NumberStyle, radius: Float, center: Offset, color: Color) {
    // Numeral rendering uses native text drawing via drawContext.canvas so we
    // stay inside a single DrawScope without an extra Compose Text overlay.
    val paint = android.graphics.Paint().apply {
        this.color = color.toArgbCompat()
        textAlign = android.graphics.Paint.Align.CENTER
        textSize = radius * 0.16f
        isAntiAlias = true
    }
    for (i in 0 until 12) {
        val angle = (i / 12f) * 2 * PI.toFloat() - PI.toFloat() / 2f
        val r = radius * 0.7f
        val x = center.x + cos(angle) * r
        val y = center.y + sin(angle) * r + paint.textSize / 3f
        val label = when (style) {
            NumberStyle.ROMAN -> romanNumerals[i]
            NumberStyle.ARABIC_ART_DECO -> (if (i == 0) 12 else i).toString()
            else -> (if (i == 0) 12 else i).toString()
        }
        drawContext.canvas.nativeCanvas.drawText(label, x, y, paint)
    }
}

private fun Color.toArgbCompat(): Int {
    return android.graphics.Color.argb(
        (alpha * 255).toInt(),
        (red * 255).toInt(),
        (green * 255).toInt(),
        (blue * 255).toInt()
    )
}

private fun DrawScope.drawHand(
    center: Offset,
    angleDegrees: Float,
    length: Float,
    width: Float,
    color: Color,
    style: HandStyle
) {
    val angle = (angleDegrees - 90f) * PI.toFloat() / 180f
    val tip = Offset(center.x + cos(angle) * length, center.y + sin(angle) * length)
    val tailLength = length * 0.15f
    val tail = Offset(center.x - cos(angle) * tailLength, center.y - sin(angle) * tailLength)

    when (style) {
        HandStyle.SKELETON -> drawLine(color.copy(alpha = 0.7f), tail, tip, strokeWidth = width * 0.6f, cap = StrokeCap.Round)
        HandStyle.SWORD, HandStyle.DIAMOND -> {
            drawLine(color, tail, tip, strokeWidth = width, cap = StrokeCap.Round)
            drawCircle(color, radius = width * 0.9f, center = Offset(center.x + cos(angle) * length * 0.6f, center.y + sin(angle) * length * 0.6f))
        }
        HandStyle.BLOCK -> drawLine(color, tail, tip, strokeWidth = width * 1.6f, cap = StrokeCap.Butt)
        HandStyle.NEEDLE -> drawLine(color, tail, tip, strokeWidth = width * 0.5f, cap = StrokeCap.Round)
        HandStyle.CLASSIC -> drawLine(color, tail, tip, strokeWidth = width, cap = StrokeCap.Round)
    }
}
