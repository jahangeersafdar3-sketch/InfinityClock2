package com.infinityclock.app.alarm.ui

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclock.app.alarm.AlarmScheduler
import com.infinityclock.app.alarm.model.AlarmItem
import com.infinityclock.app.data.AlarmRepository
import com.infinityclock.app.notif.AlertPlayer
import com.infinityclock.app.theme.InfinityClockTheme

/**
 * The real alarm-ringing screen: shows over the lock screen and turns the
 * screen on (the documented Activity APIs for this, not a private/hidden
 * API), plays the alert sound + vibration, and offers genuine Snooze/
 * Dismiss actions.
 */
class AlarmRingingActivity : ComponentActivity() {

    private var alertPlayer: AlertPlayer? = null
    private var alarm: AlarmItem? = null

    companion object {
        const val EXTRA_ALARM_ID = "com.infinityclock.app.alarm.EXTRA_ALARM_ID"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val alarmId = intent?.getStringExtra(EXTRA_ALARM_ID)
        val repository = AlarmRepository(this)

        setContent {
            var loadedAlarm by remember { mutableStateOf<AlarmItem?>(null) }

            androidx.compose.runtime.LaunchedEffect(alarmId) {
                if (alarmId != null) {
                    val found = repository.all().firstOrNull { it.id == alarmId }
                    alarm = found
                    loadedAlarm = found
                    val player = AlertPlayer(this@AlarmRingingActivity)
                    alertPlayer = player
                    player.start(sound = found?.soundEnabled ?: true, vibrate = found?.vibrate ?: true, useAlarmSound = true)
                }
            }

            InfinityClockTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AlarmRingingContent(
                        alarm = loadedAlarm,
                        onSnooze = { snoozeAndFinish() },
                        onDismiss = { dismissAndFinish() }
                    )
                }
            }
        }
    }

    private fun snoozeAndFinish() {
        alertPlayer?.stop()
        val current = alarm
        if (current != null) {
            AlarmScheduler.scheduleSnooze(this, current, minutesFromNow = 5)
        }
        finish()
    }

    private fun dismissAndFinish() {
        alertPlayer?.stop()
        // Repeating alarms already had their next occurrence scheduled by
        // AlarmFireReceiver when this one fired; one-shot alarms were
        // already marked disabled there too. Nothing further to do here.
        finish()
    }

    override fun onDestroy() {
        alertPlayer?.stop()
        super.onDestroy()
    }
}

@androidx.compose.runtime.Composable
private fun AlarmRingingContent(alarm: AlarmItem?, onSnooze: () -> Unit, onDismiss: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = alarm?.let { "%02d:%02d".format(it.hour, it.minute) } ?: "Alarm",
            fontSize = 64.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = alarm?.label ?: "Alarm",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(top = 8.dp, bottom = 48.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            OutlinedButton(onClick = onSnooze) { Text("Snooze 5 min") }
            Button(onClick = onDismiss) { Text("Dismiss") }
        }
    }
}
