package com.infinityclock.app.ui.stopwatch

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.infinityclock.app.stopwatch.formatElapsed
import com.infinityclock.app.viewmodel.StopwatchViewModel
import kotlinx.coroutines.delay

@Composable
fun StopwatchScreen(onBack: () -> Unit, viewModel: StopwatchViewModel = viewModel()) {
    val state by viewModel.state.collectAsState()
    var displayMillis by remember { mutableLongStateOf(viewModel.currentElapsedMillis()) }

    LaunchedEffect(state.running) {
        while (state.running) {
            displayMillis = viewModel.currentElapsedMillis()
            delay(30)
        }
        displayMillis = viewModel.currentElapsedMillis()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Stopwatch") }) }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = formatElapsed(displayMillis),
                fontSize = 56.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 32.dp)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                if (state.running) {
                    Button(onClick = { viewModel.lap() }, modifier = Modifier.weight(1f)) { Text("Lap") }
                    Button(onClick = { viewModel.pause() }, modifier = Modifier.weight(1f)) { Text("Pause") }
                } else {
                    Button(onClick = { viewModel.start() }, modifier = Modifier.weight(1f)) {
                        Text(if (state.accumulatedMillis > 0) "Resume" else "Start")
                    }
                    OutlinedButton(onClick = { viewModel.reset() }, modifier = Modifier.weight(1f)) { Text("Reset") }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            if (state.laps.isEmpty()) {
                Text("No laps yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    val laps = state.laps
                    items(laps.size) { index ->
                        val lapNumber = index + 1
                        val lapTime = laps[index]
                        val splitTime = if (index == 0) laps[0] else laps[index] - laps[index - 1]
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Lap $lapNumber")
                            Text("+${formatElapsed(splitTime)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatElapsed(lapTime))
                        }
                    }
                }
            }
        }
    }
}
