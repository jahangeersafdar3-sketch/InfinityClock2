package com.infinityclock.app.clock.util

fun TickTime.timeString(is24Hour: Boolean, showSeconds: Boolean): String {
    val h = if (is24Hour) hour24 else hour12
    val hh = h.toString().padStart(2, '0')
    val mm = minute.toString().padStart(2, '0')
    return if (showSeconds) {
        val ss = second.toString().padStart(2, '0')
        "$hh:$mm:$ss"
    } else {
        "$hh:$mm"
    }
}

fun TickTime.amPm(): String = if (hour24 < 12) "AM" else "PM"

fun TickTime.dateString(): String = "$month $dayOfMonth, $year"

fun TickTime.shortDateString(): String = "$dayOfMonth ${month.take(3)}"
