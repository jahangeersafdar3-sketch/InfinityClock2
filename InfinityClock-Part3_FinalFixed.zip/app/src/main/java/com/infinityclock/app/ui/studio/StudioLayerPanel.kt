package com.infinityclock.app.ui.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.infinityclock.app.studio.model.CanvasElement

/**
 * The Part 2 "Layer System" panel: select / reorder (up/down) / hide-show /
 * duplicate / delete, all backed by real StudioViewModel mutations. Listed
 * top layer first (highest zIndex at the top), matching how design tools
 * conventionally order layers.
 */
@Composable
fun StudioLayerPanel(
    elements: List<CanvasElement>,
    selectedId: String?,
    onSelect: (String) -> Unit,
    onToggleVisibility: (String) -> Unit,
    onMoveUp: (String) -> Unit,
    onMoveDown: (String) -> Unit,
    onDuplicate: (String) -> Unit,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val sorted = elements.sortedByDescending { it.zIndex }
    LazyColumn(modifier = modifier) {
        items(sorted, key = { it.id }) { element ->
            val isSelected = element.id == selectedId
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(element.id) }
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                        RoundedCornerShape(10.dp)
                    )
                    .padding(vertical = 4.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = element.name,
                    style = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (!element.visible) TextDecoration.LineThrough else null,
                    color = if (!element.visible) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(start = 8.dp)
                )
                Row {
                    IconButton(onClick = { onToggleVisibility(element.id) }) {
                        Icon(
                            if (element.visible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle visibility"
                        )
                    }
                    IconButton(onClick = { onMoveUp(element.id) }) {
                        Icon(Icons.Filled.ArrowUpward, contentDescription = "Move layer up")
                    }
                    IconButton(onClick = { onMoveDown(element.id) }) {
                        Icon(Icons.Filled.ArrowDownward, contentDescription = "Move layer down")
                    }
                    IconButton(onClick = { onDuplicate(element.id) }) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = "Duplicate")
                    }
                    IconButton(onClick = { onDelete(element.id) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete")
                    }
                }
            }
        }
    }
}
