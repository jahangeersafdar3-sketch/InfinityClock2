package com.infinityclock.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.infinityclock.app.data.StudioRepository
import com.infinityclock.app.studio.model.CanvasElement
import com.infinityclock.app.studio.model.ElementType
import com.infinityclock.app.studio.model.StudioClockConfig
import com.infinityclock.app.studio.model.defaultElement
import com.infinityclock.app.studio.undo.UndoRedoStack
import com.infinityclock.app.widget.WidgetUpdateScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Owns exactly one Clock Studio editing session (one StudioClockConfig plus
 * its undo/redo history and current selection). A fresh instance is created
 * per edited clock (see StudioScreen's `viewModel(key = studioId)`), so
 * switching between studio clocks never mixes up undo history.
 */
class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = StudioRepository(application)

    private val undoRedo = UndoRedoStack()

    private val _config = MutableStateFlow(StudioClockConfig.blank())
    val config: StateFlow<StudioClockConfig> = _config.asStateFlow()

    private val _selectedElementId = MutableStateFlow<String?>(null)
    val selectedElementId: StateFlow<String?> = _selectedElementId.asStateFlow()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()
    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    private var loadedExistingId: String? = null

    fun load(studioId: String, existing: StudioClockConfig?) {
        if (loadedExistingId == studioId) return
        loadedExistingId = studioId
        _config.value = existing ?: StudioClockConfig.blank()
        _selectedElementId.value = null
        undoRedo.clear()
        refreshUndoFlags()
    }

    private fun refreshUndoFlags() {
        _canUndo.value = undoRedo.canUndo
        _canRedo.value = undoRedo.canRedo
    }

    private fun mutateElements(transform: (List<CanvasElement>) -> List<CanvasElement>) {
        undoRedo.recordBeforeChange(_config.value.elements)
        _config.value = _config.value.copy(elements = transform(_config.value.elements), modifiedAt = System.currentTimeMillis())
        refreshUndoFlags()
    }

    /** Used by drag/resize/rotate gestures, which call this once per gesture before the first delta. */
    fun beginGesture() {
        undoRedo.recordBeforeChange(_config.value.elements)
        refreshUndoFlags()
    }

    /** Applies a live gesture update WITHOUT recording another undo step (the gesture already recorded one in beginGesture). */
    private fun applyLive(elementId: String, transform: (CanvasElement) -> CanvasElement) {
        _config.value = _config.value.copy(
            elements = _config.value.elements.map { if (it.id == elementId) transform(it) else it },
            modifiedAt = System.currentTimeMillis()
        )
    }

    fun moveElement(id: String, newX: Float, newY: Float) = applyLive(id) { it.copy(x = newX, y = newY) }
    fun resizeElement(id: String, newWidth: Float, newHeight: Float) = applyLive(id) { it.copy(width = newWidth, height = newHeight) }
    fun rotateElement(id: String, newRotation: Float) = applyLive(id) { it.copy(rotationDegrees = newRotation) }

    fun addElement(type: ElementType) {
        val nextZ = (_config.value.elements.maxOfOrNull { it.zIndex } ?: -1) + 1
        val newElement = defaultElement(type, nextZ)
        mutateElements { it + newElement }
        _selectedElementId.value = newElement.id
    }

    fun updateSelected(transform: (CanvasElement) -> CanvasElement) {
        val id = _selectedElementId.value ?: return
        mutateElements { list -> list.map { if (it.id == id) transform(it) else it } }
    }

    fun deleteElement(id: String) {
        mutateElements { list -> list.filterNot { it.id == id } }
        if (_selectedElementId.value == id) _selectedElementId.value = null
    }

    fun duplicateElement(id: String) {
        val nextZ = (_config.value.elements.maxOfOrNull { it.zIndex } ?: -1) + 1
        mutateElements { list ->
            val source = list.firstOrNull { it.id == id } ?: return@mutateElements list
            list + source.copy(id = java.util.UUID.randomUUID().toString(), name = "${source.name} Copy", zIndex = nextZ)
        }
    }

    fun renameElement(id: String, newName: String) {
        mutateElements { list -> list.map { if (it.id == id) it.copy(name = newName) else it } }
    }

    fun toggleVisibility(id: String) {
        mutateElements { list -> list.map { if (it.id == id) it.copy(visible = !it.visible) else it } }
    }

    fun moveLayerUp(id: String) {
        mutateElements { list ->
            val sorted = list.sortedBy { it.zIndex }
            val index = sorted.indexOfFirst { it.id == id }
            if (index < 0 || index == sorted.size - 1) return@mutateElements list
            val a = sorted[index]
            val b = sorted[index + 1]
            list.map {
                when (it.id) {
                    a.id -> it.copy(zIndex = b.zIndex)
                    b.id -> it.copy(zIndex = a.zIndex)
                    else -> it
                }
            }
        }
    }

    fun moveLayerDown(id: String) {
        mutateElements { list ->
            val sorted = list.sortedBy { it.zIndex }
            val index = sorted.indexOfFirst { it.id == id }
            if (index <= 0) return@mutateElements list
            val a = sorted[index]
            val b = sorted[index - 1]
            list.map {
                when (it.id) {
                    a.id -> it.copy(zIndex = b.zIndex)
                    b.id -> it.copy(zIndex = a.zIndex)
                    else -> it
                }
            }
        }
    }

    fun select(id: String?) {
        _selectedElementId.value = id
    }

    fun undo() {
        val restored = undoRedo.undo(_config.value.elements) ?: return
        _config.value = _config.value.copy(elements = restored)
        refreshUndoFlags()
    }

    fun redo() {
        val restored = undoRedo.redo(_config.value.elements) ?: return
        _config.value = _config.value.copy(elements = restored)
        refreshUndoFlags()
    }

    fun rename(newName: String) {
        _config.value = _config.value.copy(name = newName, modifiedAt = System.currentTimeMillis())
    }

    fun save(onSaved: (StudioClockConfig) -> Unit) {
        viewModelScope.launch {
            repository.save(_config.value)
            WidgetUpdateScheduler.requestUpdateForClock(getApplication(), _config.value.id)
            onSaved(_config.value)
        }
    }

    fun saveAs(newName: String, onSaved: (StudioClockConfig) -> Unit) {
        viewModelScope.launch {
            val copy = _config.value.copy(
                id = java.util.UUID.randomUUID().toString(),
                name = newName,
                createdAt = System.currentTimeMillis(),
                modifiedAt = System.currentTimeMillis()
            )
            repository.save(copy)
            onSaved(copy)
        }
    }
}
