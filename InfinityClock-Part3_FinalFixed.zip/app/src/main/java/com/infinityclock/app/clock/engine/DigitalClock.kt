package com.infinityclock.app.clock.engine

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.model.AnimationStyle
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.clock.model.ClockFont
import com.infinityclock.app.clock.util.TickTime
import com.infinityclock.app.clock.util.amPm
import com.infinityclock.app.clock.util.dateString
import com.infinityclock.app.clock.util.timeString

private fun fontFamilyFor(font: ClockFont): FontFamily = when (font) {
    ClockFont.SYSTEM -> FontFamily.SansSerif
    ClockFont.MONO -> FontFamily.Monospace
    ClockFont.SERIF -> FontFamily.Serif
    ClockFont.CONDENSED -> FontFamily.SansSerif
    ClockFont.ROUNDED -> FontFamily.SansSerif
}

@Composable
fun DigitalClockFace(
    config: ClockConfig,
    time: TickTime,
    quality: AnimationQuality,
    modifier: Modifier = Modifier
) {
    val primary = Color(config.primaryColor)
    val secondary = Color(config.secondaryColor)
    val animated = quality != AnimationQuality.BATTERY_SAVER

    val glowRadius by if (animated && config.glow) {
        val transition = rememberInfiniteTransition(label = "digitalGlow")
        transition.animateFloat(
            initialValue = 8f,
            targetValue = 26f * config.glowIntensity + 8f,
            animationSpec = infiniteRepeatable(
                animation = tween((1400 / config.animationSpeedMultiplier).toInt().coerceAtLeast(200), easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "glowRadius"
        )
    } else {
        androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(14f) }
    }

    val textStyle = TextStyle(
        fontFamily = fontFamilyFor(config.font),
        fontWeight = FontWeight.Bold,
        fontSize = 56.sp,
        color = primary.copy(alpha = config.opacity),
        shadow = if (config.glow) Shadow(color = Color(config.glowColor), blurRadius = glowRadius) else null
    )

    Column(
        modifier = modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val timeText = time.timeString(config.is24Hour, config.showSeconds)

        if (config.animationStyle == AnimationStyle.NUMBER_MORPH && animated) {
            AnimatedContent(
                targetState = timeText,
                label = "digitalMorph",
                transitionSpec = {
                    (slideInVertically { it / 2 } + fadeIn()) togetherWith
                        (slideOutVertically { -it / 2 } + fadeOut())
                }
            ) { text ->
                Text(text = text, style = textStyle)
            }
        } else {
            Text(text = timeText, style = textStyle)
        }

        if (!config.is24Hour) {
            Text(
                text = time.amPm(),
                style = textStyle.copy(fontSize = 16.sp, color = secondary.copy(alpha = config.opacity))
            )
        }
        if (config.showDate) {
            Text(
                text = if (config.showDay) "${time.dayOfWeek}, ${time.dateString()}" else time.dateString(),
                style = textStyle.copy(fontSize = 14.sp, fontWeight = FontWeight.Normal, color = secondary.copy(alpha = config.opacity), shadow = null)
            )
        }
    }
}
