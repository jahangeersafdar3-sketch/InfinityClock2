package com.infinityclock.app.studio.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * A custom clock built in the Clock Studio from CanvasElements. This is
 * intentionally a separate model from clock.model.ClockConfig (the Part 1
 * parametric preset model) — Part 1's designs and customization flow are
 * untouched; this is an additive, free-form design system.
 */
data class StudioClockConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val modifiedAt: Long = System.currentTimeMillis(),
    val elements: List<CanvasElement> = emptyList()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("isFavorite", isFavorite)
        put("createdAt", createdAt); put("modifiedAt", modifiedAt)
        val arr = JSONArray()
        elements.forEach { arr.put(it.toJson()) }
        put("elements", arr)
    }

    companion object {
        fun fromJson(j: JSONObject): StudioClockConfig {
            val arr = j.getJSONArray("elements")
            val elements = (0 until arr.length()).map { CanvasElement.fromJson(arr.getJSONObject(it)) }
            return StudioClockConfig(
                id = j.getString("id"), name = j.getString("name"),
                isFavorite = j.getBoolean("isFavorite"),
                createdAt = j.getLong("createdAt"), modifiedAt = j.getLong("modifiedAt"),
                elements = elements
            )
        }

        fun blank(name: String = "New Studio Clock"): StudioClockConfig {
            var z = 0
            val bg = defaultElement(ElementType.BACKGROUND, z++)
            val hours = defaultElement(ElementType.HOURS, z++).copy(y = 0.38f, fontSizeSp = 56f)
            val minutes = defaultElement(ElementType.MINUTES, z++).copy(y = 0.38f, x = 0.55f, fontSizeSp = 56f)
            return StudioClockConfig(name = name, elements = listOf(bg, hours, minutes))
        }
    }
}
