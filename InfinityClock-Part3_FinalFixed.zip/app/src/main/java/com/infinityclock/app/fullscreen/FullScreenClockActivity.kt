package com.infinityclock.app.fullscreen

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.offset
import com.infinityclock.app.burnin.BurnInShifter
import com.infinityclock.app.clock.engine.ClockEngine
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.clock.presets.buildPresetCatalog
import com.infinityclock.app.data.ClockRepository
import com.infinityclock.app.theme.InfinityClockTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first

enum class FullScreenMode { NORMAL, DIM, RED_NIGHT, AMOLED }

/**
 * The one real full-screen clock display, used by both "Bedside Clock" and
 * "Full Screen Clock" in the Control Center — they are honestly the same
 * feature with adjustable modes, not two separately-built screens pretending
 * to be different. Keeps the screen awake, supports portrait and landscape
 * (no locked orientation), includes real burn-in protection via
 * BurnInShifter, and a tap-to-reveal control overlay.
 */
class FullScreenClockActivity : ComponentActivity() {

    companion object {
        const val EXTRA_INITIAL_MODE = "com.infinityclock.app.EXTRA_INITIAL_MODE"
        const val EXTRA_BEDSIDE = "com.infinityclock.app.EXTRA_BEDSIDE"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val isBedside = intent?.getBooleanExtra(EXTRA_BEDSIDE, false) ?: false
        if (isBedside && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
        }

        val initialModeName = intent?.getStringExtra(EXTRA_INITIAL_MODE)
        val initialMode = runCatching { FullScreenMode.valueOf(initialModeName ?: "") }.getOrDefault(
            if (isBedside) FullScreenMode.DIM else FullScreenMode.NORMAL
        )

        setContent {
            InfinityClockTheme {
                FullScreenClockScreen(initialMode = initialMode, onExit = { finish() })
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun FullScreenClockScreen(initialMode: FullScreenMode, onExit: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var mode by remember { mutableStateOf(initialMode) }
    var controlsVisible by remember { mutableStateOf(true) }
    var clock by remember { mutableStateOf<ClockConfig?>(null) }

    LaunchedEffect(Unit) {
        val presets = buildPresetCatalog()
        val custom = ClockRepository(context).customClocksFlow.first()
        clock = (presets + custom).firstOrNull()
    }

    LaunchedEffect(controlsVisible) {
        if (controlsVisible) {
            delay(4000)
            controlsVisible = false
        }
    }

    val density = androidx.compose.ui.platform.LocalDensity.current
    val shifter = remember { BurnInShifter(maxRangePx = with(density) { 16.dp.toPx() }, shiftIntervalMillis = 5 * 60_000L) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        while (true) {
            shifter.update(System.currentTimeMillis())
            offsetX = shifter.currentOffsetX
            offsetY = shifter.currentOffsetY
            delay(200)
        }
    }

    val backgroundColor = when (mode) {
        FullScreenMode.NORMAL, FullScreenMode.DIM -> Color.Black
        FullScreenMode.RED_NIGHT -> Color.Black
        FullScreenMode.AMOLED -> Color.Black
    }

    Surface(color = backgroundColor, modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable { controlsVisible = true }
        ) {
            val current = clock
            if (current != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .offset { IntOffset(offsetX.toInt(), offsetY.toInt()) }
                ) {
                    ClockEngine(config = current, quality = AnimationQuality.BALANCED, modifier = Modifier.fillMaxSize())
                }
            }

            // Dim / red-night scrims are drawn as simple overlays rather than
            // altering every clock preset's own colors, so any clock design
            // still works correctly under these modes.
            when (mode) {
                FullScreenMode.DIM -> Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)))
                FullScreenMode.RED_NIGHT -> Box(modifier = Modifier.fillMaxSize().background(Color(0xFF200000).copy(alpha = 0.75f)))
                else -> {}
            }

            AnimatedVisibility(
                visible = controlsVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp)
            ) {
                Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                    FullScreenMode.values().forEach { m ->
                        FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.name.replace('_', ' ')) })
                    }
                    Button(onClick = onExit) { Text("Exit") }
                }
            }
        }
    }
}
