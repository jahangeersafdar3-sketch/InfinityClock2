package com.infinityclock.app.clock.presets

/**
 * The 10 curated palettes from the Advanced Color Studio spec. Presets pull
 * from these, and the Color Studio screen (Part 1's customization editor)
 * offers the exact same list to the user.
 */
data class Palette(
    val name: String,
    val primary: Long,
    val secondary: Long,
    val accent: Long,
    val glow: Long
)

val CuratedPalettes = listOf(
    Palette("Neon Blue", 0xFF00D4FF, 0xFF0088CC, 0xFF66E8FF, 0xFF00D4FF),
    Palette("Purple", 0xFF9B5CFF, 0xFF6C3FCF, 0xFFC9A6FF, 0xFF9B5CFF),
    Palette("Cyber Green", 0xFF39FF88, 0xFF0FA85A, 0xFFB6FFD6, 0xFF39FF88),
    Palette("Sunset", 0xFFFF7A59, 0xFFFF4D8D, 0xFFFFC371, 0xFFFF7A59),
    Palette("Ocean", 0xFF1FA2FF, 0xFF12D8FA, 0xFFA6FFCB, 0xFF1FA2FF),
    Palette("Fire", 0xFFFF4E50, 0xFFF9D423, 0xFFFF8C42, 0xFFFF4E50),
    Palette("Ice", 0xFFA1FFCE, 0xFF7FDBFF, 0xFFFAFFD1, 0xFF7FDBFF),
    Palette("Aurora", 0xFF00F5A0, 0xFF00D9F5, 0xFF7B2FF7, 0xFF00F5A0),
    Palette("Gold", 0xFFFFD700, 0xFFC9A227, 0xFFFFF3B0, 0xFFFFD700),
    Palette("AMOLED", 0xFFFFFFFF, 0xFF888888, 0xFFCCCCCC, 0xFFFFFFFF)
)

fun palette(index: Int): Palette = CuratedPalettes[index % CuratedPalettes.size]
