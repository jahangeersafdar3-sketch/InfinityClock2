package com.infinityclock.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclock.app.timer.TimerState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.timerDataStore by preferencesDataStore(name = "infinity_clock_timer")

class TimerRepository(private val context: Context) {
    private val key = stringPreferencesKey("timer_state_json")

    val stateFlow: Flow<TimerState> = context.timerDataStore.data.map { prefs ->
        prefs[key]?.let { TimerState.fromJson(JSONObject(it)) } ?: TimerState()
    }

    suspend fun save(state: TimerState) {
        context.timerDataStore.edit { it[key] = state.toJson().toString() }
    }

    suspend fun current(): TimerState = stateFlow.first()
}
