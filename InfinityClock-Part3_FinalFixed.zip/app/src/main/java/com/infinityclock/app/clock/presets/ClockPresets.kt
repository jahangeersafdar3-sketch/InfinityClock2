package com.infinityclock.app.clock.presets

import com.infinityclock.app.clock.model.*

/**
 * Generates the full built-in preset catalog (100+ clocks) from the shared
 * ClockConfig model. Each ClockCategory defines its *character* (background
 * treatment, animation, hand/number/marker style); each of the 3 palette
 * variants per category then gives it a genuinely different color identity,
 * plus a structural tweak (border, opacity, gradient angle, glow intensity)
 * so variants are not just recolors of one another.
 *
 * Total: 34 categories x 3 variants = 102 presets.
 */
private data class CategoryBlueprint(
    val background: BackgroundStyle,
    val animation: AnimationStyle,
    val font: ClockFont = ClockFont.SYSTEM,
    val handStyle: HandStyle = HandStyle.CLASSIC,
    val numberStyle: NumberStyle = NumberStyle.STANDARD,
    val markerStyle: MarkerStyle = MarkerStyle.TICKS,
    val glow: Boolean = false,
    val border: Boolean = false
)

private val blueprints: Map<ClockCategory, CategoryBlueprint> = mapOf(
    // ---- DIGITAL ----
    ClockCategory.DIGITAL_MINIMAL to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.NONE, ClockFont.SYSTEM
    ),
    ClockCategory.DIGITAL_NEON to CategoryBlueprint(
        BackgroundStyle.AMOLED_BLACK, AnimationStyle.GLOW_PULSE, ClockFont.CONDENSED, glow = true
    ),
    ClockCategory.DIGITAL_GLASS to CategoryBlueprint(
        BackgroundStyle.GLASS, AnimationStyle.LIGHT_SWEEP, ClockFont.ROUNDED, border = true
    ),
    ClockCategory.DIGITAL_CYBER to CategoryBlueprint(
        BackgroundStyle.ANIMATED_GRADIENT, AnimationStyle.GRADIENT_MOVE, ClockFont.MONO, glow = true, border = true
    ),
    ClockCategory.DIGITAL_FUTURISTIC to CategoryBlueprint(
        BackgroundStyle.ABSTRACT, AnimationStyle.LIGHT_SWEEP, ClockFont.CONDENSED, glow = true
    ),
    ClockCategory.DIGITAL_LED to CategoryBlueprint(
        BackgroundStyle.AMOLED_BLACK, AnimationStyle.TICKING, ClockFont.MONO, glow = true
    ),
    ClockCategory.DIGITAL_MATRIX to CategoryBlueprint(
        BackgroundStyle.PARTICLES, AnimationStyle.PARTICLE_DRIFT, ClockFont.MONO, glow = true
    ),
    ClockCategory.DIGITAL_RETRO to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.TICKING, ClockFont.SERIF, border = true
    ),
    ClockCategory.DIGITAL_PIXEL to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.NUMBER_MORPH, ClockFont.MONO, markerStyle = MarkerStyle.DOTS
    ),
    ClockCategory.DIGITAL_GRADIENT to CategoryBlueprint(
        BackgroundStyle.GRADIENT, AnimationStyle.GRADIENT_MOVE, ClockFont.ROUNDED
    ),
    ClockCategory.DIGITAL_HOLOGRAPHIC to CategoryBlueprint(
        BackgroundStyle.AURORA, AnimationStyle.HOLOGRAPHIC_FLICKER, ClockFont.CONDENSED, glow = true
    ),
    ClockCategory.DIGITAL_LUXURY to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.BREATHING_GLOW, ClockFont.SERIF, border = true, glow = true
    ),
    ClockCategory.DIGITAL_AMOLED to CategoryBlueprint(
        BackgroundStyle.AMOLED_BLACK, AnimationStyle.NONE, ClockFont.SYSTEM
    ),
    ClockCategory.DIGITAL_SCIFI to CategoryBlueprint(
        BackgroundStyle.SPACE, AnimationStyle.LIGHT_SWEEP, ClockFont.CONDENSED, glow = true, border = true
    ),
    ClockCategory.DIGITAL_TERMINAL to CategoryBlueprint(
        BackgroundStyle.AMOLED_BLACK, AnimationStyle.TICKING, ClockFont.MONO
    ),
    ClockCategory.DIGITAL_LIQUID to CategoryBlueprint(
        BackgroundStyle.ANIMATED_GRADIENT, AnimationStyle.LIQUID_WAVE, ClockFont.ROUNDED, glow = true
    ),

    // ---- ANALOG ----
    ClockCategory.ANALOG_CLASSIC to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.SMOOTH_SWEEP, handStyle = HandStyle.CLASSIC, markerStyle = MarkerStyle.TICKS
    ),
    ClockCategory.ANALOG_LUXURY to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.SMOOTH_SWEEP, handStyle = HandStyle.DIAMOND,
        numberStyle = NumberStyle.ARABIC_ART_DECO, markerStyle = MarkerStyle.DIAMONDS, border = true, glow = true
    ),
    ClockCategory.ANALOG_ROMAN to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.SMOOTH_SWEEP, handStyle = HandStyle.SWORD,
        numberStyle = NumberStyle.ROMAN, markerStyle = MarkerStyle.LINES
    ),
    ClockCategory.ANALOG_MINIMAL to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.NONE, handStyle = HandStyle.NEEDLE,
        numberStyle = NumberStyle.TICKS_ONLY, markerStyle = MarkerStyle.DOTS
    ),
    ClockCategory.ANALOG_SKELETON to CategoryBlueprint(
        BackgroundStyle.GLASS, AnimationStyle.MECHANICAL_TICK, handStyle = HandStyle.SKELETON,
        markerStyle = MarkerStyle.LINES, border = true
    ),
    ClockCategory.ANALOG_MECHANICAL to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.MECHANICAL_TICK, handStyle = HandStyle.SWORD, markerStyle = MarkerStyle.TICKS
    ),
    ClockCategory.ANALOG_GLASS to CategoryBlueprint(
        BackgroundStyle.GLASS, AnimationStyle.SMOOTH_SWEEP, handStyle = HandStyle.NEEDLE, border = true
    ),
    ClockCategory.ANALOG_NEON to CategoryBlueprint(
        BackgroundStyle.AMOLED_BLACK, AnimationStyle.GLOW_PULSE, handStyle = HandStyle.BLOCK, glow = true
    ),
    ClockCategory.ANALOG_FUTURISTIC to CategoryBlueprint(
        BackgroundStyle.ABSTRACT, AnimationStyle.LIGHT_SWEEP, handStyle = HandStyle.BLOCK, glow = true
    ),
    ClockCategory.ANALOG_METALLIC to CategoryBlueprint(
        BackgroundStyle.GRADIENT, AnimationStyle.SMOOTH_SWEEP, handStyle = HandStyle.SWORD, border = true
    ),
    ClockCategory.ANALOG_COMPASS to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.SMOOTH_SWEEP, handStyle = HandStyle.NEEDLE, markerStyle = MarkerStyle.LINES
    ),
    ClockCategory.ANALOG_SPORT to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.TICKING, handStyle = HandStyle.BLOCK, markerStyle = MarkerStyle.TICKS
    ),
    ClockCategory.ANALOG_SPACE to CategoryBlueprint(
        BackgroundStyle.SPACE, AnimationStyle.SMOOTH_SWEEP, handStyle = HandStyle.NEEDLE, glow = true
    ),

    // ---- HYBRID ----
    ClockCategory.HYBRID_ANALOG_DIGITAL to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.SMOOTH_SWEEP, handStyle = HandStyle.CLASSIC
    ),
    ClockCategory.HYBRID_ANALOG_DATE to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.SMOOTH_SWEEP, handStyle = HandStyle.NEEDLE
    ),
    ClockCategory.HYBRID_DIGITAL_SECONDS_RING to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.SMOOTH_SWEEP, ClockFont.CONDENSED, glow = true
    ),
    ClockCategory.HYBRID_DIGITAL_BATTERY to CategoryBlueprint(
        BackgroundStyle.SOLID, AnimationStyle.NONE, ClockFont.ROUNDED
    ),
    ClockCategory.HYBRID_DIGITAL_WORLD to CategoryBlueprint(
        BackgroundStyle.GRADIENT, AnimationStyle.GRADIENT_MOVE, ClockFont.SYSTEM
    )
)

fun buildPresetCatalog(): List<ClockConfig> {
    val presets = mutableListOf<ClockConfig>()
    var paletteCursor = 0

    for (category in ClockCategory.values()) {
        val blueprint = blueprints.getValue(category)

        for (variant in 0 until 3) {
            val pal = palette(paletteCursor)
            paletteCursor++

            // Structural tweaks per variant so three clocks in one category
            // are not just recolors: opacity, border, glow intensity and
            // gradient angle all shift with the variant index.
            val variantBorder = blueprint.border || variant == 1
            val variantGlow = blueprint.glow || variant == 2
            val opacity = when (variant) {
                0 -> 1f
                1 -> 0.94f
                else -> 0.88f
            }
            val gradientAngle = 30f + (variant * 45f) + (paletteCursor % 4) * 10f

            presets += ClockConfig(
                name = "${pal.name} ${category.displayName}",
                category = category,
                isCustom = false,
                font = blueprint.font,
                primaryColor = pal.primary,
                secondaryColor = pal.secondary,
                accentColor = pal.accent,
                backgroundStyle = blueprint.background,
                backgroundColors = listOf(pal.secondary, pal.primary),
                gradientAngle = gradientAngle,
                opacity = opacity,
                glow = variantGlow,
                glowColor = pal.glow,
                glowIntensity = if (variant == 2) 0.8f else 0.5f,
                shadow = variant != 0,
                border = variantBorder,
                borderColor = pal.accent,
                showSeconds = true,
                showDate = category.type != ClockType.ANALOG || variant != 1,
                showDay = true,
                is24Hour = variant != 1,
                animationStyle = blueprint.animation,
                animationSpeedMultiplier = when (variant) {
                    0 -> 1f
                    1 -> 1.25f
                    else -> 0.8f
                },
                handStyle = blueprint.handStyle,
                numberStyle = blueprint.numberStyle,
                markerStyle = blueprint.markerStyle
            )
        }
    }

    return presets
}
