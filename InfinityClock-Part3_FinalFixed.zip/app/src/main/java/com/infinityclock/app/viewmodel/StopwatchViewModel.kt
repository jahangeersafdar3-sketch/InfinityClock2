package com.infinityclock.app.viewmodel

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.infinityclock.app.data.StopwatchRepository
import com.infinityclock.app.stopwatch.StopwatchState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class StopwatchViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = StopwatchRepository(application)

    private val _state = MutableStateFlow(StopwatchState())
    val state: StateFlow<StopwatchState> = _state.asStateFlow()

    init {
        viewModelScope.launch { _state.value = repository.current() }
    }

    private fun persist() = viewModelScope.launch { repository.save(_state.value) }

    fun start() {
        if (_state.value.running) return
        _state.value = _state.value.copy(running = true, startElapsedRealtime = SystemClock.elapsedRealtime())
        persist()
    }

    fun pause() {
        val s = _state.value
        if (!s.running) return
        val elapsed = s.currentElapsedMillis(SystemClock.elapsedRealtime())
        _state.value = s.copy(running = false, accumulatedMillis = elapsed)
        persist()
    }

    fun reset() {
        _state.value = StopwatchState()
        persist()
    }

    fun lap() {
        val s = _state.value
        val elapsed = s.currentElapsedMillis(SystemClock.elapsedRealtime())
        _state.value = s.copy(laps = s.laps + elapsed)
        persist()
    }

    /** Call periodically (e.g. every 30ms while running) just to force UI recomposition — the
     * actual elapsed value is always recomputed fresh from real elapsedRealtime(), never counted. */
    fun currentElapsedMillis(): Long = _state.value.currentElapsedMillis(SystemClock.elapsedRealtime())
}
