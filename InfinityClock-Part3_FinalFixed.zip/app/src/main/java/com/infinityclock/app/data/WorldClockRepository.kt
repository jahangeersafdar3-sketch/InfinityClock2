package com.infinityclock.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclock.app.worldclock.WorldClockEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.worldClockDataStore by preferencesDataStore(name = "infinity_clock_world_clock")

class WorldClockRepository(private val context: Context) {
    private object Keys {
        val ENTRIES = stringPreferencesKey("world_clock_entries_json")
    }

    val entriesFlow: Flow<List<WorldClockEntry>> = context.worldClockDataStore.data.map { prefs ->
        val json = prefs[Keys.ENTRIES] ?: "[]"
        val array = JSONArray(json)
        (0 until array.length()).map { WorldClockEntry.fromJson(array.getJSONObject(it)) }.sortedBy { it.order }
    }

    private suspend fun writeAll(entries: List<WorldClockEntry>) {
        context.worldClockDataStore.edit { prefs ->
            val array = JSONArray()
            entries.forEachIndexed { index, e -> array.put(e.copy(order = index).toJson()) }
            prefs[Keys.ENTRIES] = array.toString()
        }
    }

    suspend fun add(entry: WorldClockEntry, current: List<WorldClockEntry>) {
        if (current.any { it.zoneId == entry.zoneId && it.city == entry.city }) return
        writeAll(current + entry.copy(order = current.size))
    }

    suspend fun remove(id: String, current: List<WorldClockEntry>) {
        writeAll(current.filterNot { it.id == id })
    }

    suspend fun toggleFavorite(id: String, current: List<WorldClockEntry>) {
        writeAll(current.map { if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it })
    }

    suspend fun moveUp(id: String, current: List<WorldClockEntry>) {
        val sorted = current.sortedBy { it.order }.toMutableList()
        val index = sorted.indexOfFirst { it.id == id }
        if (index <= 0) return
        val tmp = sorted[index - 1]
        sorted[index - 1] = sorted[index]
        sorted[index] = tmp
        writeAll(sorted)
    }

    suspend fun moveDown(id: String, current: List<WorldClockEntry>) {
        val sorted = current.sortedBy { it.order }.toMutableList()
        val index = sorted.indexOfFirst { it.id == id }
        if (index < 0 || index >= sorted.size - 1) return
        val tmp = sorted[index + 1]
        sorted[index + 1] = sorted[index]
        sorted[index] = tmp
        writeAll(sorted)
    }
}
