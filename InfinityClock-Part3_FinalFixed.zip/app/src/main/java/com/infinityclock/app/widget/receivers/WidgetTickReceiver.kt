package com.infinityclock.app.widget.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.infinityclock.app.widget.WidgetUpdateScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Fired by WidgetUpdateScheduler's AlarmManager alarm roughly once a minute.
 * Redraws all widgets, then — only if a widget is still actually pinned —
 * schedules the next tick. If the user removes every widget, this chain
 * naturally stops instead of ticking forever in the background.
 */
class WidgetTickReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_TICK = "com.infinityclock.app.widget.ACTION_TICK"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_TICK) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                WidgetUpdateScheduler.triggerAllWidgetUpdates(context)
                if (WidgetUpdateScheduler.hasAnyConfiguredWidget(context)) {
                    WidgetUpdateScheduler.scheduleNextTick(context)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
