package com.infinityclock.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.clock.presets.buildPresetCatalog
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.clockDataStore by preferencesDataStore(name = "infinity_clock_library")

/**
 * Persists user-created clocks and favorite/recent state locally via
 * DataStore (JSON-encoded, using org.json which ships with Android — no
 * network, no Firebase, no cloud dependency of any kind).
 */
class ClockRepository(private val context: Context) {

    private object Keys {
        val CUSTOM_CLOCKS = stringPreferencesKey("custom_clocks_json")
        val FAVORITE_IDS = stringSetPreferencesKey("favorite_ids")
        val RECENT_IDS = stringPreferencesKey("recent_ids_json")
    }

    private val presetCatalog: List<ClockConfig> = buildPresetCatalog()

    fun presets(): List<ClockConfig> = presetCatalog

    val customClocksFlow: Flow<List<ClockConfig>> = context.clockDataStore.data.map { prefs ->
        val json = prefs[Keys.CUSTOM_CLOCKS] ?: "[]"
        val array = JSONArray(json)
        (0 until array.length()).map { ClockConfig.fromJson(array.getJSONObject(it)) }
    }

    val favoriteIdsFlow: Flow<Set<String>> = context.clockDataStore.data.map { prefs ->
        prefs[Keys.FAVORITE_IDS] ?: emptySet()
    }

    private val recentIdsFlow: Flow<List<String>> = context.clockDataStore.data.map { prefs ->
        val json = prefs[Keys.RECENT_IDS] ?: "[]"
        val array = JSONArray(json)
        (0 until array.length()).map { array.getString(it) }
    }

    /** All clocks (presets + custom), with favorite flags applied. */
    val allClocksFlow: Flow<List<ClockConfig>> = combine(customClocksFlow, favoriteIdsFlow) { custom, favorites ->
        (presetCatalog + custom).map { it.copy(isFavorite = favorites.contains(it.id)) }
    }

    val recentClocksFlow: Flow<List<ClockConfig>> = combine(allClocksFlow, recentIdsFlow) { all, recentIds ->
        val byId = all.associateBy { it.id }
        recentIds.mapNotNull { byId[it] }
    }

    suspend fun saveCustomClock(config: ClockConfig) {
        context.clockDataStore.edit { prefs ->
            val json = prefs[Keys.CUSTOM_CLOCKS] ?: "[]"
            val array = JSONArray(json)
            val existing = (0 until array.length()).map { JSONObject(array.getJSONObject(it).toString()) }
            val filtered = existing.filterNot { it.getString("id") == config.id }
            val updated = JSONArray()
            filtered.forEach { updated.put(it) }
            updated.put(config.toJson())
            prefs[Keys.CUSTOM_CLOCKS] = updated.toString()
        }
    }

    suspend fun deleteCustomClock(id: String) {
        context.clockDataStore.edit { prefs ->
            val json = prefs[Keys.CUSTOM_CLOCKS] ?: "[]"
            val array = JSONArray(json)
            val remaining = JSONArray()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                if (obj.getString("id") != id) remaining.put(obj)
            }
            prefs[Keys.CUSTOM_CLOCKS] = remaining.toString()
        }
    }

    suspend fun duplicateCustomClock(source: ClockConfig): ClockConfig {
        val copy = source.copy(
            id = java.util.UUID.randomUUID().toString(),
            name = "${source.name} Copy",
            isCustom = true,
            createdAt = System.currentTimeMillis(),
            modifiedAt = System.currentTimeMillis()
        )
        saveCustomClock(copy)
        return copy
    }

    suspend fun toggleFavorite(id: String) {
        context.clockDataStore.edit { prefs ->
            val current = prefs[Keys.FAVORITE_IDS] ?: emptySet()
            prefs[Keys.FAVORITE_IDS] = if (current.contains(id)) current - id else current + id
        }
    }

    suspend fun markRecentlyUsed(id: String) {
        context.clockDataStore.edit { prefs ->
            val json = prefs[Keys.RECENT_IDS] ?: "[]"
            val array = JSONArray(json)
            val existing = (0 until array.length()).map { array.getString(it) }
            val updated = (listOf(id) + existing.filterNot { it == id }).take(20)
            prefs[Keys.RECENT_IDS] = JSONArray(updated).toString()
        }
    }
}
