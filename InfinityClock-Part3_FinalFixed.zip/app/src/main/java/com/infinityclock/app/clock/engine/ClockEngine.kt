package com.infinityclock.app.clock.engine

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.clock.model.ClockType
import com.infinityclock.app.clock.util.TickTime
import com.infinityclock.app.clock.util.currentTickTime
import com.infinityclock.app.clock.util.rememberBatteryPercent
import com.infinityclock.app.clock.util.tickerFlow
import kotlinx.coroutines.flow.collectLatest

/**
 * The single reusable renderer every screen (Home preview, Gallery cards,
 * Create/Customize preview, and any future widget) calls into. It owns:
 *  - a real, wall-clock-accurate ticker (paused while the host lifecycle is
 *    not STARTED, so a clock that has scrolled off-screen or is backgrounded
 *    stops recomputing/animating — this satisfies the "don't run animation
 *    when not visible" performance requirement)
 *  - background rendering
 *  - dispatch to the correct face (Digital/Analog/Hybrid)
 */
@Composable
fun ClockEngine(
    config: ClockConfig,
    quality: AnimationQuality,
    modifier: Modifier = Modifier,
    live: Boolean = true
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    var lifecycleStarted by remember { mutableStateOf(true) }

    if (live) {
        DisposableLifecycleGate(onStateChanged = { started -> lifecycleStarted = started })
    }

    var time by remember { mutableStateOf(currentTickTime()) }

    LaunchedEffect(live, lifecycleStarted) {
        if (live && lifecycleStarted) {
            tickerFlow().collectLatest { time = it }
        } else if (!live) {
            time = currentTickTime()
        }
    }

    val batteryPercent = rememberBatteryPercent()

    Box(modifier = modifier.fillMaxSize()) {
        ClockBackground(config = config, quality = quality, modifier = Modifier.fillMaxSize())
        when (config.type) {
            ClockType.DIGITAL -> DigitalClockFace(config, time, quality, modifier = Modifier.fillMaxSize())
            ClockType.ANALOG -> AnalogClockFace(config, time, quality, modifier = Modifier.fillMaxSize())
            ClockType.HYBRID -> HybridClockFace(config, time, quality, batteryPercent, modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
private fun DisposableLifecycleGate(onStateChanged: (Boolean) -> Unit) {
    val lifecycleOwner = LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START, Lifecycle.Event.ON_RESUME -> onStateChanged(true)
                Lifecycle.Event.ON_STOP, Lifecycle.Event.ON_PAUSE -> onStateChanged(false)
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
}
