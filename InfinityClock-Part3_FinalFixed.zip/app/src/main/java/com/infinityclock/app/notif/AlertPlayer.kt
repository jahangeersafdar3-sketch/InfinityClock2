package com.infinityclock.app.notif

import android.content.Context
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Plays the device's default alarm/notification sound and vibrates, used by
 * both the Timer completion alert and the Alarm ringing screen. Uses
 * STREAM_ALARM-equivalent audio attributes so it respects the user's alarm
 * volume, and stops cleanly rather than leaking a Ringtone/Vibrator.
 */
class AlertPlayer(private val context: Context) {
    private var ringtone: Ringtone? = null

    fun start(sound: Boolean, vibrate: Boolean, useAlarmSound: Boolean) {
        if (sound) {
            val uri = if (useAlarmSound) {
                RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            } else {
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            }
            ringtone = RingtoneManager.getRingtone(context, uri)?.apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    audioAttributes = AudioAttributes.Builder()
                        .setUsage(if (useAlarmSound) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                }
                isLooping = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                play()
            }
        }
        if (vibrate) {
            val vibrator = vibratorService()
            val pattern = longArrayOf(0, 500, 500)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        }
    }

    fun stop() {
        ringtone?.stop()
        ringtone = null
        vibratorService()?.cancel()
    }

    private fun vibratorService(): Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
}
