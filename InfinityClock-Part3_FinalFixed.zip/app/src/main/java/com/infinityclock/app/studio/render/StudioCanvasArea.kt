package com.infinityclock.app.studio.render

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.util.TickTime
import com.infinityclock.app.studio.model.CanvasElement
import com.infinityclock.app.studio.model.ElementAnimationPreset
import kotlin.math.max
import kotlin.math.min

/**
 * Renders every CanvasElement at its correct position/size/rotation and,
 * when [editable] is true, provides real direct-manipulation controls for
 * the currently selected element:
 *  - drag the element body to move it
 *  - drag the bottom-right handle to resize it
 *  - drag the top handle left/right to rotate it
 * All three write back real fraction/degree values via the callbacks, which
 * StudioViewModel then applies (recording an undo snapshot first).
 */
@Composable
fun StudioCanvasArea(
    elements: List<CanvasElement>,
    time: TickTime,
    is24Hour: Boolean,
    quality: AnimationQuality,
    editable: Boolean,
    selectedId: String?,
    onSelect: (String?) -> Unit,
    onBeginGesture: () -> Unit,
    onMove: (id: String, newX: Float, newY: Float) -> Unit,
    onResize: (id: String, newWidth: Float, newHeight: Float) -> Unit,
    onRotate: (id: String, newRotation: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current

    BoxWithConstraints(
        modifier = modifier.pointerInput(editable) {
            if (editable) detectTapGestures(onTap = { onSelect(null) })
        }
    ) {
        val canvasWidthDp = maxWidth
        val canvasHeightDp = maxHeight

        elements.sortedBy { it.zIndex }.forEach { element ->
            key(element.id) {
                val widthDp = canvasWidthDp * element.width
                val heightDp = canvasHeightDp * element.height
                val offsetXDp = canvasWidthDp * element.x
                val offsetYDp = canvasHeightDp * element.y
                val isSelected = editable && selectedId == element.id

                val animRotation by animatedRotation(element, quality)
                val animScale by animatedScale(element, quality)
                val animAlpha by animatedAlpha(element, quality)

                Box(
                    modifier = Modifier
                        .offset(x = offsetXDp, y = offsetYDp)
                        .size(width = widthDp, height = heightDp)
                        .graphicsLayer {
                            rotationZ = element.rotationDegrees + animRotation
                            scaleX = animScale
                            scaleY = animScale
                            alpha = animAlpha
                        }
                        .then(
                            if (editable) Modifier.pointerInput(element.id) {
                                detectTapGestures(onTap = { onSelect(element.id) })
                            } else Modifier
                        )
                        .then(
                            if (editable) Modifier.pointerInput(element.id) {
                                detectDragGestures(
                                    onDragStart = {
                                        onSelect(element.id)
                                        onBeginGesture()
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        val dxFraction = with(density) { dragAmount.x.toDp() } / canvasWidthDp
                                        val dyFraction = with(density) { dragAmount.y.toDp() } / canvasHeightDp
                                        val newX = (element.x + dxFraction).coerceIn(-0.5f, 1f)
                                        val newY = (element.y + dyFraction).coerceIn(-0.5f, 1f)
                                        onMove(element.id, newX, newY)
                                    }
                                )
                            } else Modifier
                        )
                ) {
                    Canvas(modifier = Modifier.size(widthDp, heightDp)) {
                        drawCanvasElement(
                            element = element,
                            widthPx = size.width,
                            heightPx = size.height,
                            displayText = resolveElementText(element, time, is24Hour)
                        )
                    }

                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(widthDp, heightDp)
                                .border(BorderStroke(1.5.dp, Color.White))
                        )

                        // Resize handle (bottom-right): drag to change width/height.
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(18.dp)
                                .offset(x = 9.dp, y = 9.dp)
                                .background(Color.White, CircleShape)
                                .pointerInput(element.id) {
                                    detectDragGestures(
                                        onDragStart = { onBeginGesture() },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            val dW = with(density) { dragAmount.x.toDp() } / canvasWidthDp
                                            val dH = with(density) { dragAmount.y.toDp() } / canvasHeightDp
                                            val newW = (element.width + dW).coerceIn(0.05f, 1f)
                                            val newH = (element.height + dH).coerceIn(0.03f, 1f)
                                            onResize(element.id, newW, newH)
                                        }
                                    )
                                }
                        )

                        // Rotate handle (top-center): drag left/right to spin the element.
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .size(18.dp)
                                .offset(y = (-22).dp)
                                .background(Color.Cyan, CircleShape)
                                .pointerInput(element.id) {
                                    detectDragGestures(
                                        onDragStart = { onBeginGesture() },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            val newRotation = element.rotationDegrees + dragAmount.x * 0.6f
                                            onRotate(element.id, newRotation)
                                        }
                                    )
                                }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun animatedRotation(element: CanvasElement, quality: AnimationQuality) = if (
    quality != AnimationQuality.BATTERY_SAVER && element.animation == ElementAnimationPreset.ROTATION
) {
    val transition = rememberInfiniteTransition(label = "elementRotate")
    transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween((4000 / max(element.animationSpeedMultiplier, 0.1f)).toInt(), easing = LinearEasing)
        ),
        label = "rotate"
    )
} else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
}

@Composable
private fun animatedScale(element: CanvasElement, quality: AnimationQuality) = if (
    quality != AnimationQuality.BATTERY_SAVER &&
    element.animation in setOf(ElementAnimationPreset.PULSE, ElementAnimationPreset.SCALE, ElementAnimationPreset.BREATHING)
) {
    val transition = rememberInfiniteTransition(label = "elementScale")
    val range = if (element.animation == ElementAnimationPreset.BREATHING) 0.08f else 0.15f
    transition.animateFloat(
        initialValue = 1f - range,
        targetValue = 1f + range,
        animationSpec = infiniteRepeatable(
            animation = tween((1200 / max(element.animationSpeedMultiplier, 0.1f)).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
} else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
}

@Composable
private fun animatedAlpha(element: CanvasElement, quality: AnimationQuality) = if (
    quality != AnimationQuality.BATTERY_SAVER &&
    element.animation in setOf(ElementAnimationPreset.FADE, ElementAnimationPreset.GLOW, ElementAnimationPreset.LIGHT_SWEEP)
) {
    val transition = rememberInfiniteTransition(label = "elementAlpha")
    transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween((1000 / max(element.animationSpeedMultiplier, 0.1f)).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )
} else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
}
