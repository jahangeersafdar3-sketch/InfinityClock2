package com.infinityclock.app.worldclock

import org.json.JSONObject
import java.util.UUID

data class WorldClockEntry(
    val id: String = UUID.randomUUID().toString(),
    val city: String,
    val country: String,
    val zoneId: String,
    val isFavorite: Boolean = false,
    val order: Int = 0
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("city", city); put("country", country)
        put("zoneId", zoneId); put("isFavorite", isFavorite); put("order", order)
    }

    companion object {
        fun fromJson(j: JSONObject) = WorldClockEntry(
            id = j.getString("id"), city = j.getString("city"), country = j.getString("country"),
            zoneId = j.getString("zoneId"), isFavorite = j.getBoolean("isFavorite"), order = j.optInt("order", 0)
        )
    }
}

/** Computes the current wall-clock time/date in [zoneId] from real timezone
 * data (java.util.TimeZone), so daylight saving is applied automatically. */
data class WorldClockNow(
    val hour24: Int, val minute: Int, val dayOfWeek: String, val dayOfMonth: Int, val month: String,
    val utcOffsetLabel: String
)

private val dayNames = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
private val monthNames = arrayOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

fun computeNowFor(zoneId: String): WorldClockNow {
    val tz = java.util.TimeZone.getTimeZone(zoneId)
    val cal = java.util.Calendar.getInstance(tz)
    val offsetMillis = tz.getOffset(cal.timeInMillis)
    val offsetHours = offsetMillis / 3_600_000.0
    val sign = if (offsetHours >= 0) "+" else "-"
    val absHours = kotlin.math.abs(offsetHours)
    val wholeHours = absHours.toInt()
    val minutesPart = ((absHours - wholeHours) * 60).toInt()
    val offsetLabel = "UTC$sign${wholeHours.toString().padStart(2, '0')}:${minutesPart.toString().padStart(2, '0')}"
    return WorldClockNow(
        hour24 = cal.get(java.util.Calendar.HOUR_OF_DAY),
        minute = cal.get(java.util.Calendar.MINUTE),
        dayOfWeek = dayNames[cal.get(java.util.Calendar.DAY_OF_WEEK) - 1],
        dayOfMonth = cal.get(java.util.Calendar.DAY_OF_MONTH),
        month = monthNames[cal.get(java.util.Calendar.MONTH)],
        utcOffsetLabel = offsetLabel
    )
}
