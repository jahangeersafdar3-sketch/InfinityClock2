package com.infinityclock.app.timer

import org.json.JSONObject

/**
 * Like StopwatchState, anchored on SystemClock.elapsedRealtime() rather than
 * a per-tick counter: [targetElapsedRealtime] is the real moment the timer
 * should reach zero, so the remaining time is always recomputed correctly
 * even after the app was backgrounded.
 */
data class TimerState(
    val totalMillis: Long = 0L,
    val remainingMillisWhenPaused: Long = 0L,
    val targetElapsedRealtime: Long = 0L,
    val running: Boolean = false,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true
) {
    fun remainingMillis(nowElapsedRealtime: Long): Long = if (running) {
        (targetElapsedRealtime - nowElapsedRealtime).coerceAtLeast(0L)
    } else {
        remainingMillisWhenPaused
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("totalMillis", totalMillis)
        put("remainingMillisWhenPaused", remainingMillisWhenPaused)
        put("targetElapsedRealtime", targetElapsedRealtime)
        put("running", running)
        put("soundEnabled", soundEnabled)
        put("vibrationEnabled", vibrationEnabled)
    }

    companion object {
        fun fromJson(j: JSONObject) = TimerState(
            totalMillis = j.optLong("totalMillis", 0L),
            remainingMillisWhenPaused = j.optLong("remainingMillisWhenPaused", 0L),
            targetElapsedRealtime = j.optLong("targetElapsedRealtime", 0L),
            running = j.optBoolean("running", false),
            soundEnabled = j.optBoolean("soundEnabled", true),
            vibrationEnabled = j.optBoolean("vibrationEnabled", true)
        )
    }
}

fun formatCountdown(millis: Long): String {
    val totalSeconds = (millis + 999) / 1000 // round up so it doesn't show 0 a beat early
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, seconds) else "%02d:%02d".format(minutes, seconds)
}
