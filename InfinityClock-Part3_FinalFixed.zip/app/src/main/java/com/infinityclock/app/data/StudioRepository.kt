package com.infinityclock.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclock.app.studio.model.StudioClockConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Context.studioDataStore by preferencesDataStore(name = "infinity_clock_studio")

/**
 * Persists Clock Studio designs locally (DataStore + org.json, same pattern
 * as ClockRepository) — fully independent of the Part 1 preset system so
 * saving/loading studio clocks can never disturb it.
 */
class StudioRepository(private val context: Context) {

    private object Keys {
        val CLOCKS = stringPreferencesKey("studio_clocks_json")
    }

    val clocksFlow: Flow<List<StudioClockConfig>> = context.studioDataStore.data.map { prefs ->
        val json = prefs[Keys.CLOCKS] ?: "[]"
        val array = JSONArray(json)
        (0 until array.length()).map { StudioClockConfig.fromJson(array.getJSONObject(it)) }
    }

    suspend fun save(config: StudioClockConfig) {
        context.studioDataStore.edit { prefs ->
            val json = prefs[Keys.CLOCKS] ?: "[]"
            val array = JSONArray(json)
            val existing = (0 until array.length()).map { JSONObject(array.getJSONObject(it).toString()) }
            val filtered = existing.filterNot { it.getString("id") == config.id }
            val updated = JSONArray()
            filtered.forEach { updated.put(it) }
            updated.put(config.toJson())
            prefs[Keys.CLOCKS] = updated.toString()
        }
    }

    suspend fun delete(id: String) {
        context.studioDataStore.edit { prefs ->
            val json = prefs[Keys.CLOCKS] ?: "[]"
            val array = JSONArray(json)
            val remaining = JSONArray()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                if (obj.getString("id") != id) remaining.put(obj)
            }
            prefs[Keys.CLOCKS] = remaining.toString()
        }
    }

    suspend fun duplicate(source: StudioClockConfig): StudioClockConfig {
        val copy = source.copy(
            id = UUID.randomUUID().toString(),
            name = "${source.name} Copy",
            createdAt = System.currentTimeMillis(),
            modifiedAt = System.currentTimeMillis()
        )
        save(copy)
        return copy
    }

    suspend fun toggleFavorite(id: String, current: List<StudioClockConfig>) {
        val target = current.firstOrNull { it.id == id } ?: return
        save(target.copy(isFavorite = !target.isFavorite, modifiedAt = System.currentTimeMillis()))
    }

    suspend fun rename(id: String, newName: String, current: List<StudioClockConfig>) {
        val target = current.firstOrNull { it.id == id } ?: return
        save(target.copy(name = newName, modifiedAt = System.currentTimeMillis()))
    }
}
