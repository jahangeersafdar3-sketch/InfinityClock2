package com.infinityclock.app.widget

import android.content.Context
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.clock.model.ClockType
import com.infinityclock.app.clock.presets.buildPresetCatalog
import com.infinityclock.app.common.ClockRef
import com.infinityclock.app.common.ClockRefKind
import com.infinityclock.app.data.ClockRepository
import com.infinityclock.app.data.StudioRepository
import kotlinx.coroutines.flow.first

/** What a widget actually needs to know to render — resolved from either repository. */
data class ResolvedWidgetClock(
    val name: String,
    val primaryColor: Long,
    val secondaryColor: Long,
    val accentColor: Long,
    val renderAsAnalog: Boolean
)

private val fallbackPresets by lazy { buildPresetCatalog() }

/**
 * Studio (freeform layer-based) designs cannot yet be rendered pixel-for-
 * pixel inside a RemoteViews/Glance widget — that would need full custom
 * Canvas drawing, which the Android widget framework does not support. This
 * is a deliberate, documented limitation (see README): a Studio clock shown
 * in a widget renders as a clean digital readout using that design's own
 * colors, rather than pretending its full custom layout appears.
 */
suspend fun resolveWidgetClock(context: Context, ref: ClockRef?): ResolvedWidgetClock {
    if (ref == null) return defaultResolved()
    return when (ref.kind) {
        ClockRefKind.STANDARD -> {
            val repo = ClockRepository(context)
            val all = fallbackPresets + repo.customClocksFlow.first()
            val match = all.firstOrNull { it.id == ref.id }
            if (match != null) fromConfig(match) else defaultResolved()
        }
        ClockRefKind.STUDIO -> {
            val repo = StudioRepository(context)
            val match = repo.clocksFlow.first().firstOrNull { it.id == ref.id }
            if (match != null) {
                val dominant = match.elements.firstOrNull { it.type.name.contains("HOUR") }?.primaryColor
                    ?: match.elements.firstOrNull()?.primaryColor ?: 0xFF00D4FF
                ResolvedWidgetClock(match.name, dominant, dominant, dominant, renderAsAnalog = false)
            } else defaultResolved()
        }
    }
}

private fun fromConfig(config: ClockConfig) = ResolvedWidgetClock(
    name = config.name,
    primaryColor = config.primaryColor,
    secondaryColor = config.secondaryColor,
    accentColor = config.accentColor,
    renderAsAnalog = config.type != ClockType.DIGITAL
)

private fun defaultResolved() = ResolvedWidgetClock(
    name = "Infinity Clock",
    primaryColor = 0xFF00D4FF,
    secondaryColor = 0xFF0088CC,
    accentColor = 0xFF66E8FF,
    renderAsAnalog = false
)
