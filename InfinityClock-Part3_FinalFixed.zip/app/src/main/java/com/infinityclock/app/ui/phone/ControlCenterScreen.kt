package com.infinityclock.app.ui.phone

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessAlarm
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.infinityclock.app.fullscreen.FullScreenClockActivity
import com.infinityclock.app.fullscreen.FullScreenMode
import com.infinityclock.app.wallpaper.WallpaperConfigActivity

private data class PhoneFeatureCard(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val onClick: () -> Unit
)

/**
 * The Part 3 "Phone Control Center": every card opens a real, working
 * feature — nothing here is a placeholder. Widget setup (Part 2) lives at
 * the top since it's still reachable from this same tab.
 */
@Composable
fun ControlCenterScreen(
    onOpenWidgets: () -> Unit,
    onOpenAlarms: () -> Unit,
    onOpenTimer: () -> Unit,
    onOpenStopwatch: () -> Unit,
    onOpenWorldClock: () -> Unit
) {
    val context = LocalContext.current

    val cards = listOf(
        PhoneFeatureCard("Home Screen Widget", "Add a live clock widget — 4 sizes and designs.", Icons.Filled.Widgets, onOpenWidgets),
        PhoneFeatureCard("Live Wallpaper", "An animated clock behind your home screen.", Icons.Filled.Wallpaper) {
            context.startActivity(Intent(context, WallpaperConfigActivity::class.java))
        },
        PhoneFeatureCard("Bedside Clock", "A dim, full-screen clock for your nightstand.", Icons.Filled.DarkMode) {
            context.startActivity(
                Intent(context, FullScreenClockActivity::class.java)
                    .putExtra(FullScreenClockActivity.EXTRA_BEDSIDE, true)
                    .putExtra(FullScreenClockActivity.EXTRA_INITIAL_MODE, FullScreenMode.DIM.name)
            )
        },
        PhoneFeatureCard("Full Screen Clock", "A bright, distraction-free full-screen clock.", Icons.Filled.Fullscreen) {
            context.startActivity(
                Intent(context, FullScreenClockActivity::class.java)
                    .putExtra(FullScreenClockActivity.EXTRA_BEDSIDE, false)
                    .putExtra(FullScreenClockActivity.EXTRA_INITIAL_MODE, FullScreenMode.NORMAL.name)
            )
        },
        PhoneFeatureCard("Alarms", "Set, edit, and manage real alarms.", Icons.Filled.AccessAlarm, onOpenAlarms),
        PhoneFeatureCard("Timer", "A countdown timer with presets.", Icons.Filled.Timer, onOpenTimer),
        PhoneFeatureCard("Stopwatch", "Accurate elapsed time with laps.", Icons.Filled.Timer, onOpenStopwatch),
        PhoneFeatureCard("World Clock", "Track times across cities worldwide.", Icons.Filled.Public, onOpenWorldClock)
    )

    Scaffold(topBar = { TopAppBar(title = { Text("Use on Phone") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(cards) { card ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable(onClick = card.onClick),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(card.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column(modifier = Modifier.padding(start = 12.dp)) {
                            Text(card.title, style = MaterialTheme.typography.titleMedium)
                            Text(card.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
