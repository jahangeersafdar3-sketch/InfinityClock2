package com.infinityclock.app.wallpaper

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.infinityclock.app.theme.InfinityClockTheme
import com.infinityclock.app.ui.wallpaper.WallpaperConfigScreen

/**
 * Standalone entry point for wallpaper settings — reachable both from
 * inside the app (Control Center → Live Wallpaper) and from Android's own
 * "Live wallpaper settings" affordance, since it's declared as the
 * `android:settingsActivity` for our WallpaperService in
 * res/xml/live_wallpaper.xml.
 */
class WallpaperConfigActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InfinityClockTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    WallpaperConfigScreen(
                        onBack = { finish() },
                        onLaunchSystemPicker = { launchSystemWallpaperPicker() }
                    )
                }
            }
        }
    }

    private fun launchSystemWallpaperPicker() {
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this@WallpaperConfigActivity, InfinityLiveWallpaperService::class.java)
            )
        }
        // Some launchers/OEM skins don't implement this action even though
        // it's part of the public WallpaperManager API — fall back to the
        // system's generic wallpaper chooser rather than crashing.
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            startActivity(Intent(Intent.ACTION_SET_WALLPAPER))
        }
    }
}
