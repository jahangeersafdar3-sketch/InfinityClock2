package com.infinityclock.app.clock.engine

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.model.BackgroundStyle
import com.infinityclock.app.clock.model.ClockConfig
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Renders the background layer for a ClockConfig. Animated variants are
 * driven by a single rememberInfiniteTransition per visible clock and are
 * gated by [quality] — BATTERY_SAVER always resolves to a static frame so
 * no expensive animation loop runs, satisfying the "don't run expensive
 * animation when not needed" requirement together with the visibility
 * gating done by the caller (see ClockEngine.kt).
 */
@Composable
fun ClockBackground(
    config: ClockConfig,
    quality: AnimationQuality,
    modifier: Modifier = Modifier
) {
    val animated = quality != AnimationQuality.BATTERY_SAVER
    val primary = Color(config.primaryColor)
    val secondary = Color(config.secondaryColor)

    when (config.backgroundStyle) {
        BackgroundStyle.SOLID -> {
            Canvas(modifier = modifier.fillMaxSize()) {
                drawRect(Color(config.backgroundColors.first()))
            }
        }

        BackgroundStyle.AMOLED_BLACK -> {
            Canvas(modifier = modifier.fillMaxSize()) { drawRect(Color.Black) }
        }

        BackgroundStyle.GRADIENT -> {
            val colors = config.backgroundColors.map { Color(it) }
            Canvas(modifier = modifier.fillMaxSize()) {
                drawRect(
                    Brush.linearGradient(
                        colors = if (colors.size >= 2) colors else listOf(secondary, primary)
                    )
                )
            }
        }

        BackgroundStyle.ANIMATED_GRADIENT -> {
            val transition = rememberInfiniteTransition(label = "gradientAnim")
            val shift by transition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(6000, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "gradientShift"
            )
            val t = if (animated) shift else 0f
            Canvas(modifier = modifier.fillMaxSize()) {
                drawRect(
                    Brush.linearGradient(
                        colors = listOf(secondary, primary, secondary),
                        start = Offset(size.width * t, 0f),
                        end = Offset(size.width * (1f - t), size.height)
                    )
                )
            }
        }

        BackgroundStyle.GLASS -> {
            Canvas(modifier = modifier.fillMaxSize()) {
                drawRect(Color(0xFF15151F))
                drawRect(primary.copy(alpha = 0.08f))
            }
        }

        BackgroundStyle.STARS, BackgroundStyle.SPACE -> {
            val transition = rememberInfiniteTransition(label = "starTwinkle")
            val twinkle by transition.animateFloat(
                initialValue = 0.3f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2000, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "twinkle"
            )
            val alpha = if (animated) twinkle else 0.7f
            Canvas(modifier = modifier.fillMaxSize()) {
                drawRect(Color(0xFF04040A))
                drawStars(seed = config.id.hashCode(), alpha = alpha, tint = primary)
            }
        }

        BackgroundStyle.PARTICLES -> {
            val transition = rememberInfiniteTransition(label = "particleDrift")
            val drift by transition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(5000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "drift"
            )
            val progress = if (animated) drift else 0f
            Canvas(modifier = modifier.fillMaxSize()) {
                drawRect(Color.Black)
                drawParticles(seed = config.id.hashCode(), progress = progress, tint = primary)
            }
        }

        BackgroundStyle.AURORA -> {
            val transition = rememberInfiniteTransition(label = "aurora")
            val wave by transition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(8000, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "auroraWave"
            )
            val t = if (animated) wave else 0.5f
            Canvas(modifier = modifier.fillMaxSize()) {
                drawRect(Color(0xFF060614))
                drawAurora(t, primary, secondary)
            }
        }

        BackgroundStyle.ABSTRACT -> {
            Canvas(modifier = modifier.fillMaxSize()) {
                drawRect(Brush.radialGradient(listOf(secondary.copy(alpha = 0.35f), Color.Black)))
            }
        }
    }
}

private fun DrawScope.drawStars(seed: Int, alpha: Float, tint: Color) {
    val random = Random(seed)
    repeat(60) {
        val x = random.nextFloat() * size.width
        val y = random.nextFloat() * size.height
        val r = random.nextFloat() * 1.6f + 0.4f
        drawCircle(tint.copy(alpha = alpha * random.nextFloat().coerceIn(0.3f, 1f)), radius = r, center = Offset(x, y))
    }
}

private fun DrawScope.drawParticles(seed: Int, progress: Float, tint: Color) {
    val random = Random(seed)
    repeat(40) {
        val baseX = random.nextFloat() * size.width
        val baseY = (random.nextFloat() * size.height + progress * size.height) % size.height
        val r = random.nextFloat() * 2.5f + 0.5f
        drawCircle(tint.copy(alpha = 0.5f), radius = r, center = Offset(baseX, baseY))
    }
}

private fun DrawScope.drawAurora(t: Float, primary: Color, secondary: Color) {
    val waveHeight = size.height * 0.25f
    val midY = size.height * 0.4f
    for (band in 0 until 3) {
        val phase = t * 2 * Math.PI.toFloat() + band
        val color = if (band % 2 == 0) primary else secondary
        for (x in 0..20) {
            val fx = x / 20f * size.width
            val fy = midY + band * 40f + sin(phase + fx / size.width * 4) * waveHeight * 0.15f
            drawCircle(color.copy(alpha = 0.10f), radius = size.width / 14f, center = Offset(fx, fy))
        }
    }
}
