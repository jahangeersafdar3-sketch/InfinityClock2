package com.infinityclock.app.studio.render

import com.infinityclock.app.clock.util.TickTime
import com.infinityclock.app.studio.model.CanvasElement
import com.infinityclock.app.studio.model.ElementType

/** Resolves what a text-bound element should currently display from the real clock. */
fun resolveElementText(element: CanvasElement, time: TickTime, is24Hour: Boolean): String = when (element.type) {
    ElementType.HOURS -> (if (is24Hour) time.hour24 else time.hour12).toString().padStart(2, '0')
    ElementType.MINUTES -> time.minute.toString().padStart(2, '0')
    ElementType.SECONDS -> time.second.toString().padStart(2, '0')
    ElementType.DATE -> time.dayOfMonth.toString().padStart(2, '0')
    ElementType.DAY -> time.dayOfWeek
    ElementType.MONTH -> time.month
    ElementType.CUSTOM_TEXT -> element.text
    else -> ""
}
