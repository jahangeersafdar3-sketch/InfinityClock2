package com.infinityclock.app.notif

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

object NotificationChannels {
    const val TIMER_CHANNEL_ID = "infinity_clock_timer"
    const val ALARM_CHANNEL_ID = "infinity_clock_alarm"

    fun ensureCreated(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (manager.getNotificationChannel(TIMER_CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(TIMER_CHANNEL_ID, "Timer", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Countdown timer completion alerts"
                }
            )
        }
        if (manager.getNotificationChannel(ALARM_CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(ALARM_CHANNEL_ID, "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Alarm clock alerts"
                    setBypassDnd(true)
                }
            )
        }
    }
}
