package com.infinityclock.app.ui.worldclock

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.infinityclock.app.viewmodel.WorldClockViewModel
import com.infinityclock.app.worldclock.TimeZoneCatalog
import com.infinityclock.app.worldclock.WorldClockEntry
import com.infinityclock.app.worldclock.computeNowFor
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorldClockScreen(onBack: () -> Unit, viewModel: WorldClockViewModel = viewModel()) {
    val entries by viewModel.entries.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    // Real elapsed-time tick, not a naive per-second UI-only counter: this
    // just triggers recomposition every second; each row recomputes its
    // displayed time from the real system clock + that city's actual
    // timezone data via computeNowFor().
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            tick++
        }
    }

    if (showAddDialog) {
        AddCityDialog(
            alreadyAdded = entries.map { it.zoneId to it.city },
            onDismiss = { showAddDialog = false },
            onAdd = { city ->
                viewModel.add(WorldClockEntry(city = city.city, country = city.country, zoneId = city.zoneId))
                showAddDialog = false
            }
        )
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("World Clock") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add city")
            }
        }
    ) { padding ->
        if (entries.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("No cities yet — tap + to add one.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(entries.sortedByDescending { it.isFavorite }, key = { it.id }) { entry ->
                    @Suppress("UNUSED_EXPRESSION") tick // read to force recomposition each second
                    val now = computeNowFor(entry.zoneId)
                    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(entry.city, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${entry.country} · ${now.dayOfWeek}, ${now.month} ${now.dayOfMonth} · ${now.utcOffsetLabel}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "${now.hour24.toString().padStart(2, '0')}:${now.minute.toString().padStart(2, '0')}",
                                style = MaterialTheme.typography.headlineSmall
                            )
                            IconButton(onClick = { viewModel.toggleFavorite(entry.id) }) {
                                Icon(
                                    if (entry.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (entry.isFavorite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { viewModel.moveUp(entry.id) }) {
                                Icon(Icons.Filled.ArrowUpward, contentDescription = "Move up")
                            }
                            IconButton(onClick = { viewModel.moveDown(entry.id) }) {
                                Icon(Icons.Filled.ArrowDownward, contentDescription = "Move down")
                            }
                            IconButton(onClick = { viewModel.remove(entry.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Remove")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddCityDialog(
    alreadyAdded: List<Pair<String, String>>,
    onDismiss: () -> Unit,
    onAdd: (com.infinityclock.app.worldclock.CityTimeZone) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val results = remember(query) {
        TimeZoneCatalog.filter {
            (it.city.contains(query, ignoreCase = true) || it.country.contains(query, ignoreCase = true)) &&
                (it.zoneId to it.city) !in alreadyAdded
        }.take(30)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a City") },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search city or country") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(modifier = Modifier.padding(top = 8.dp)) {
                    items(results) { city ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .clickable { onAdd(city) },
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${city.city}, ${city.country}")
                            Text(city.zoneId, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
