package com.infinityclock.app.widget.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Glance/RemoteViews widgets cannot host a Compose Canvas, so an analog or
 * hybrid widget face is rendered into a plain Android Bitmap using
 * android.graphics directly, then shown via Glance's Image(ImageProvider).
 * This mirrors clock/engine/AnalogClock.kt's hand math so a widget's analog
 * face matches the in-app analog face.
 */
object WidgetBitmapRenderer {

    fun renderAnalogFace(
        widthPx: Int,
        heightPx: Int,
        primaryColor: Long,
        secondaryColor: Long,
        accentColor: Long,
        hour24: Int,
        minute: Int,
        second: Int
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(widthPx.coerceAtLeast(1), heightPx.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val radius = min(widthPx, heightPx) / 2f * 0.92f
        val cx = widthPx / 2f
        val cy = heightPx / 2f

        val dialPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(40, 255, 255, 255)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(cx, cy, radius, dialPaint)

        val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = argbFromLong(primaryColor)
            style = Paint.Style.STROKE
            strokeWidth = radius * 0.03f
        }
        canvas.drawCircle(cx, cy, radius, ringPaint)

        val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = argbFromLong(secondaryColor)
            strokeWidth = radius * 0.02f
        }
        for (i in 0 until 12) {
            val angle = (i / 12f) * 2 * Math.PI.toFloat() - Math.PI.toFloat() / 2f
            val outer = radius * 0.95f
            val inner = radius * 0.82f
            canvas.drawLine(
                cx + cos(angle) * inner, cy + sin(angle) * inner,
                cx + cos(angle) * outer, cy + sin(angle) * outer,
                tickPaint
            )
        }

        val hourFraction = (hour24 % 12) + minute / 60f
        drawHand(canvas, cx, cy, hourFraction / 12f * 360f, radius * 0.5f, radius * 0.045f, argbFromLong(primaryColor))
        val minuteFraction = minute + second / 60f
        drawHand(canvas, cx, cy, minuteFraction / 60f * 360f, radius * 0.72f, radius * 0.03f, argbFromLong(primaryColor))
        drawHand(canvas, cx, cy, second / 60f * 360f, radius * 0.85f, radius * 0.015f, argbFromLong(accentColor))

        val hubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = argbFromLong(accentColor) }
        canvas.drawCircle(cx, cy, radius * 0.04f, hubPaint)

        return bitmap
    }

    private fun drawHand(canvas: Canvas, cx: Float, cy: Float, angleDegrees: Float, length: Float, width: Float, color: Int) {
        val angle = Math.toRadians((angleDegrees - 90f).toDouble())
        val tipX = cx + (cos(angle) * length).toFloat()
        val tipY = cy + (sin(angle) * length).toFloat()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            strokeWidth = width
            strokeCap = Paint.Cap.ROUND
        }
        canvas.drawLine(cx, cy, tipX, tipY, paint)
    }

    private fun argbFromLong(value: Long): Int = value.toInt()
}
