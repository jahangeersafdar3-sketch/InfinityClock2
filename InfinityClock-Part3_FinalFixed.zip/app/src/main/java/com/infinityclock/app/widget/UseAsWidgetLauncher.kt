package com.infinityclock.app.widget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import com.infinityclock.app.common.ClockRef

sealed class UseAsWidgetResult {
    object Requested : UseAsWidgetResult()
    object UnsupportedLauncher : UseAsWidgetResult()
}

/**
 * The real "Use as Widget" flow (Part 2, section 11): uses the official
 * AppWidgetManager.requestPinAppWidget API (Android 8+) to ask the current
 * launcher to pin one of our providers directly. The provider's manifest
 * `configure` activity (WidgetConfigurationActivity) is then auto-launched
 * by the system the moment pinning succeeds, pre-selecting the clock the
 * user tapped via PendingWidgetSelection.
 *
 * Older or non-conforming launchers don't support this API —
 * isRequestPinAppWidgetSupported() tells us honestly, and the caller should
 * fall back to pointing the user at the normal widget picker (Home Screen →
 * Widgets → Infinity Clock) instead of pretending pinning happened.
 */
object UseAsWidgetLauncher {

    fun requestPin(context: Context, ref: ClockRef, preferAnalog: Boolean): UseAsWidgetResult {
        val appWidgetManager = context.getSystemService(Context.APPWIDGET_SERVICE) as? AppWidgetManager
            ?: return UseAsWidgetResult.UnsupportedLauncher

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || !appWidgetManager.isRequestPinAppWidgetSupported) {
            return UseAsWidgetResult.UnsupportedLauncher
        }

        val providerClass = if (preferAnalog) AnalogClockWidgetLargeReceiver::class.java else DigitalClockWidgetMediumReceiver::class.java
        val provider = ComponentName(context, providerClass)

        return try {
            PendingWidgetSelection.set(ref)
            appWidgetManager.requestPinAppWidget(provider, null, null)
            UseAsWidgetResult.Requested
        } catch (e: IllegalArgumentException) {
            UseAsWidgetResult.UnsupportedLauncher
        }
    }
}
