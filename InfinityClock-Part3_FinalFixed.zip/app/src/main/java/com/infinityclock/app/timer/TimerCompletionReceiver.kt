package com.infinityclock.app.timer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.infinityclock.app.MainActivity
import com.infinityclock.app.notif.AlertPlayer
import com.infinityclock.app.notif.NotificationChannels

/** Holds the currently-ringing alert so the notification's Stop action can silence it. */
private object TimerAlertHolder {
    var player: AlertPlayer? = null
}

class TimerCompletionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_TIMER_COMPLETE = "com.infinityclock.app.timer.ACTION_TIMER_COMPLETE"
        const val ACTION_STOP_TIMER_ALERT = "com.infinityclock.app.timer.ACTION_STOP_TIMER_ALERT"
        private const val NOTIFICATION_ID = 9001
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_TIMER_COMPLETE -> {
                NotificationChannels.ensureCreated(context)
                val player = AlertPlayer(context)
                TimerAlertHolder.player = player
                player.start(sound = true, vibrate = true, useAlarmSound = true)

                val contentIntent = PendingIntent.getActivity(
                    context, 0, Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
                )
                val stopIntent = Intent(context, TimerCompletionReceiver::class.java).apply { action = ACTION_STOP_TIMER_ALERT }
                val stopPendingIntent = PendingIntent.getBroadcast(
                    context, 1, stopIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
                )

                val notification = NotificationCompat.Builder(context, NotificationChannels.TIMER_CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle("Timer finished")
                    .setContentText("Tap Stop to silence the alert.")
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setAutoCancel(true)
                    .setContentIntent(contentIntent)
                    .addAction(0, "Stop", stopPendingIntent)
                    .build()

                if (hasNotificationPermission(context)) {
                    NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
                }
            }
            ACTION_STOP_TIMER_ALERT -> {
                TimerAlertHolder.player?.stop()
                TimerAlertHolder.player = null
                NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
            }
        }
    }

    private fun hasNotificationPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.POST_NOTIFICATIONS
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}
