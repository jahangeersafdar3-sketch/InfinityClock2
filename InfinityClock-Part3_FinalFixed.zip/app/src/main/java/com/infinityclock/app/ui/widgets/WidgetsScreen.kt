package com.infinityclock.app.ui.widgets

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.infinityclock.app.common.ClockRef
import com.infinityclock.app.common.ClockRefKind
import com.infinityclock.app.viewmodel.AppViewModel
import com.infinityclock.app.widget.UseAsWidgetLauncher
import com.infinityclock.app.widget.UseAsWidgetResult

private data class WidgetTypeInfo(val title: String, val size: String, val description: String, val analog: Boolean)

private val widgetTypes = listOf(
    WidgetTypeInfo("Digital Small", "~2×1 cells", "A compact time readout for tight spaces.", analog = false),
    WidgetTypeInfo("Digital Medium", "~3×2 cells", "Time, date and day at a glance.", analog = false),
    WidgetTypeInfo("Analog Large", "~4×4 cells", "A full analog face matching your chosen clock's colors.", analog = true),
    WidgetTypeInfo("Hybrid Extra Large", "~5×4 cells", "The biggest layout, with full date details.", analog = true)
)

/**
 * Real home-screen widgets (Part 2): four working Glance-based AppWidget
 * providers actually registered in the manifest and visible in Android's
 * widget picker (Home Screen → Widgets → Infinity Clock). This screen lets
 * the user pin one directly via requestPinAppWidget when the launcher
 * supports it, and otherwise points them at the manual picker — it is a
 * setup hub, not a substitute for the real widget.
 */
@Composable
fun WidgetsScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val selectedClock by viewModel.selectedClock.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("Widgets") }) }) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Add a live Infinity Clock widget to your home screen. Each widget " +
                        "you add gets its own clock choice and settings — set that up right " +
                        "after adding it.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(widgetTypes) { info ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Widgets, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(info.title, style = MaterialTheme.typography.titleMedium)
                            Text(info.size, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(info.description, style = MaterialTheme.typography.bodyMedium)
                        }
                        Button(onClick = {
                            val result = UseAsWidgetLauncher.requestPin(
                                context,
                                ClockRef(ClockRefKind.STANDARD, selectedClock.id),
                                preferAnalog = info.analog
                            )
                            val message = when (result) {
                                is UseAsWidgetResult.Requested -> "Pinning — finish setup in the prompt that appears."
                                is UseAsWidgetResult.UnsupportedLauncher -> "Your launcher doesn't support quick-pinning. Add manually: Home Screen → Widgets → Infinity Clock."
                            }
                            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                        }) { Text("Add") }
                    }
                }
            }
            item {
                Text(
                    "Can't find the quick-add option? Every launcher also lets you add widgets " +
                        "manually: long-press your home screen → Widgets → Infinity Clock.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
