package com.infinityclock.app.theme

import androidx.compose.ui.graphics.Color

// Core brand palette used by app chrome (nav bar, app bars, generic surfaces).
// Individual clock presets carry their own colors via ClockConfig and are
// intentionally independent of these values.

val InfinityPurple = Color(0xFF6C5CE7)
val InfinityCyan = Color(0xFF00D4FF)
val InfinityPink = Color(0xFFFF4D8D)

val DarkBackground = Color(0xFF0B0B14)
val DarkSurface = Color(0xFF15151F)
val DarkSurfaceVariant = Color(0xFF1E1E2C)
val AmoledBackground = Color(0xFF000000)

val LightBackground = Color(0xFFF6F6FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFECECF6)

val TextPrimaryDark = Color(0xFFF5F5FA)
val TextSecondaryDark = Color(0xFFA0A0B8)

val TextPrimaryLight = Color(0xFF141420)
val TextSecondaryLight = Color(0xFF5A5A72)
