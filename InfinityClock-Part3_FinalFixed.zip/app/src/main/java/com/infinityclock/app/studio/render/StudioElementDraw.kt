package com.infinityclock.app.studio.render

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.nativeCanvas
import com.infinityclock.app.studio.model.CanvasElement
import com.infinityclock.app.studio.model.ElementFont
import com.infinityclock.app.studio.model.ElementType
import com.infinityclock.app.studio.model.isText

private fun androidPaintFor(element: CanvasElement, sizePx: Float): android.graphics.Paint =
    android.graphics.Paint().apply {
        isAntiAlias = true
        color = android.graphics.Color.argb(
            (element.opacity * 255).toInt(),
            ((element.primaryColor shr 16) and 0xFF).toInt(),
            ((element.primaryColor shr 8) and 0xFF).toInt(),
            (element.primaryColor and 0xFF).toInt()
        )
        textAlign = android.graphics.Paint.Align.CENTER
        textSize = sizePx
        isFakeBoldText = element.bold
        typeface = when (element.font) {
            ElementFont.SYSTEM -> android.graphics.Typeface.DEFAULT
            ElementFont.MONO -> android.graphics.Typeface.MONOSPACE
            ElementFont.SERIF -> android.graphics.Typeface.SERIF
            ElementFont.CONDENSED -> android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.NORMAL)
            ElementFont.ROUNDED -> android.graphics.Typeface.SANS_SERIF
        }
        if (element.hasShadow || element.hasGlow) {
            val glowRadius = if (element.hasGlow) 8f + element.glowIntensity * 24f else 6f
            val glowArgb = android.graphics.Color.argb(
                180,
                ((element.glowColor shr 16) and 0xFF).toInt(),
                ((element.glowColor shr 8) and 0xFF).toInt(),
                (element.glowColor and 0xFF).toInt()
            )
            setShadowLayer(glowRadius, 0f, if (element.hasShadow) 3f else 0f, glowArgb)
        }
    }

/**
 * Draws one CanvasElement into [DrawScope] local coordinates (0,0 at the
 * element's own top-left, spanning [widthPx] x [heightPx]) — the caller is
 * responsible for translating/rotating to the element's canvas position via
 * a graphicsLayer, so this function only needs to know its own local size.
 */
fun DrawScope.drawCanvasElement(
    element: CanvasElement,
    widthPx: Float,
    heightPx: Float,
    displayText: String
) {
    if (!element.visible) return

    val primary = Color(element.primaryColor).copy(alpha = element.opacity)
    val secondary = Color(element.secondaryColor).copy(alpha = element.opacity)

    when (element.type) {
        ElementType.BACKGROUND -> {
            if (element.useGradient) {
                drawRect(androidx.compose.ui.graphics.Brush.linearGradient(listOf(primary, secondary)))
            } else {
                drawRect(primary)
            }
        }

        ElementType.SHAPE_RECT -> drawShapeGlow(element, widthPx, heightPx) {
            if (element.filled) drawRect(primary, size = Size(widthPx, heightPx))
            if (element.strokeWidth > 0) drawRect(Color(element.strokeColor), size = Size(widthPx, heightPx), style = Stroke(element.strokeWidth))
        }

        ElementType.SHAPE_CIRCLE, ElementType.GLOW_ORB -> drawShapeGlow(element, widthPx, heightPx) {
            val r = minOf(widthPx, heightPx) / 2f
            val center = Offset(widthPx / 2f, heightPx / 2f)
            if (element.filled) drawCircle(primary, radius = r, center = center)
            if (element.strokeWidth > 0) drawCircle(Color(element.strokeColor), radius = r, center = center, style = Stroke(element.strokeWidth))
        }

        ElementType.SHAPE_LINE -> drawShapeGlow(element, widthPx, heightPx) {
            drawLine(primary, Offset(0f, heightPx / 2f), Offset(widthPx, heightPx / 2f), strokeWidth = maxOf(element.strokeWidth, 3f))
        }

        ElementType.DECORATIVE -> drawShapeGlow(element, widthPx, heightPx) {
            val r = minOf(widthPx, heightPx) / 2f
            val center = Offset(widthPx / 2f, heightPx / 2f)
            for (i in 0 until 6) {
                val angle = i / 6f * 2 * Math.PI.toFloat()
                val dotCenter = Offset(center.x + kotlin.math.cos(angle) * r * 0.7f, center.y + kotlin.math.sin(angle) * r * 0.7f)
                drawCircle(primary, radius = r * 0.15f, center = dotCenter)
            }
        }

        ElementType.PARTICLES -> {
            val random = kotlin.random.Random(element.id.hashCode())
            repeat(24) {
                val x = random.nextFloat() * widthPx
                val y = random.nextFloat() * heightPx
                drawCircle(primary.copy(alpha = element.opacity * 0.6f), radius = 1.5f + random.nextFloat() * 2f, center = Offset(x, y))
            }
        }

        else -> if (element.type.isText() && displayText.isNotEmpty()) {
            drawTextElement(element, widthPx, heightPx, displayText)
        }
    }
}

private inline fun DrawScope.drawShapeGlow(element: CanvasElement, widthPx: Float, heightPx: Float, draw: DrawScope.() -> Unit) {
    if (element.hasGlow) {
        val glow = Color(element.glowColor)
        val steps = 4
        for (i in steps downTo 1) {
            val scaleFactor = 1f + (i * element.glowIntensity * 0.06f)
            val alpha = (0.10f * element.glowIntensity) * (steps - i + 1) / steps
            translate(left = -(widthPx * (scaleFactor - 1f) / 2f), top = -(heightPx * (scaleFactor - 1f) / 2f)) {
                scale(scaleFactor, pivot = Offset(widthPx * scaleFactor / 2f, heightPx * scaleFactor / 2f)) {
                    drawRect(glow.copy(alpha = alpha), size = Size(widthPx, heightPx))
                }
            }
        }
    }
    draw()
}

private fun DrawScope.drawTextElement(element: CanvasElement, widthPx: Float, heightPx: Float, text: String) {
    val paint = androidPaintFor(element, heightPx * 0.7f)
    drawContext.canvas.nativeCanvas.drawText(
        text,
        widthPx / 2f,
        heightPx / 2f + paint.textSize * 0.35f,
        paint
    )
}
