package com.infinityclock.app.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.infinityclock.app.BuildConfig
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.data.ExportImportManager
import com.infinityclock.app.theme.AppThemeMode
import com.infinityclock.app.viewmodel.AppViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(viewModel: AppViewModel) {
    val settings by viewModel.settings.collectAsState()
    var showResetDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val exportImportManager = remember { ExportImportManager(context) }
    var importResultMessage by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            scope.launch {
                context.contentResolver.openOutputStream(uri)?.use { exportImportManager.exportAll(it) }
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val result = exportImportManager.importAll(stream)
                    importResultMessage = "Imported ${result.customClocksImported} custom clock(s) and ${result.studioClocksImported} Studio clock(s)."
                }
            }
        }
    }

    if (importResultMessage != null) {
        AlertDialog(
            onDismissRequest = { importResultMessage = null },
            title = { Text("Import Complete") },
            text = { Text(importResultMessage ?: "") },
            confirmButton = { Button(onClick = { importResultMessage = null }) { Text("OK") } }
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset settings?") },
            text = { Text("This restores all settings on this screen to their defaults. Your saved custom clocks are not affected.") },
            confirmButton = {
                Button(onClick = { viewModel.resetSettings(); showResetDialog = false }) { Text("Reset") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Settings") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            item { SettingsSection("Time Display") }
            item {
                SwitchRow("24-hour format", settings.is24Hour) { viewModel.setIs24Hour(it) }
            }
            item {
                SwitchRow("Show seconds", settings.showSeconds) { viewModel.setShowSeconds(it) }
            }
            item {
                SwitchRow("Show date", settings.showDate) { viewModel.setShowDate(it) }
            }
            item {
                SwitchRow("Show day", settings.showDay) { viewModel.setShowDay(it) }
            }

            item { Divider(modifier = Modifier.padding(vertical = 12.dp)) }
            item { SettingsSection("Appearance") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(AppThemeMode.values().toList()) { mode ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { viewModel.setThemeMode(mode) },
                            label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                        )
                    }
                }
            }

            item { Divider(modifier = Modifier.padding(vertical = 12.dp)) }
            item { SettingsSection("Animation") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(AnimationQuality.values().toList()) { quality ->
                        FilterChip(
                            selected = settings.animationQuality == quality,
                            onClick = { viewModel.setAnimationQuality(quality) },
                            label = { Text(quality.name.replace('_', ' ')) }
                        )
                    }
                }
            }
            item {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    Text(
                        "Global animation speed (${String.format("%.1fx", settings.animationSpeed)})",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Slider(
                        value = settings.animationSpeed,
                        onValueChange = { viewModel.setAnimationSpeed(it) },
                        valueRange = 0.25f..2.5f
                    )
                }
            }

            item { Divider(modifier = Modifier.padding(vertical = 12.dp)) }
            item { SettingsSection("Feedback") }
            item {
                SwitchRow("Haptic feedback", settings.hapticFeedback) { viewModel.setHapticFeedback(it) }
            }

            item { Divider(modifier = Modifier.padding(vertical = 12.dp)) }
            item {
                OutlinedButton(onClick = { showResetDialog = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Reset Settings")
                }
            }

            item { Divider(modifier = Modifier.padding(vertical = 12.dp)) }
            item { SettingsSection("Data Safety") }
            item {
                Text(
                    "Your custom clocks and Studio designs are always stored on this device only — no account, no cloud. Export them to a file to back up or move to another device.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    OutlinedButton(
                        onClick = { exportLauncher.launch("infinity-clock-backup.json") },
                        modifier = Modifier.weight(1f)
                    ) { Text("Export") }
                    OutlinedButton(
                        onClick = { importLauncher.launch(arrayOf("application/json")) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Import") }
                }
            }

            item { Divider(modifier = Modifier.padding(vertical = 12.dp)) }
            item { SettingsSection("About") }
            item {
                Text(
                    "Infinity Clock\nVersion ${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(vertical = 4.dp))
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
