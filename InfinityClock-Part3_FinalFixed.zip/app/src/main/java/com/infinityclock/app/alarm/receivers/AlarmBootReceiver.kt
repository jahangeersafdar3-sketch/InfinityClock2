package com.infinityclock.app.alarm.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.infinityclock.app.alarm.AlarmScheduler
import com.infinityclock.app.data.AlarmRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * AlarmManager alarms do NOT survive a device reboot — Android clears them
 * all. Real alarm-clock apps must re-register every enabled alarm on boot,
 * which is exactly what this does (and BOOT_COMPLETED is on the static-
 * broadcast exemption list, so a manifest receiver is correct here).
 */
class AlarmBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repository = AlarmRepository(context)
                repository.all().filter { it.enabled }.forEach { alarm ->
                    AlarmScheduler.schedule(context, alarm)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
