package com.infinityclock.app.stopwatch

import org.json.JSONArray
import org.json.JSONObject

/**
 * Stopwatch state persisted using SystemClock.elapsedRealtime() anchors,
 * not accumulated per-tick counters — resuming after the app is backgrounded
 * or killed recomputes the correct elapsed time from real clock math instead
 * of drifting.
 */
data class StopwatchState(
    val running: Boolean = false,
    val accumulatedMillis: Long = 0L,
    val startElapsedRealtime: Long = 0L,
    val laps: List<Long> = emptyList() // each lap stored as total elapsed millis at the moment it was recorded
) {
    fun currentElapsedMillis(nowElapsedRealtime: Long): Long =
        if (running) accumulatedMillis + (nowElapsedRealtime - startElapsedRealtime) else accumulatedMillis

    fun toJson(): JSONObject = JSONObject().apply {
        put("running", running)
        put("accumulatedMillis", accumulatedMillis)
        put("startElapsedRealtime", startElapsedRealtime)
        put("laps", JSONArray(laps))
    }

    companion object {
        fun fromJson(j: JSONObject): StopwatchState {
            val lapsArray = j.optJSONArray("laps") ?: JSONArray()
            return StopwatchState(
                running = j.optBoolean("running", false),
                accumulatedMillis = j.optLong("accumulatedMillis", 0L),
                startElapsedRealtime = j.optLong("startElapsedRealtime", 0L),
                laps = (0 until lapsArray.length()).map { lapsArray.getLong(it) }
            )
        }
    }
}

fun formatElapsed(millis: Long): String {
    val totalCentis = millis / 10
    val centis = totalCentis % 100
    val totalSeconds = totalCentis / 100
    val seconds = totalSeconds % 60
    val totalMinutes = totalSeconds / 60
    val minutes = totalMinutes % 60
    val hours = totalMinutes / 60
    return if (hours > 0) {
        "%d:%02d:%02d.%02d".format(hours, minutes, seconds, centis)
    } else {
        "%02d:%02d.%02d".format(minutes, seconds, centis)
    }
}
