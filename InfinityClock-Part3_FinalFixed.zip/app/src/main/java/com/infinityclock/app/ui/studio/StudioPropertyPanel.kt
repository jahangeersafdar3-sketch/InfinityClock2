package com.infinityclock.app.ui.studio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.infinityclock.app.clock.presets.CuratedPalettes
import com.infinityclock.app.clock.presets.Palette
import com.infinityclock.app.studio.model.CanvasElement
import com.infinityclock.app.studio.model.ElementAnimationPreset
import com.infinityclock.app.studio.model.ElementFont
import com.infinityclock.app.studio.model.ElementType
import com.infinityclock.app.studio.model.isShape
import com.infinityclock.app.studio.model.isText

/**
 * The property editor for the currently selected canvas element. Every
 * control here writes straight back into the element via [onChange], which
 * StudioViewModel wraps with an undo snapshot — so every one of these
 * (opacity/color/gradient/font/size/stroke/shadow/glow/visibility/
 * animation) is a real, working control per the Part 2 brief.
 */
@Composable
fun StudioPropertyPanel(
    element: CanvasElement,
    onChange: (CanvasElement.() -> CanvasElement) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(element.name, style = MaterialTheme.typography.titleMedium)

        if (element.type.isText()) {
            if (element.type == ElementType.CUSTOM_TEXT) {
                OutlinedTextField(
                    value = element.text,
                    onValueChange = { newText -> onChange { copy(text = newText) } },
                    label = { Text("Text") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Text("Font", style = MaterialTheme.typography.bodyMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ElementFont.values().toList()) { font ->
                    FilterChip(
                        selected = element.font == font,
                        onClick = { onChange { copy(font = font) } },
                        label = { Text(font.name) }
                    )
                }
            }
            LabeledSlider("Font size (${element.fontSizeSp.toInt()}sp)", element.fontSizeSp, 10f..96f) {
                onChange { copy(fontSizeSp = it) }
            }
            ToggleRow("Bold", element.bold) { onChange { copy(bold = it) } }
        }

        Text("Color", style = MaterialTheme.typography.bodyMedium)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(CuratedPalettes) { pal: Palette ->
                ColorSwatch(pal, element.primaryColor == pal.primary) {
                    onChange { copy(primaryColor = pal.primary, secondaryColor = pal.secondary) }
                }
            }
        }
        ToggleRow("Use gradient", element.useGradient) { onChange { copy(useGradient = it) } }
        if (element.useGradient) {
            LabeledSlider("Gradient angle (${element.gradientAngle.toInt()}°)", element.gradientAngle, 0f..360f) {
                onChange { copy(gradientAngle = it) }
            }
        }

        LabeledSlider("Opacity (${(element.opacity * 100).toInt()}%)", element.opacity, 0.05f..1f) {
            onChange { copy(opacity = it) }
        }
        LabeledSlider("Rotation (${element.rotationDegrees.toInt()}°)", element.rotationDegrees, -180f..180f) {
            onChange { copy(rotationDegrees = it) }
        }

        if (element.type.isShape()) {
            ToggleRow("Filled", element.filled) { onChange { copy(filled = it) } }
            LabeledSlider("Stroke width (${element.strokeWidth.toInt()}px)", element.strokeWidth, 0f..20f) {
                onChange { copy(strokeWidth = it) }
            }
        }

        ToggleRow("Shadow", element.hasShadow) { onChange { copy(hasShadow = it) } }
        ToggleRow("Glow", element.hasGlow) { onChange { copy(hasGlow = it) } }
        if (element.hasGlow) {
            LabeledSlider("Glow intensity (${(element.glowIntensity * 100).toInt()}%)", element.glowIntensity, 0.1f..1f) {
                onChange { copy(glowIntensity = it) }
            }
        }

        Text("Animation", style = MaterialTheme.typography.bodyMedium)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ElementAnimationPreset.values().toList()) { preset ->
                FilterChip(
                    selected = element.animation == preset,
                    onClick = { onChange { copy(animation = preset) } },
                    label = { Text(preset.name.replace('_', ' ')) }
                )
            }
        }
        if (element.animation != ElementAnimationPreset.NONE) {
            LabeledSlider("Animation speed (${String.format("%.1fx", element.animationSpeedMultiplier)})", element.animationSpeedMultiplier, 0.25f..3f) {
                onChange { copy(animationSpeedMultiplier = it) }
            }
        }

        ToggleRow("Visible", element.visible) { onChange { copy(visible = it) } }
    }
}

@Composable
private fun ColorSwatch(palette: Palette, selected: Boolean, onClick: () -> Unit) {
    Column {
        androidx.compose.foundation.layout.Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .clickable(onClick = onClick)
        ) {
            Canvas(modifier = Modifier.fillMaxWidth().size(36.dp)) {
                drawCircle(
                    androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(palette.primary), Color(palette.secondary)))
                )
                if (selected) drawCircle(Color.White, style = Stroke(width = 3f))
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}
