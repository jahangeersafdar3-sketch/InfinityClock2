package com.infinityclock.app.data

import android.content.Context
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.studio.model.StudioClockConfig
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

data class ImportResult(val customClocksImported: Int, val studioClocksImported: Int)

/**
 * Exports/imports the user's own custom clocks (Part 1 quick-customized
 * ClockConfig items) and Studio designs (Part 2) to/from a user-chosen file
 * via the Storage Access Framework — no cloud account, no server, the file
 * lives wherever the user picks (local storage, SD card, or a synced folder
 * they manage themselves).
 */
class ExportImportManager(private val context: Context) {
    private val clockRepository = ClockRepository(context)
    private val studioRepository = StudioRepository(context)

    suspend fun exportAll(outputStream: OutputStream) {
        val customClocks = clockRepository.customClocksFlow.first()
        val studioClocks = studioRepository.clocksFlow.first()

        val root = JSONObject().apply {
            put("formatVersion", 1)
            put("exportedAt", System.currentTimeMillis())
            put("customClocks", JSONArray(customClocks.map { it.toJson() }))
            put("studioClocks", JSONArray(studioClocks.map { it.toJson() }))
        }
        outputStream.bufferedWriter().use { it.write(root.toString()) }
    }

    /** New random IDs are assigned to every imported clock so importing can
     * never silently overwrite something already on this device. */
    suspend fun importAll(inputStream: InputStream): ImportResult {
        val text = inputStream.bufferedReader().use { it.readText() }
        val root = JSONObject(text)

        var customCount = 0
        val customArray = root.optJSONArray("customClocks")
        if (customArray != null) {
            for (i in 0 until customArray.length()) {
                val config = ClockConfig.fromJson(customArray.getJSONObject(i)).copy(
                    id = UUID.randomUUID().toString(),
                    isCustom = true,
                    modifiedAt = System.currentTimeMillis()
                )
                clockRepository.saveCustomClock(config)
                customCount++
            }
        }

        var studioCount = 0
        val studioArray = root.optJSONArray("studioClocks")
        if (studioArray != null) {
            for (i in 0 until studioArray.length()) {
                val config = StudioClockConfig.fromJson(studioArray.getJSONObject(i)).copy(
                    id = UUID.randomUUID().toString(),
                    modifiedAt = System.currentTimeMillis()
                )
                studioRepository.save(config)
                studioCount++
            }
        }

        return ImportResult(customCount, studioCount)
    }
}
