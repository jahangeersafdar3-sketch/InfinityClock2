package com.infinityclock.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.theme.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "infinity_clock_settings")

data class AppSettings(
    val is24Hour: Boolean = true,
    val showSeconds: Boolean = true,
    val showDate: Boolean = true,
    val showDay: Boolean = true,
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val animationQuality: AnimationQuality = AnimationQuality.BALANCED,
    val animationSpeed: Float = 1f,
    val hapticFeedback: Boolean = true,
    val selectedClockId: String? = null
)

/**
 * Every field here is a real DataStore-backed preference — reading these
 * screens' switches always reflects what's actually persisted, and toggling
 * them actually rewrites the DataStore value (see SettingsScreen.kt).
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val IS_24_HOUR = booleanPreferencesKey("is_24_hour")
        val SHOW_SECONDS = booleanPreferencesKey("show_seconds")
        val SHOW_DATE = booleanPreferencesKey("show_date")
        val SHOW_DAY = booleanPreferencesKey("show_day")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ANIMATION_QUALITY = stringPreferencesKey("animation_quality")
        val ANIMATION_SPEED = floatPreferencesKey("animation_speed")
        val HAPTIC_FEEDBACK = booleanPreferencesKey("haptic_feedback")
        val SELECTED_CLOCK_ID = stringPreferencesKey("selected_clock_id")
    }

    val settingsFlow: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        AppSettings(
            is24Hour = prefs[Keys.IS_24_HOUR] ?: true,
            showSeconds = prefs[Keys.SHOW_SECONDS] ?: true,
            showDate = prefs[Keys.SHOW_DATE] ?: true,
            showDay = prefs[Keys.SHOW_DAY] ?: true,
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { AppThemeMode.valueOf(it) }.getOrNull() } ?: AppThemeMode.SYSTEM,
            animationQuality = prefs[Keys.ANIMATION_QUALITY]?.let { runCatching { AnimationQuality.valueOf(it) }.getOrNull() } ?: AnimationQuality.BALANCED,
            animationSpeed = prefs[Keys.ANIMATION_SPEED] ?: 1f,
            hapticFeedback = prefs[Keys.HAPTIC_FEEDBACK] ?: true,
            selectedClockId = prefs[Keys.SELECTED_CLOCK_ID]
        )
    }

    suspend fun setIs24Hour(value: Boolean) = context.settingsDataStore.edit { it[Keys.IS_24_HOUR] = value }
    suspend fun setShowSeconds(value: Boolean) = context.settingsDataStore.edit { it[Keys.SHOW_SECONDS] = value }
    suspend fun setShowDate(value: Boolean) = context.settingsDataStore.edit { it[Keys.SHOW_DATE] = value }
    suspend fun setShowDay(value: Boolean) = context.settingsDataStore.edit { it[Keys.SHOW_DAY] = value }
    suspend fun setThemeMode(value: AppThemeMode) = context.settingsDataStore.edit { it[Keys.THEME_MODE] = value.name }
    suspend fun setAnimationQuality(value: AnimationQuality) = context.settingsDataStore.edit { it[Keys.ANIMATION_QUALITY] = value.name }
    suspend fun setAnimationSpeed(value: Float) = context.settingsDataStore.edit { it[Keys.ANIMATION_SPEED] = value }
    suspend fun setHapticFeedback(value: Boolean) = context.settingsDataStore.edit { it[Keys.HAPTIC_FEEDBACK] = value }
    suspend fun setSelectedClockId(value: String?) = context.settingsDataStore.edit {
        if (value == null) it.remove(Keys.SELECTED_CLOCK_ID) else it[Keys.SELECTED_CLOCK_ID] = value
    }

    suspend fun resetAll() = context.settingsDataStore.edit { it.clear() }
}
