package com.infinityclock.app.widget

import android.content.Context
import androidx.glance.GlanceId
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import com.infinityclock.app.data.WidgetConfigRepository
import kotlinx.coroutines.launch

class DigitalClockWidgetMedium : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val appWidgetId = GlanceAppWidgetManager(context).getAppWidgetId(id)
        val config = WidgetConfigRepository(context).get(appWidgetId)
        val resolved = resolveWidgetClock(context, config?.clockRef)
        provideContent {
            InfinityWidgetContent(WidgetSizeCategory.MEDIUM, resolved, config)
        }
    }
}

class DigitalClockWidgetMediumReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = DigitalClockWidgetMedium()
    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        WidgetUpdateScheduler.startIfNeeded(context)
    }

    // onDeleted (not onDisabled) is where we know exactly which instance IDs
    // were removed, across ALL four widget types sharing one config store —
    // so this is the correct place to both clean up that instance's config
    // and decide whether ticking should stop (only once truly no Infinity
    // Clock widget of any type/size remains pinned).
    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            val repo = com.infinityclock.app.data.WidgetConfigRepository(context)
            appWidgetIds.forEach { repo.remove(it) }
            if (!repo.hasAnyConfigured()) {
                WidgetUpdateScheduler.cancelTicking(context)
            }
        }
    }
}
