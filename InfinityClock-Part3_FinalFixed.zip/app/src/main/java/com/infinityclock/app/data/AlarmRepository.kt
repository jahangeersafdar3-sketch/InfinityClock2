package com.infinityclock.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclock.app.alarm.model.AlarmItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.alarmDataStore by preferencesDataStore(name = "infinity_clock_alarms")

class AlarmRepository(private val context: Context) {
    private val key = stringPreferencesKey("alarms_json")

    val alarmsFlow: Flow<List<AlarmItem>> = context.alarmDataStore.data.map { prefs ->
        val json = prefs[key] ?: "[]"
        val array = JSONArray(json)
        (0 until array.length()).map { AlarmItem.fromJson(array.getJSONObject(it)) }
    }

    suspend fun all(): List<AlarmItem> = alarmsFlow.first()

    suspend fun save(alarm: AlarmItem) {
        context.alarmDataStore.edit { prefs ->
            val json = prefs[key] ?: "[]"
            val array = JSONArray(json)
            val existing = (0 until array.length()).map { JSONObject(array.getJSONObject(it).toString()) }
            val filtered = existing.filterNot { it.getString("id") == alarm.id }
            val updated = JSONArray()
            filtered.forEach { updated.put(it) }
            updated.put(alarm.toJson())
            prefs[key] = updated.toString()
        }
    }

    suspend fun delete(id: String) {
        context.alarmDataStore.edit { prefs ->
            val json = prefs[key] ?: "[]"
            val array = JSONArray(json)
            val remaining = JSONArray()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                if (obj.getString("id") != id) remaining.put(obj)
            }
            prefs[key] = remaining.toString()
        }
    }
}
