package com.infinityclock.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclock.app.wallpaper.WallpaperConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.wallpaperDataStore by preferencesDataStore(name = "infinity_clock_wallpaper")

/** Single active wallpaper configuration (there's only ever one live wallpaper at a time). */
class WallpaperConfigRepository(private val context: Context) {
    private val key = stringPreferencesKey("wallpaper_config_json")

    val configFlow: Flow<WallpaperConfig> = context.wallpaperDataStore.data.map { prefs ->
        prefs[key]?.let { WallpaperConfig.fromJson(JSONObject(it)) } ?: WallpaperConfig()
    }

    suspend fun current(): WallpaperConfig = configFlow.first()

    suspend fun save(config: WallpaperConfig) {
        context.wallpaperDataStore.edit { it[key] = config.toJson().toString() }
    }
}
