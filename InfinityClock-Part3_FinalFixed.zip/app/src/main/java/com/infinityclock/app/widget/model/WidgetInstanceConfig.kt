package com.infinityclock.app.widget.model

import com.infinityclock.app.common.ClockRef
import com.infinityclock.app.common.ClockRefKind
import org.json.JSONObject

/**
 * Per-widget-instance settings, keyed by the Android-assigned appWidgetId.
 * Every field the Part 2 "Widget Configuration" section asks for is here,
 * and each home-screen widget instance gets its own independent copy.
 */
data class WidgetInstanceConfig(
    val appWidgetId: Int,
    val clockRef: ClockRef,
    val overridePrimaryColor: Long? = null,
    val overrideSecondaryColor: Long? = null,
    val is24Hour: Boolean = true,
    val showSeconds: Boolean = false,
    val showDate: Boolean = true,
    val showDay: Boolean = true,
    val transparentBackground: Boolean = false,
    val backgroundOpacity: Float = 1f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("appWidgetId", appWidgetId)
        put("clockRef", clockRef.serialize())
        put("overridePrimaryColor", overridePrimaryColor ?: JSONObject.NULL)
        put("overrideSecondaryColor", overrideSecondaryColor ?: JSONObject.NULL)
        put("is24Hour", is24Hour)
        put("showSeconds", showSeconds)
        put("showDate", showDate)
        put("showDay", showDay)
        put("transparentBackground", transparentBackground)
        put("backgroundOpacity", backgroundOpacity.toDouble())
    }

    companion object {
        fun default(appWidgetId: Int, clockRef: ClockRef) = WidgetInstanceConfig(appWidgetId, clockRef)

        fun fromJson(j: JSONObject): WidgetInstanceConfig? {
            val ref = ClockRef.deserialize(j.optString("clockRef", null)) ?: return null
            return WidgetInstanceConfig(
                appWidgetId = j.getInt("appWidgetId"),
                clockRef = ref,
                overridePrimaryColor = if (j.isNull("overridePrimaryColor")) null else j.getLong("overridePrimaryColor"),
                overrideSecondaryColor = if (j.isNull("overrideSecondaryColor")) null else j.getLong("overrideSecondaryColor"),
                is24Hour = j.getBoolean("is24Hour"),
                showSeconds = j.getBoolean("showSeconds"),
                showDate = j.getBoolean("showDate"),
                showDay = j.getBoolean("showDay"),
                transparentBackground = j.getBoolean("transparentBackground"),
                backgroundOpacity = j.getDouble("backgroundOpacity").toFloat()
            )
        }
    }
}
