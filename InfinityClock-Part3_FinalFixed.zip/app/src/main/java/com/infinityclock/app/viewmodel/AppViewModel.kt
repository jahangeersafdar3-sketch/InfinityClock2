package com.infinityclock.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.model.ClockCategory
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.data.AppSettings
import com.infinityclock.app.data.ClockRepository
import com.infinityclock.app.data.SettingsRepository
import com.infinityclock.app.data.StudioRepository
import com.infinityclock.app.studio.model.StudioClockConfig
import com.infinityclock.app.theme.AppThemeMode
import com.infinityclock.app.widget.WidgetUpdateScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class GalleryFilter { ALL, DIGITAL, ANALOG, HYBRID, FAVORITES, RECENT, CUSTOM, STUDIO }

/**
 * Single app-wide state holder shared by every screen so Home/Gallery/Create/
 * Settings always agree on the current settings + clock library without
 * re-reading DataStore independently or duplicating logic.
 */
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = SettingsRepository(application)
    private val clockRepository = ClockRepository(application)
    private val studioRepository = StudioRepository(application)

    val settings: StateFlow<AppSettings> = settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val allClocks: StateFlow<List<ClockConfig>> = clockRepository.allClocksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), clockRepository.presets())

    val recentClocks: StateFlow<List<ClockConfig>> = clockRepository.recentClocksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedClock: StateFlow<ClockConfig> = combine(settings, allClocks) { s, clocks ->
        clocks.firstOrNull { it.id == s.selectedClockId } ?: clocks.first()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), clockRepository.presets().first())

    // --- Clock Studio (Part 2) — additive, does not touch anything above. ---
    val studioClocks: StateFlow<List<StudioClockConfig>> = studioRepository.clocksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveStudioClock(config: StudioClockConfig) {
        viewModelScope.launch {
            studioRepository.save(config)
            WidgetUpdateScheduler.requestUpdateForClock(getApplication(), config.id)
        }
    }

    fun duplicateStudioClock(config: StudioClockConfig, onDuplicated: (StudioClockConfig) -> Unit) {
        viewModelScope.launch { onDuplicated(studioRepository.duplicate(config)) }
    }

    fun deleteStudioClock(id: String) {
        viewModelScope.launch { studioRepository.delete(id) }
    }

    fun toggleStudioFavorite(id: String) {
        viewModelScope.launch { studioRepository.toggleFavorite(id, studioClocks.value) }
    }

    fun renameStudioClock(id: String, newName: String) {
        viewModelScope.launch { studioRepository.rename(id, newName, studioClocks.value) }
    }

    fun selectClock(config: ClockConfig) {
        viewModelScope.launch {
            settingsRepository.setSelectedClockId(config.id)
            clockRepository.markRecentlyUsed(config.id)
        }
    }

    fun toggleFavorite(config: ClockConfig) {
        viewModelScope.launch { clockRepository.toggleFavorite(config.id) }
    }

    fun saveCustomClock(config: ClockConfig, applyImmediately: Boolean) {
        viewModelScope.launch {
            clockRepository.saveCustomClock(config)
            if (applyImmediately) {
                settingsRepository.setSelectedClockId(config.id)
                clockRepository.markRecentlyUsed(config.id)
            }
            WidgetUpdateScheduler.requestUpdateForClock(getApplication(), config.id)
        }
    }

    fun duplicateClock(config: ClockConfig, onDuplicated: (ClockConfig) -> Unit) {
        viewModelScope.launch {
            val copy = clockRepository.duplicateCustomClock(config)
            onDuplicated(copy)
        }
    }

    fun deleteCustomClock(id: String) {
        viewModelScope.launch { clockRepository.deleteCustomClock(id) }
    }

    fun setIs24Hour(value: Boolean) = viewModelScope.launch { settingsRepository.setIs24Hour(value) }
    fun setShowSeconds(value: Boolean) = viewModelScope.launch { settingsRepository.setShowSeconds(value) }
    fun setShowDate(value: Boolean) = viewModelScope.launch { settingsRepository.setShowDate(value) }
    fun setShowDay(value: Boolean) = viewModelScope.launch { settingsRepository.setShowDay(value) }
    fun setThemeMode(value: AppThemeMode) = viewModelScope.launch { settingsRepository.setThemeMode(value) }
    fun setAnimationQuality(value: AnimationQuality) = viewModelScope.launch { settingsRepository.setAnimationQuality(value) }
    fun setAnimationSpeed(value: Float) = viewModelScope.launch { settingsRepository.setAnimationSpeed(value) }
    fun setHapticFeedback(value: Boolean) = viewModelScope.launch { settingsRepository.setHapticFeedback(value) }
    fun resetSettings() = viewModelScope.launch { settingsRepository.resetAll() }
}
