package com.infinityclock.app.alarm.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.infinityclock.app.alarm.AlarmScheduler
import com.infinityclock.app.alarm.ui.AlarmRingingActivity
import com.infinityclock.app.data.AlarmRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Fired by AlarmManager.setAlarmClock() at the scheduled time. Starting an
 * Activity directly from here is one of the documented exceptions to
 * Android's background-activity-start restrictions (a PendingIntent
 * triggered by AlarmManager for the app's own scheduled alarm), so the
 * ringing screen reliably appears even from the background or a locked
 * screen — matching a real alarm clock app's behavior.
 */
class AlarmFireReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_ALARM_FIRE = "com.infinityclock.app.alarm.ACTION_ALARM_FIRE"
        const val EXTRA_ALARM_ID = "com.infinityclock.app.alarm.EXTRA_ALARM_ID"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_ALARM_FIRE) return
        val alarmId = intent.getStringExtra(EXTRA_ALARM_ID) ?: return
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repository = AlarmRepository(context)
                val alarm = repository.all().firstOrNull { it.id == alarmId }
                if (alarm != null) {
                    val ringingIntent = Intent(context, AlarmRingingActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        putExtra(AlarmRingingActivity.EXTRA_ALARM_ID, alarm.id)
                    }
                    context.startActivity(ringingIntent)

                    if (alarm.repeatDays.isEmpty()) {
                        // One-shot alarm: it has done its job.
                        repository.save(alarm.copy(enabled = false))
                    } else {
                        // Repeating: schedule the next occurrence now so it's
                        // never left unscheduled between firings.
                        AlarmScheduler.schedule(context, alarm)
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
