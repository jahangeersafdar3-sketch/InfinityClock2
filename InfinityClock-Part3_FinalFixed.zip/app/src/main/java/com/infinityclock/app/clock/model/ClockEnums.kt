package com.infinityclock.app.clock.model

enum class ClockType { DIGITAL, ANALOG, HYBRID }

enum class ClockCategory(val displayName: String, val type: ClockType) {
    // Digital
    DIGITAL_MINIMAL("Minimal", ClockType.DIGITAL),
    DIGITAL_NEON("Neon", ClockType.DIGITAL),
    DIGITAL_GLASS("Glass", ClockType.DIGITAL),
    DIGITAL_CYBER("Cyber", ClockType.DIGITAL),
    DIGITAL_FUTURISTIC("Futuristic", ClockType.DIGITAL),
    DIGITAL_LED("LED", ClockType.DIGITAL),
    DIGITAL_MATRIX("Matrix", ClockType.DIGITAL),
    DIGITAL_RETRO("Retro", ClockType.DIGITAL),
    DIGITAL_PIXEL("Pixel", ClockType.DIGITAL),
    DIGITAL_GRADIENT("Gradient", ClockType.DIGITAL),
    DIGITAL_HOLOGRAPHIC("Holographic", ClockType.DIGITAL),
    DIGITAL_LUXURY("Luxury", ClockType.DIGITAL),
    DIGITAL_AMOLED("AMOLED", ClockType.DIGITAL),
    DIGITAL_SCIFI("Sci-Fi", ClockType.DIGITAL),
    DIGITAL_TERMINAL("Terminal", ClockType.DIGITAL),
    DIGITAL_LIQUID("Liquid", ClockType.DIGITAL),

    // Analog
    ANALOG_CLASSIC("Classic", ClockType.ANALOG),
    ANALOG_LUXURY("Luxury", ClockType.ANALOG),
    ANALOG_ROMAN("Roman", ClockType.ANALOG),
    ANALOG_MINIMAL("Minimal", ClockType.ANALOG),
    ANALOG_SKELETON("Skeleton", ClockType.ANALOG),
    ANALOG_MECHANICAL("Mechanical", ClockType.ANALOG),
    ANALOG_GLASS("Glass", ClockType.ANALOG),
    ANALOG_NEON("Neon", ClockType.ANALOG),
    ANALOG_FUTURISTIC("Futuristic", ClockType.ANALOG),
    ANALOG_METALLIC("Metallic", ClockType.ANALOG),
    ANALOG_COMPASS("Compass", ClockType.ANALOG),
    ANALOG_SPORT("Sport", ClockType.ANALOG),
    ANALOG_SPACE("Space", ClockType.ANALOG),

    // Hybrid
    HYBRID_ANALOG_DIGITAL("Analog + Digital", ClockType.HYBRID),
    HYBRID_ANALOG_DATE("Analog + Date", ClockType.HYBRID),
    HYBRID_DIGITAL_SECONDS_RING("Digital + Seconds Ring", ClockType.HYBRID),
    HYBRID_DIGITAL_BATTERY("Digital + Battery", ClockType.HYBRID),
    HYBRID_DIGITAL_WORLD("Digital + World Clock", ClockType.HYBRID)
}

enum class ClockFont { SYSTEM, MONO, SERIF, CONDENSED, ROUNDED }

enum class BackgroundStyle {
    SOLID, GRADIENT, ANIMATED_GRADIENT, AMOLED_BLACK,
    STARS, PARTICLES, AURORA, ABSTRACT, SPACE, GLASS
}

enum class AnimationStyle {
    NONE, SMOOTH_SWEEP, TICKING, GLOW_PULSE, BREATHING_GLOW,
    GRADIENT_MOVE, LIGHT_SWEEP, PARTICLE_DRIFT, AURORA_FLOW,
    LIQUID_WAVE, HOLOGRAPHIC_FLICKER, MECHANICAL_TICK, NUMBER_MORPH
}

enum class HandStyle { CLASSIC, SKELETON, SWORD, NEEDLE, BLOCK, DIAMOND }

enum class NumberStyle { STANDARD, ROMAN, DOTS, TICKS_ONLY, ARABIC_ART_DECO }

enum class MarkerStyle { TICKS, DOTS, LINES, DIAMONDS, NONE }

enum class AnimationQuality { BATTERY_SAVER, BALANCED, SMOOTH, MAXIMUM }
