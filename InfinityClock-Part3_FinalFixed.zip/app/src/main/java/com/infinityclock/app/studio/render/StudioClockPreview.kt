package com.infinityclock.app.studio.render

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.util.currentTickTime
import com.infinityclock.app.clock.util.tickerFlow
import com.infinityclock.app.studio.model.StudioClockConfig
import kotlinx.coroutines.flow.collectLatest

/**
 * Read-only, live-ticking render of a StudioClockConfig — used by the
 * gallery card, Home preview, and the in-app widget preview. No selection
 * handles, no gestures; the same drawing code as the editor so what you see
 * here always matches what the editor produced.
 */
@Composable
fun StudioClockPreview(
    config: StudioClockConfig,
    quality: AnimationQuality,
    is24Hour: Boolean = true,
    modifier: Modifier = Modifier
) {
    var time by remember { mutableStateOf(currentTickTime()) }
    LaunchedEffect(Unit) {
        tickerFlow().collectLatest { time = it }
    }

    StudioCanvasArea(
        elements = config.elements,
        time = time,
        is24Hour = is24Hour,
        quality = quality,
        editable = false,
        selectedId = null,
        onSelect = {},
        onBeginGesture = {},
        onMove = { _, _, _ -> },
        onResize = { _, _, _ -> },
        onRotate = { _, _ -> },
        modifier = modifier.fillMaxSize()
    )
}
