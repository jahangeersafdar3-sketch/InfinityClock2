package com.infinityclock.app.navigation

sealed class Screen(val route: String, val label: String) {
    data object Home : Screen("home", "Home")
    data object Gallery : Screen("gallery", "Clocks")
    data object Create : Screen("create", "Create")
    // Route stays "widgets" (unchanged from Part 2) but now hosts the
    // full Part 3 "Use on Phone" control center — widgets are one card
    // among several rather than the whole screen.
    data object UseOnPhone : Screen("widgets", "Use on Phone")
    data object Settings : Screen("settings", "Settings")

    companion object {
        val bottomBarScreens = listOf(Home, Gallery, Create, UseOnPhone, Settings)
    }
}

/** Route for editing a specific clock (new or existing). Passed as an arg. */
const val EDIT_CLOCK_ROUTE = "create/{clockId}"
fun editClockRoute(clockId: String) = "create/$clockId"

/** Route for the Clock Studio editor (Part 2), keyed by studio clock id or "new". */
const val STUDIO_ROUTE = "studio/{studioId}"
fun studioRoute(studioId: String) = "studio/$studioId"

/** Part 3 feature routes, hosted inside the same Compose NavHost as everything else. */
const val ALARMS_ROUTE = "alarms"
const val TIMER_ROUTE = "timer"
const val STOPWATCH_ROUTE = "stopwatch"
const val WORLD_CLOCK_ROUTE = "worldclock"
/** The Part 2 widget setup screen, now reached via a card on the Control Center. */
const val WIDGETS_DETAIL_ROUTE = "widgets_detail"
