package com.infinityclock.app.timer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Schedules the "timer finished" alert so it still fires if the app is
 * backgrounded or the screen is off. Uses an exact alarm ONLY when the app
 * already has permission to schedule one (`canScheduleExactAlarms()`,
 * API 31+); otherwise it falls back to an inexact-but-Doze-aware alarm
 * rather than prompting for a sensitive permission just for a countdown
 * timer — "request only required permissions" per the Part 3 brief.
 */
object TimerScheduler {
    private const val REQUEST_CODE = 5231

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, TimerCompletionReceiver::class.java).apply {
            action = TimerCompletionReceiver.ACTION_TIMER_COMPLETE
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags)
    }

    fun schedule(context: Context, triggerAtElapsedRealtime: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val canBeExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()
        if (canBeExact) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAtElapsedRealtime, pendingIntent(context))
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAtElapsedRealtime, pendingIntent(context))
        }
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        alarmManager.cancel(pendingIntent(context))
    }

    fun canScheduleExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
        return alarmManager.canScheduleExactAlarms()
    }
}
