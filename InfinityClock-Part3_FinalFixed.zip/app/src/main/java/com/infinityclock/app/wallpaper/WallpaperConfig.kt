package com.infinityclock.app.wallpaper

import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.common.ClockRef
import com.infinityclock.app.common.ClockRefKind
import org.json.JSONObject

data class WallpaperConfig(
    val clockRefKind: ClockRefKind = ClockRefKind.STANDARD,
    val clockRefId: String? = null,
    val renderAsAnalog: Boolean = false,
    val primaryColor: Long = 0xFF00D4FF,
    val secondaryColor: Long = 0xFF0088CC,
    val accentColor: Long = 0xFF66E8FF,
    val backgroundColor: Long = 0xFF000000,
    val is24Hour: Boolean = true,
    val showSeconds: Boolean = true,
    val showDate: Boolean = true,
    val showDay: Boolean = true,
    val clockScale: Float = 1f,
    val offsetXFraction: Float = 0f,
    val offsetYFraction: Float = 0f,
    val opacity: Float = 1f,
    val glow: Boolean = true,
    val performanceMode: AnimationQuality = AnimationQuality.BALANCED,
    val burnInProtectionEnabled: Boolean = true,
    val burnInShiftIntervalMinutes: Int = 5,
    val burnInMovementRangeDp: Float = 12f
) {
    val clockRef: ClockRef? get() = clockRefId?.let { ClockRef(clockRefKind, it) }

    fun toJson(): JSONObject = JSONObject().apply {
        put("clockRefKind", clockRefKind.name)
        put("clockRefId", clockRefId ?: JSONObject.NULL)
        put("renderAsAnalog", renderAsAnalog)
        put("primaryColor", primaryColor); put("secondaryColor", secondaryColor); put("accentColor", accentColor)
        put("backgroundColor", backgroundColor)
        put("is24Hour", is24Hour); put("showSeconds", showSeconds); put("showDate", showDate); put("showDay", showDay)
        put("clockScale", clockScale.toDouble())
        put("offsetXFraction", offsetXFraction.toDouble()); put("offsetYFraction", offsetYFraction.toDouble())
        put("opacity", opacity.toDouble()); put("glow", glow)
        put("performanceMode", performanceMode.name)
        put("burnInProtectionEnabled", burnInProtectionEnabled)
        put("burnInShiftIntervalMinutes", burnInShiftIntervalMinutes)
        put("burnInMovementRangeDp", burnInMovementRangeDp.toDouble())
    }

    companion object {
        fun fromJson(j: JSONObject): WallpaperConfig = WallpaperConfig(
            clockRefKind = runCatching { ClockRefKind.valueOf(j.getString("clockRefKind")) }.getOrDefault(ClockRefKind.STANDARD),
            clockRefId = if (j.isNull("clockRefId")) null else j.getString("clockRefId"),
            renderAsAnalog = j.optBoolean("renderAsAnalog", false),
            primaryColor = j.optLong("primaryColor", 0xFF00D4FF),
            secondaryColor = j.optLong("secondaryColor", 0xFF0088CC),
            accentColor = j.optLong("accentColor", 0xFF66E8FF),
            backgroundColor = j.optLong("backgroundColor", 0xFF000000),
            is24Hour = j.optBoolean("is24Hour", true),
            showSeconds = j.optBoolean("showSeconds", true),
            showDate = j.optBoolean("showDate", true),
            showDay = j.optBoolean("showDay", true),
            clockScale = j.optDouble("clockScale", 1.0).toFloat(),
            offsetXFraction = j.optDouble("offsetXFraction", 0.0).toFloat(),
            offsetYFraction = j.optDouble("offsetYFraction", 0.0).toFloat(),
            opacity = j.optDouble("opacity", 1.0).toFloat(),
            glow = j.optBoolean("glow", true),
            performanceMode = runCatching { AnimationQuality.valueOf(j.getString("performanceMode")) }.getOrDefault(AnimationQuality.BALANCED),
            burnInProtectionEnabled = j.optBoolean("burnInProtectionEnabled", true),
            burnInShiftIntervalMinutes = j.optInt("burnInShiftIntervalMinutes", 5),
            burnInMovementRangeDp = j.optDouble("burnInMovementRangeDp", 12.0).toFloat()
        )
    }
}
