package com.infinityclock.app.widget

import com.infinityclock.app.common.ClockRef

/**
 * A tiny in-memory handoff between "Use as Widget" (tapped in the app) and
 * WidgetConfigurationActivity, which the system auto-launches after a
 * successful requestPinAppWidget() using ONLY the standard
 * ACTION_APPWIDGET_CONFIGURE contract (EXTRA_APPWIDGET_ID) — that system-
 * driven intent has no room for our own extras, so this in-process holder is
 * what lets the configuration screen open with the right clock pre-selected.
 * If the process dies between the two steps (rare), the config screen just
 * falls back to its normal default selection — never a crash.
 */
object PendingWidgetSelection {
    private var pending: ClockRef? = null

    fun set(ref: ClockRef) {
        pending = ref
    }

    fun consume(): ClockRef? {
        val value = pending
        pending = null
        return value
    }
}
