package com.infinityclock.app.ui.gallery

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.clock.model.ClockType
import com.infinityclock.app.common.ClockRef
import com.infinityclock.app.common.ClockRefKind
import com.infinityclock.app.studio.model.StudioClockConfig
import com.infinityclock.app.studio.render.StudioClockPreview
import com.infinityclock.app.ui.components.ClockCard
import com.infinityclock.app.viewmodel.AppViewModel
import com.infinityclock.app.viewmodel.GalleryFilter
import com.infinityclock.app.widget.UseAsWidgetLauncher
import com.infinityclock.app.widget.UseAsWidgetResult

private fun filterClocks(
    all: List<ClockConfig>,
    recent: List<ClockConfig>,
    filter: GalleryFilter,
    query: String
): List<ClockConfig> {
    val base = when (filter) {
        GalleryFilter.ALL -> all
        GalleryFilter.DIGITAL -> all.filter { it.type == ClockType.DIGITAL }
        GalleryFilter.ANALOG -> all.filter { it.type == ClockType.ANALOG }
        GalleryFilter.HYBRID -> all.filter { it.type == ClockType.HYBRID }
        GalleryFilter.FAVORITES -> all.filter { it.isFavorite }
        GalleryFilter.RECENT -> recent
        GalleryFilter.CUSTOM -> all.filter { it.isCustom }
        GalleryFilter.STUDIO -> emptyList()
    }
    if (query.isBlank()) return base
    return base.filter {
        it.name.contains(query, ignoreCase = true) || it.category.displayName.contains(query, ignoreCase = true)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryScreen(
    viewModel: AppViewModel,
    onEditClock: (String) -> Unit,
    onEditStudioClock: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    // Reading these via `by` (not a discarded collectAsState() call) is what
    // makes this composable actually recompose when the library changes —
    // e.g. right after a favorite is toggled or a custom clock is saved.
    val allClocks by viewModel.allClocks.collectAsState()
    val recentClocks by viewModel.recentClocks.collectAsState()
    val studioClocks by viewModel.studioClocks.collectAsState()

    var filter by remember { mutableStateOf(GalleryFilter.ALL) }
    var query by remember { mutableStateOf("") }

    fun useAsWidget(ref: ClockRef, preferAnalog: Boolean) {
        val result = UseAsWidgetLauncher.requestPin(context, ref, preferAnalog)
        val message = when (result) {
            is UseAsWidgetResult.Requested -> "Pinning to your home screen — finish setup in the prompt that appears."
            is UseAsWidgetResult.UnsupportedLauncher -> "Your launcher doesn't support quick-pinning. Add it manually: Home Screen → Widgets → Infinity Clock."
        }
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Clock Gallery") }) }
    ) { padding ->
        val clocks = if (filter == GalleryFilter.STUDIO) emptyList() else filterClocks(allClocks, recentClocks, filter, query)
        val visibleStudioClocks = if (filter == GalleryFilter.STUDIO) {
            if (query.isBlank()) studioClocks else studioClocks.filter { it.name.contains(query, ignoreCase = true) }
        } else emptyList()

        Column(modifier = Modifier.padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search clocks or categories") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                singleLine = true
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp)
            ) {
                items(GalleryFilter.values().toList()) { f ->
                    FilterChip(
                        selected = filter == f,
                        onClick = { filter = f },
                        label = { Text(f.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            if (clocks.isEmpty() && visibleStudioClocks.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (filter == GalleryFilter.STUDIO) "No Studio clocks yet — create one from the Create tab." else "No clocks match yet.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (filter == GalleryFilter.STUDIO) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(visibleStudioClocks, key = { it.id }) { studioClock ->
                        StudioClockCard(
                            config = studioClock,
                            quality = settings.animationQuality,
                            onOpen = { onEditStudioClock(studioClock.id) },
                            onToggleFavorite = { viewModel.toggleStudioFavorite(studioClock.id) },
                            onUseAsWidget = { useAsWidget(ClockRef(ClockRefKind.STUDIO, studioClock.id), preferAnalog = false) }
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(clocks, key = { it.id }) { clock ->
                        ClockCard(
                            config = clock,
                            quality = settings.animationQuality,
                            onOpen = {
                                viewModel.selectClock(clock)
                                if (clock.isCustom) onEditClock(clock.id)
                            },
                            onToggleFavorite = { viewModel.toggleFavorite(clock) },
                            onUseAsWidget = {
                                useAsWidget(ClockRef(ClockRefKind.STANDARD, clock.id), preferAnalog = clock.type == ClockType.ANALOG)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioClockCard(
    config: StudioClockConfig,
    quality: AnimationQuality,
    onOpen: () -> Unit,
    onToggleFavorite: () -> Unit,
    onUseAsWidget: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.1f)
            ) {
                StudioClockPreview(config = config, quality = quality)
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(
                        imageVector = if (config.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (config.isFavorite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(config.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                IconButton(onClick = onUseAsWidget) {
                    Icon(
                        imageVector = Icons.Filled.Widgets,
                        contentDescription = "Use as Widget",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}
