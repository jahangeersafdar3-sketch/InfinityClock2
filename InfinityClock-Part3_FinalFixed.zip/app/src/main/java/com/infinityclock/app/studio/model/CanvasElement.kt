package com.infinityclock.app.studio.model

import org.json.JSONObject
import java.util.UUID

/**
 * One element on the Clock Studio canvas. Position/size are stored as
 * fractions (0f..1f) of the canvas so a design reflows correctly at any
 * canvas size (studio editor, gallery card, home preview, or a widget).
 *
 * Every field listed in the Part 2 brief (move/resize/rotate/opacity/color/
 * gradient/font/font size/stroke/shadow/glow/visibility/layer order) is a
 * real field here, not a UI-only control with nothing behind it.
 */
data class CanvasElement(
    val id: String = UUID.randomUUID().toString(),
    val type: ElementType,
    val name: String,
    val zIndex: Int,
    val visible: Boolean = true,

    // Transform (fractions of canvas width/height, rotation in degrees)
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val rotationDegrees: Float = 0f,

    // Appearance
    val opacity: Float = 1f,
    val primaryColor: Long = 0xFFFFFFFF,
    val secondaryColor: Long = 0xFF00D4FF,
    val useGradient: Boolean = false,
    val gradientAngle: Float = 45f,

    // Text-only
    val text: String = "",
    val font: ElementFont = ElementFont.SYSTEM,
    val fontSizeSp: Float = 32f,
    val bold: Boolean = true,

    // Shape/stroke
    val strokeWidth: Float = 0f,
    val strokeColor: Long = 0xFFFFFFFF,
    val filled: Boolean = true,

    // Effects
    val hasShadow: Boolean = false,
    val hasGlow: Boolean = false,
    val glowColor: Long = 0xFF00D4FF,
    val glowIntensity: Float = 0.5f,

    // Animation
    val animation: ElementAnimationPreset = ElementAnimationPreset.NONE,
    val animationSpeedMultiplier: Float = 1f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("type", type.name); put("name", name)
        put("zIndex", zIndex); put("visible", visible)
        put("x", x.toDouble()); put("y", y.toDouble())
        put("width", width.toDouble()); put("height", height.toDouble())
        put("rotationDegrees", rotationDegrees.toDouble())
        put("opacity", opacity.toDouble())
        put("primaryColor", primaryColor); put("secondaryColor", secondaryColor)
        put("useGradient", useGradient); put("gradientAngle", gradientAngle.toDouble())
        put("text", text); put("font", font.name)
        put("fontSizeSp", fontSizeSp.toDouble()); put("bold", bold)
        put("strokeWidth", strokeWidth.toDouble()); put("strokeColor", strokeColor); put("filled", filled)
        put("hasShadow", hasShadow); put("hasGlow", hasGlow)
        put("glowColor", glowColor); put("glowIntensity", glowIntensity.toDouble())
        put("animation", animation.name); put("animationSpeedMultiplier", animationSpeedMultiplier.toDouble())
    }

    companion object {
        fun fromJson(j: JSONObject): CanvasElement = CanvasElement(
            id = j.getString("id"),
            type = ElementType.valueOf(j.getString("type")),
            name = j.getString("name"),
            zIndex = j.getInt("zIndex"),
            visible = j.getBoolean("visible"),
            x = j.getDouble("x").toFloat(), y = j.getDouble("y").toFloat(),
            width = j.getDouble("width").toFloat(), height = j.getDouble("height").toFloat(),
            rotationDegrees = j.getDouble("rotationDegrees").toFloat(),
            opacity = j.getDouble("opacity").toFloat(),
            primaryColor = j.getLong("primaryColor"), secondaryColor = j.getLong("secondaryColor"),
            useGradient = j.getBoolean("useGradient"), gradientAngle = j.getDouble("gradientAngle").toFloat(),
            text = j.optString("text", ""), font = ElementFont.valueOf(j.getString("font")),
            fontSizeSp = j.getDouble("fontSizeSp").toFloat(), bold = j.getBoolean("bold"),
            strokeWidth = j.getDouble("strokeWidth").toFloat(), strokeColor = j.getLong("strokeColor"),
            filled = j.getBoolean("filled"),
            hasShadow = j.getBoolean("hasShadow"), hasGlow = j.getBoolean("hasGlow"),
            glowColor = j.getLong("glowColor"), glowIntensity = j.getDouble("glowIntensity").toFloat(),
            animation = ElementAnimationPreset.valueOf(j.getString("animation")),
            animationSpeedMultiplier = j.getDouble("animationSpeedMultiplier").toFloat()
        )
    }
}

fun defaultElement(type: ElementType, zIndex: Int): CanvasElement = when (type) {
    ElementType.HOURS, ElementType.MINUTES, ElementType.SECONDS ->
        CanvasElement(type = type, name = type.name.lowercase().replaceFirstChar { it.uppercase() }, zIndex = zIndex, x = 0.3f, y = 0.4f, width = 0.4f, height = 0.15f, fontSizeSp = 48f)
    ElementType.DATE, ElementType.DAY, ElementType.MONTH ->
        CanvasElement(type = type, name = type.name.lowercase().replaceFirstChar { it.uppercase() }, zIndex = zIndex, x = 0.25f, y = 0.6f, width = 0.5f, height = 0.08f, fontSizeSp = 16f)
    ElementType.CUSTOM_TEXT ->
        CanvasElement(type = type, name = "Text", zIndex = zIndex, x = 0.3f, y = 0.5f, width = 0.4f, height = 0.1f, text = "Text", fontSizeSp = 20f)
    ElementType.SHAPE_RECT ->
        CanvasElement(type = type, name = "Rectangle", zIndex = zIndex, x = 0.35f, y = 0.35f, width = 0.3f, height = 0.3f)
    ElementType.SHAPE_CIRCLE ->
        CanvasElement(type = type, name = "Circle", zIndex = zIndex, x = 0.35f, y = 0.35f, width = 0.3f, height = 0.3f)
    ElementType.SHAPE_LINE ->
        CanvasElement(type = type, name = "Line", zIndex = zIndex, x = 0.2f, y = 0.5f, width = 0.6f, height = 0.02f, strokeWidth = 4f)
    ElementType.BACKGROUND ->
        CanvasElement(type = type, name = "Background", zIndex = zIndex, x = 0f, y = 0f, width = 1f, height = 1f, primaryColor = 0xFF0B0B14)
    ElementType.DECORATIVE ->
        CanvasElement(type = type, name = "Decoration", zIndex = zIndex, x = 0.4f, y = 0.4f, width = 0.2f, height = 0.2f)
    ElementType.PARTICLES ->
        CanvasElement(type = type, name = "Particles", zIndex = zIndex, x = 0f, y = 0f, width = 1f, height = 1f)
    ElementType.GLOW_ORB ->
        CanvasElement(type = type, name = "Glow Orb", zIndex = zIndex, x = 0.4f, y = 0.4f, width = 0.2f, height = 0.2f, hasGlow = true)
}
