package com.infinityclock.app.viewmodel

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.infinityclock.app.data.TimerRepository
import com.infinityclock.app.timer.TimerScheduler
import com.infinityclock.app.timer.TimerState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TimerViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = TimerRepository(application)

    private val _state = MutableStateFlow(TimerState())
    val state: StateFlow<TimerState> = _state.asStateFlow()

    init {
        viewModelScope.launch { _state.value = repository.current() }
    }

    private fun persist() = viewModelScope.launch { repository.save(_state.value) }

    fun setDuration(millis: Long) {
        if (_state.value.running) return
        _state.value = _state.value.copy(totalMillis = millis, remainingMillisWhenPaused = millis)
        persist()
    }

    fun start() {
        val s = _state.value
        val remaining = if (s.remainingMillisWhenPaused > 0) s.remainingMillisWhenPaused else s.totalMillis
        if (remaining <= 0) return
        val target = SystemClock.elapsedRealtime() + remaining
        _state.value = s.copy(running = true, targetElapsedRealtime = target)
        TimerScheduler.schedule(getApplication(), target)
        persist()
    }

    fun pause() {
        val s = _state.value
        if (!s.running) return
        val remaining = s.remainingMillis(SystemClock.elapsedRealtime())
        _state.value = s.copy(running = false, remainingMillisWhenPaused = remaining)
        TimerScheduler.cancel(getApplication())
        persist()
    }

    fun reset() {
        TimerScheduler.cancel(getApplication())
        _state.value = TimerState()
        persist()
    }

    fun remainingMillis(): Long = _state.value.remainingMillis(SystemClock.elapsedRealtime())

    fun canScheduleExactAlarm(): Boolean = TimerScheduler.canScheduleExact(getApplication())
}
