package com.infinityclock.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.infinityclock.app.alarm.AlarmScheduler
import com.infinityclock.app.alarm.model.AlarmItem
import com.infinityclock.app.data.AlarmRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AlarmViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = AlarmRepository(application)

    val alarms: StateFlow<List<AlarmItem>> = repository.alarmsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun save(alarm: AlarmItem) {
        viewModelScope.launch {
            repository.save(alarm)
            AlarmScheduler.schedule(getApplication(), alarm)
        }
    }

    fun setEnabled(alarm: AlarmItem, enabled: Boolean) {
        val updated = alarm.copy(enabled = enabled)
        save(updated)
    }

    fun delete(alarm: AlarmItem) {
        viewModelScope.launch {
            AlarmScheduler.cancel(getApplication(), alarm)
            repository.delete(alarm.id)
        }
    }
}
