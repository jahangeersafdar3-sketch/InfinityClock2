package com.infinityclock.app.ui.wallpaper

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.infinityclock.app.clock.engine.ClockEngine
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.clock.presets.buildPresetCatalog
import com.infinityclock.app.common.ClockRef
import com.infinityclock.app.common.ClockRefKind
import com.infinityclock.app.data.ClockRepository
import com.infinityclock.app.data.WallpaperConfigRepository
import com.infinityclock.app.wallpaper.WallpaperConfig
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * In-app settings for the live wallpaper, plus the "Set as Live Wallpaper"
 * action which hands off to the real system wallpaper picker via
 * ACTION_CHANGE_LIVE_WALLPAPER — Android, not this screen, performs the
 * actual wallpaper switch, and the preview below is explicitly labeled as
 * approximate rather than pretending to be the real thing.
 */
@Composable
fun WallpaperConfigScreen(
    onBack: () -> Unit,
    onLaunchSystemPicker: (WallpaperConfig) -> Unit
) {
    val context = LocalContext.current
    val repository = remember { WallpaperConfigRepository(context) }
    val scope = rememberCoroutineScope()

    var config by remember { mutableStateOf(WallpaperConfig()) }
    var standardClocks by remember { mutableStateOf<List<ClockConfig>>(emptyList()) }

    LaunchedEffect(Unit) {
        config = repository.current()
        val presets = buildPresetCatalog()
        val custom = ClockRepository(context).customClocksFlow.first()
        standardClocks = presets + custom
    }

    fun update(transform: WallpaperConfig.() -> WallpaperConfig) {
        config = config.transform()
        scope.launch { repository.save(config) }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Live Wallpaper") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Box(modifier = Modifier.fillMaxWidth().aspectRatio(1.4f)) {
                        val previewConfig = ClockConfig(
                            name = "Preview",
                            category = if (config.renderAsAnalog) com.infinityclock.app.clock.model.ClockCategory.ANALOG_CLASSIC else com.infinityclock.app.clock.model.ClockCategory.DIGITAL_MINIMAL,
                            primaryColor = config.primaryColor, secondaryColor = config.secondaryColor, accentColor = config.accentColor,
                            backgroundColors = listOf(config.backgroundColor),
                            is24Hour = config.is24Hour, showSeconds = config.showSeconds, showDate = config.showDate, showDay = config.showDay,
                            glow = config.glow
                        )
                        ClockEngine(config = previewConfig, quality = config.performanceMode, modifier = Modifier.fillMaxSize())
                    }
                }
                Text(
                    "In-app preview — approximate only; the actual wallpaper renders full-screen behind your home screen icons.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item { Text("Choose a clock", style = MaterialTheme.typography.titleMedium) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(standardClocks.take(40)) { clock ->
                        FilterChip(
                            selected = config.clockRefId == clock.id,
                            onClick = {
                                update {
                                    copy(
                                        clockRefKind = ClockRefKind.STANDARD, clockRefId = clock.id,
                                        renderAsAnalog = clock.type != com.infinityclock.app.clock.model.ClockType.DIGITAL,
                                        primaryColor = clock.primaryColor, secondaryColor = clock.secondaryColor, accentColor = clock.accentColor
                                    )
                                }
                            },
                            label = { Text(clock.name) }
                        )
                    }
                }
            }

            item { Text("Performance Mode", style = MaterialTheme.typography.titleMedium) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(AnimationQuality.values().toList()) { mode ->
                        FilterChip(
                            selected = config.performanceMode == mode,
                            onClick = { update { copy(performanceMode = mode) } },
                            label = { Text(mode.name.replace('_', ' ')) }
                        )
                    }
                }
            }

            item { ToggleRow("24-hour format", config.is24Hour) { update { copy(is24Hour = it) } } }
            item { ToggleRow("Show seconds", config.showSeconds) { update { copy(showSeconds = it) } } }
            item { ToggleRow("Show date", config.showDate) { update { copy(showDate = it) } } }
            item { ToggleRow("Show day", config.showDay) { update { copy(showDay = it) } } }
            item { ToggleRow("Glow", config.glow) { update { copy(glow = it) } } }

            item { LabeledSlider("Clock size", config.clockScale, 0.5f..2f) { update { copy(clockScale = it) } } }
            item { LabeledSlider("Horizontal position", config.offsetXFraction, -0.4f..0.4f) { update { copy(offsetXFraction = it) } } }
            item { LabeledSlider("Vertical position", config.offsetYFraction, -0.4f..0.4f) { update { copy(offsetYFraction = it) } } }
            item { LabeledSlider("Opacity", config.opacity, 0.2f..1f) { update { copy(opacity = it) } } }

            item { Text("Burn-in Protection", style = MaterialTheme.typography.titleMedium) }
            item { ToggleRow("Enabled", config.burnInProtectionEnabled) { update { copy(burnInProtectionEnabled = it) } } }
            if (config.burnInProtectionEnabled) {
                item {
                    LabeledSlider(
                        "Shift interval (${config.burnInShiftIntervalMinutes} min)",
                        config.burnInShiftIntervalMinutes.toFloat(), 1f..30f
                    ) { update { copy(burnInShiftIntervalMinutes = it.toInt()) } }
                }
                item {
                    LabeledSlider(
                        "Movement range (${config.burnInMovementRangeDp.toInt()}dp)",
                        config.burnInMovementRangeDp, 4f..40f
                    ) { update { copy(burnInMovementRangeDp = it) } }
                }
            }

            item {
                Button(onClick = { onLaunchSystemPicker(config) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Set as Live Wallpaper")
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}
