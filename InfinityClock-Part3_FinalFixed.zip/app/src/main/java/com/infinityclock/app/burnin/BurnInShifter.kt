package com.infinityclock.app.burnin

import kotlin.random.Random

/**
 * Shared burn-in protection math for the live wallpaper AND the bedside/
 * full-screen clock. Every [shiftIntervalMillis], a new random target
 * offset (within +/-[maxRangePx]) is picked; [currentOffset] interpolates
 * toward it over [transitionMillis] each time update() is called, so the
 * clock visibly drifts smoothly rather than jumping — satisfying "do not
 * visibly jump the clock".
 */
class BurnInShifter(
    private val maxRangePx: Float,
    private val shiftIntervalMillis: Long,
    private val transitionMillis: Long = 4000L
) {
    private var lastShiftAtMillis: Long = 0L
    private var transitionStartMillis: Long = 0L
    private var fromX = 0f
    private var fromY = 0f
    private var targetX = 0f
    private var targetY = 0f

    var currentOffsetX: Float = 0f
        private set
    var currentOffsetY: Float = 0f
        private set

    fun update(nowMillis: Long) {
        if (lastShiftAtMillis == 0L) {
            lastShiftAtMillis = nowMillis
            transitionStartMillis = nowMillis
        }
        if (nowMillis - lastShiftAtMillis >= shiftIntervalMillis) {
            lastShiftAtMillis = nowMillis
            transitionStartMillis = nowMillis
            fromX = currentOffsetX
            fromY = currentOffsetY
            targetX = Random.nextFloat() * 2f * maxRangePx - maxRangePx
            targetY = Random.nextFloat() * 2f * maxRangePx - maxRangePx
        }
        val t = ((nowMillis - transitionStartMillis).toFloat() / transitionMillis).coerceIn(0f, 1f)
        // Smoothstep easing for a gentle drift rather than linear motion.
        val eased = t * t * (3f - 2f * t)
        currentOffsetX = fromX + (targetX - fromX) * eased
        currentOffsetY = fromY + (targetY - fromY) * eased
    }
}
