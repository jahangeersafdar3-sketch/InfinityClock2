package com.infinityclock.app.clock.engine

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.infinityclock.app.clock.model.ClockCategory
import com.infinityclock.app.clock.model.AnimationQuality
import com.infinityclock.app.clock.model.ClockConfig
import com.infinityclock.app.clock.util.TickTime
import com.infinityclock.app.clock.util.dateString
import com.infinityclock.app.clock.util.timeString

/**
 * Hybrid faces compose the same Digital/Analog primitives rather than
 * duplicating rendering logic — that's what keeps the engine reusable as
 * new hybrid categories are added in Part 2/3.
 */
@Composable
fun HybridClockFace(
    config: ClockConfig,
    time: TickTime,
    quality: AnimationQuality,
    batteryPercent: Int,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(16.dp)) {
        when (config.category) {
            ClockCategory.HYBRID_ANALOG_DIGITAL -> {
                AnalogClockFace(config, time, quality, modifier = Modifier.fillMaxWidth())
                Text(
                    text = time.timeString(config.is24Hour, config.showSeconds),
                    color = Color(config.secondaryColor),
                    fontWeight = FontWeight.Medium,
                    fontSize = 18.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            ClockCategory.HYBRID_ANALOG_DATE -> {
                AnalogClockFace(config, time, quality, modifier = Modifier.fillMaxWidth())
                Text(
                    text = "${time.dayOfWeek}, ${time.dateString()}",
                    color = Color(config.secondaryColor),
                    fontSize = 14.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            ClockCategory.HYBRID_DIGITAL_SECONDS_RING -> {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxWidth()) {
                    DigitalClockFace(config, time, quality)
                }
                LinearProgressIndicator(
                    progress = { time.second / 60f },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    color = Color(config.accentColor)
                )
            }

            ClockCategory.HYBRID_DIGITAL_BATTERY -> {
                DigitalClockFace(config, time, quality)
                Text(
                    text = "Battery: $batteryPercent%",
                    color = Color(config.secondaryColor),
                    fontSize = 14.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                LinearProgressIndicator(
                    progress = { batteryPercent / 100f },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    color = Color(config.primaryColor)
                )
            }

            ClockCategory.HYBRID_DIGITAL_WORLD -> {
                DigitalClockFace(config, time, quality)
                Text(
                    text = "Local time zone",
                    color = Color(config.secondaryColor),
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            else -> DigitalClockFace(config, time, quality)
        }
    }
}
