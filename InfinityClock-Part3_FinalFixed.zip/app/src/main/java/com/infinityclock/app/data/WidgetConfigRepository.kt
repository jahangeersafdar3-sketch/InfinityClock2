package com.infinityclock.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.infinityclock.app.widget.model.WidgetInstanceConfig
import kotlinx.coroutines.flow.first
import org.json.JSONObject

private val Context.widgetConfigDataStore by preferencesDataStore(name = "infinity_clock_widget_configs")

/**
 * Stores each home-screen widget instance's configuration independently,
 * keyed by its Android-assigned appWidgetId — exactly what's required so
 * multiple pinned widgets never share settings.
 */
class WidgetConfigRepository(private val context: Context) {

    private fun keyFor(appWidgetId: Int) = stringPreferencesKey("widget_$appWidgetId")
    private val knownIdsKey = stringSetPreferencesKey("known_widget_ids")

    suspend fun get(appWidgetId: Int): WidgetInstanceConfig? {
        val prefs = context.widgetConfigDataStore.data.first()
        val json = prefs[keyFor(appWidgetId)] ?: return null
        return WidgetInstanceConfig.fromJson(JSONObject(json))
    }

    suspend fun save(config: WidgetInstanceConfig) {
        context.widgetConfigDataStore.edit { prefs ->
            prefs[keyFor(config.appWidgetId)] = config.toJson().toString()
            val known = prefs[knownIdsKey] ?: emptySet()
            prefs[knownIdsKey] = known + config.appWidgetId.toString()
        }
    }

    suspend fun remove(appWidgetId: Int) {
        context.widgetConfigDataStore.edit { prefs ->
            prefs.remove(keyFor(appWidgetId))
            val known = prefs[knownIdsKey] ?: emptySet()
            prefs[knownIdsKey] = known - appWidgetId.toString()
        }
    }

    suspend fun allConfiguredIds(): Set<Int> {
        val prefs = context.widgetConfigDataStore.data.first()
        return (prefs[knownIdsKey] ?: emptySet()).mapNotNull { it.toIntOrNull() }.toSet()
    }

    suspend fun hasAnyConfigured(): Boolean = allConfiguredIds().isNotEmpty()
}
