package com.infinityclock.app.widget

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.unit.ColorProvider
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.clickable
import androidx.glance.action.actionStartActivity
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import com.infinityclock.app.MainActivity
import com.infinityclock.app.clock.util.currentTickTime
import com.infinityclock.app.clock.util.timeString
import com.infinityclock.app.widget.model.WidgetInstanceConfig
import com.infinityclock.app.widget.render.WidgetBitmapRenderer

enum class WidgetSizeCategory { SMALL, MEDIUM, LARGE, EXTRA_LARGE }

/**
 * The shared content every Infinity Clock widget renders, parameterized by
 * size category so the layout genuinely adapts (bigger digits, extra date/
 * day rows, or an analog face) instead of the same fixed layout just being
 * cropped on a small widget.
 */
@Composable
fun InfinityWidgetContent(
    sizeCategory: WidgetSizeCategory,
    resolved: ResolvedWidgetClock,
    config: WidgetInstanceConfig?
) {
    val time = currentTickTime()
    val is24Hour = config?.is24Hour ?: true
    val showSeconds = config?.showSeconds ?: false
    val showDate = config?.showDate ?: (sizeCategory != WidgetSizeCategory.SMALL)
    val showDay = config?.showDay ?: (sizeCategory == WidgetSizeCategory.LARGE || sizeCategory == WidgetSizeCategory.EXTRA_LARGE)

    val bgAlpha = if (config?.transparentBackground == true) 0f else (config?.backgroundOpacity ?: 0.85f)
    val primaryArgb = config?.overridePrimaryColor ?: resolved.primaryColor
    val secondaryArgb = config?.overrideSecondaryColor ?: resolved.secondaryColor

    val useAnalog = resolved.renderAsAnalog && sizeCategory != WidgetSizeCategory.SMALL

    Box(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(Color(0xFF0B0B14).copy(alpha = bgAlpha))
            .clickable(actionStartActivity<MainActivity>())
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        if (useAnalog) {
            val boxSizePx = 300
            val bitmap = WidgetBitmapRenderer.renderAnalogFace(
                widthPx = boxSizePx, heightPx = boxSizePx,
                primaryColor = primaryArgb, secondaryColor = secondaryArgb, accentColor = primaryArgb,
                hour24 = time.hour24, minute = time.minute, second = time.second
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(provider = ImageProvider(bitmap), contentDescription = resolved.name, modifier = GlanceModifier.fillMaxSize())
                if (showDate && sizeCategory == WidgetSizeCategory.EXTRA_LARGE) {
                    Text(
                        text = if (showDay) "${time.dayOfWeek}, ${time.month} ${time.dayOfMonth}" else "${time.month} ${time.dayOfMonth}",
                        style = TextStyle(color = ColorProvider(Color(secondaryArgb)), fontSize = 12.sp, textAlign = TextAlign.Center)
                    )
                }
            }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val timeText = time.timeString(is24Hour, showSeconds)
                val fontSize = when (sizeCategory) {
                    WidgetSizeCategory.SMALL -> 22
                    WidgetSizeCategory.MEDIUM -> 32
                    WidgetSizeCategory.LARGE -> 42
                    WidgetSizeCategory.EXTRA_LARGE -> 56
                }
                Text(
                    text = timeText,
                    style = TextStyle(
                        color = ColorProvider(Color(primaryArgb)),
                        fontSize = fontSize.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                )
                if (showDate) {
                    Text(
                        text = if (showDay) "${time.dayOfWeek}, ${time.month} ${time.dayOfMonth}" else "${time.month} ${time.dayOfMonth}",
                        style = TextStyle(
                            color = ColorProvider(Color(secondaryArgb)),
                            fontSize = (if (sizeCategory == WidgetSizeCategory.SMALL) 10 else 13).sp,
                            textAlign = TextAlign.Center
                        )
                    )
                }
            }
        }
    }
}
