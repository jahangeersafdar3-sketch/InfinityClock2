package com.infinityclock.app.widget.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.infinityclock.app.widget.WidgetUpdateScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Reacts to system events that must immediately refresh widgets and/or
 * restart the tick chain: device reboot, manual time change, timezone
 * change, and locale change (all satisfy the Part 2 "Widget Update System"
 * lifecycle requirements). These four actions are on Android's static-
 * broadcast exemption list, so a manifest-registered receiver is correct
 * here (no need to register dynamically at runtime).
 */
class WidgetSystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                WidgetUpdateScheduler.triggerAllWidgetUpdates(context)
                if (WidgetUpdateScheduler.hasAnyConfiguredWidget(context)) {
                    when (intent.action) {
                        Intent.ACTION_BOOT_COMPLETED,
                        Intent.ACTION_TIME_CHANGED,
                        Intent.ACTION_TIMEZONE_CHANGED,
                        Intent.ACTION_LOCALE_CHANGED -> WidgetUpdateScheduler.startIfNeeded(context)
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
